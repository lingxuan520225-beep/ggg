<?php

$install_lock = __DIR__ . '/../install.lock';
if (!file_exists($install_lock)) {
    header('Location: /install.php');
    exit;
}

//家园地址
$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';
$host = $_SERVER['HTTP_HOST'];
$config['jy_url'] = "$protocol://$host";

//分区列表
$config['urls'] = [
     [
        'qy' => 2,
        'url' => "$protocol://$host",
        'name' => '仙途幻想[一区]（正式服）',
        'status' => 1, // 运行状态，1正常，0关闭
    ],

	[
        'qy' => 4,
        'url' => 'http://182.254.194.141:82',
        'name' => '齐天大圣[二区]（正式服）',
        'status' => 0, // 运行状态，1正常，0关闭
    ],
    [
        'qy' => 2,
        'url' => 'mhjy',
        'name' => '2.梦幻家园',
        'status' => 0, // 运行状态，1正常，0关闭
    ]，
    [
        'qy' => 25,
        'url' => 'mhjy.xyz',
        'name' => '梦幻家园',
        'status' => 0, // 运行状态，1正常，0关闭
    ]];

//家园数据库配置
$config['mysql'] = [
    'host' => 'localhost',
    'user' => 'xxjyuser1',
    'password' => 'xxjyuser1',
    'database' => 'xxjyuser1',
];

//是否开启调试信息
$config['debug'] = false;

return $config;
