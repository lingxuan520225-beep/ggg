-- MySQL dump 10.13  Distrib 5.7.26, for Win64 (x86_64)
--
-- Host: localhost    Database: xxjyuser
-- ------------------------------------------------------
-- Server version	5.7.26

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `all_boss`
--

DROP TABLE IF EXISTS `all_boss`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `all_boss` (
  `bossid` int(11) NOT NULL,
  `bossmz` text NOT NULL,
  `bosstime` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `all_boss`
--

LOCK TABLES `all_boss` WRITE;
/*!40000 ALTER TABLE `all_boss` DISABLE KEYS */;
/*!40000 ALTER TABLE `all_boss` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `all_bp`
--

DROP TABLE IF EXISTS `all_bp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `all_bp` (
  `bpid` int(11) NOT NULL,
  `bpdj` int(11) NOT NULL,
  `bpmz` text NOT NULL,
  `cbpmz` text NOT NULL,
  `cwjid` int(11) NOT NULL,
  `xbpmz` text NOT NULL,
  `xwjid` int(11) NOT NULL,
  `ccmz01` text NOT NULL,
  `ccid01` int(11) NOT NULL,
  `ccmz02` text NOT NULL,
  `ccid02` int(11) NOT NULL,
  `ccmz03` text NOT NULL,
  `ccid03` int(11) NOT NULL,
  `ccmz04` int(11) NOT NULL,
  `ccid04` int(11) NOT NULL,
  `ccmz05` text NOT NULL,
  `ccid05` int(11) NOT NULL,
  `ccmz06` text NOT NULL,
  `ccid06` int(11) NOT NULL,
  `bprsmax` int(11) NOT NULL,
  `bpjymax` int(11) NOT NULL,
  `bpyl` int(11) NOT NULL,
  `bpsw` int(11) NOT NULL,
  `bpjy` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '帮派经验',
  `bprs` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '帮派人数'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `all_bp`
--

LOCK TABLES `all_bp` WRITE;
/*!40000 ALTER TABLE `all_bp` DISABLE KEYS */;
/*!40000 ALTER TABLE `all_bp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `all_cz`
--

DROP TABLE IF EXISTS `all_cz`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `all_cz` (
  `id` int(11) NOT NULL COMMENT '排序',
  `czid` int(11) NOT NULL COMMENT '充值id',
  `czje` int(11) NOT NULL COMMENT '充值金额',
  `cztime` datetime NOT NULL COMMENT '充值时间',
  `czfl` int(11) NOT NULL COMMENT '充值方式'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `all_cz`
--

LOCK TABLES `all_cz` WRITE;
/*!40000 ALTER TABLE `all_cz` DISABLE KEYS */;
/*!40000 ALTER TABLE `all_cz` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `all_gzhoures`
--

DROP TABLE IF EXISTS `all_gzhoures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `all_gzhoures` (
  `id` int(11) NOT NULL,
  `wjid` int(11) NOT NULL,
  `fzid` int(11) NOT NULL,
  `wjmz` text NOT NULL,
  `fzmz` text NOT NULL,
  `fzfl` int(11) NOT NULL,
  `fzgm` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `all_gzhoures`
--

LOCK TABLES `all_gzhoures` WRITE;
/*!40000 ALTER TABLE `all_gzhoures` DISABLE KEYS */;
/*!40000 ALTER TABLE `all_gzhoures` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `all_hbmoney`
--

DROP TABLE IF EXISTS `all_hbmoney`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `all_hbmoney` (
  `wjid` int(11) NOT NULL,
  `wjmz` text NOT NULL,
  `money` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `all_hbmoney`
--

LOCK TABLES `all_hbmoney` WRITE;
/*!40000 ALTER TABLE `all_hbmoney` DISABLE KEYS */;
/*!40000 ALTER TABLE `all_hbmoney` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `all_hbmoneyjc`
--

DROP TABLE IF EXISTS `all_hbmoneyjc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `all_hbmoneyjc` (
  `id` int(11) NOT NULL,
  `money` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `all_hbmoneyjc`
--

LOCK TABLES `all_hbmoneyjc` WRITE;
/*!40000 ALTER TABLE `all_hbmoneyjc` DISABLE KEYS */;
/*!40000 ALTER TABLE `all_hbmoneyjc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `all_hdph01`
--

DROP TABLE IF EXISTS `all_hdph01`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `all_hdph01` (
  `id` int(11) NOT NULL,
  `wjid` int(11) NOT NULL,
  `wjmz` text NOT NULL,
  `vip` int(11) NOT NULL,
  `ds01` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `all_hdph01`
--

LOCK TABLES `all_hdph01` WRITE;
/*!40000 ALTER TABLE `all_hdph01` DISABLE KEYS */;
/*!40000 ALTER TABLE `all_hdph01` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `all_hdph02`
--

DROP TABLE IF EXISTS `all_hdph02`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `all_hdph02` (
  `id` int(11) NOT NULL,
  `wjid` int(11) NOT NULL,
  `wjmz` text NOT NULL,
  `vip` int(11) NOT NULL,
  `ds01` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `all_hdph02`
--

LOCK TABLES `all_hdph02` WRITE;
/*!40000 ALTER TABLE `all_hdph02` DISABLE KEYS */;
/*!40000 ALTER TABLE `all_hdph02` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `all_hdph03`
--

DROP TABLE IF EXISTS `all_hdph03`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `all_hdph03` (
  `id` int(11) NOT NULL,
  `wjid` int(11) NOT NULL,
  `wjmz` text NOT NULL,
  `vip` int(11) NOT NULL,
  `ds01` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `all_hdph03`
--

LOCK TABLES `all_hdph03` WRITE;
/*!40000 ALTER TABLE `all_hdph03` DISABLE KEYS */;
/*!40000 ALTER TABLE `all_hdph03` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `all_houres`
--

DROP TABLE IF EXISTS `all_houres`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `all_houres` (
  `id` int(11) NOT NULL,
  `wjid` int(11) NOT NULL,
  `fzid` int(11) NOT NULL,
  `wjmz` text NOT NULL,
  `fzmz` text NOT NULL,
  `fzfl` int(11) NOT NULL,
  `fzgm` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `all_houres`
--

LOCK TABLES `all_houres` WRITE;
/*!40000 ALTER TABLE `all_houres` DISABLE KEYS */;
/*!40000 ALTER TABLE `all_houres` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `all_ip`
--

DROP TABLE IF EXISTS `all_ip`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `all_ip` (
  `ip` text NOT NULL,
  `iptime` datetime NOT NULL,
  `wjid` int(11) NOT NULL,
  `wjname` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `all_ip`
--

LOCK TABLES `all_ip` WRITE;
/*!40000 ALTER TABLE `all_ip` DISABLE KEYS */;
/*!40000 ALTER TABLE `all_ip` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `all_jc`
--

DROP TABLE IF EXISTS `all_jc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `all_jc` (
  `id` int(11) NOT NULL,
  `xlid` int(11) NOT NULL,
  `jc` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `all_jc`
--

LOCK TABLES `all_jc` WRITE;
/*!40000 ALTER TABLE `all_jc` DISABLE KEYS */;
/*!40000 ALTER TABLE `all_jc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `all_jdjc`
--

DROP TABLE IF EXISTS `all_jdjc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `all_jdjc` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `wjid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '玩家ID',
  `vip` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '玩家VIP',
  `wjmz` varchar(32) NOT NULL DEFAULT '' COMMENT '玩家名字',
  `jcjg` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '竞猜价格',
  `cq` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '出拳',
  `timex` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `all_jdjc`
--

LOCK TABLES `all_jdjc` WRITE;
/*!40000 ALTER TABLE `all_jdjc` DISABLE KEYS */;
/*!40000 ALTER TABLE `all_jdjc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `all_ltbw`
--

DROP TABLE IF EXISTS `all_ltbw`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `all_ltbw` (
  `id` int(11) NOT NULL DEFAULT '0' COMMENT '编号id',
  `wjid` int(11) NOT NULL DEFAULT '0' COMMENT '玩家id',
  `wjmz` text NOT NULL COMMENT '玩家名字',
  `zltime` datetime NOT NULL COMMENT '占领时间',
  `zlmb` int(11) NOT NULL DEFAULT '0' COMMENT '占领膜拜',
  `lthp` text NOT NULL COMMENT '擂台hp',
  `ltgj` text NOT NULL COMMENT '擂台攻击',
  `ltmg` text NOT NULL COMMENT '擂台魔攻',
  `ltfy` text NOT NULL COMMENT '擂台防御',
  `ltmp` text NOT NULL COMMENT '擂台门派'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `all_ltbw`
--

LOCK TABLES `all_ltbw` WRITE;
/*!40000 ALTER TABLE `all_ltbw` DISABLE KEYS */;
/*!40000 ALTER TABLE `all_ltbw` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `all_money`
--

DROP TABLE IF EXISTS `all_money`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `all_money` (
  `wjid` int(11) NOT NULL,
  `wjmz` text NOT NULL,
  `money` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `all_money`
--

LOCK TABLES `all_money` WRITE;
/*!40000 ALTER TABLE `all_money` DISABLE KEYS */;
/*!40000 ALTER TABLE `all_money` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `all_moneyjc`
--

DROP TABLE IF EXISTS `all_moneyjc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `all_moneyjc` (
  `id` int(11) NOT NULL,
  `money` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `all_moneyjc`
--

LOCK TABLES `all_moneyjc` WRITE;
/*!40000 ALTER TABLE `all_moneyjc` DISABLE KEYS */;
/*!40000 ALTER TABLE `all_moneyjc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `all_pay`
--

DROP TABLE IF EXISTS `all_pay`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `all_pay` (
  `id` int(11) NOT NULL,
  `payid` text NOT NULL,
  `paywjid` int(11) NOT NULL,
  `price` text NOT NULL,
  `payzf` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `all_pay`
--

LOCK TABLES `all_pay` WRITE;
/*!40000 ALTER TABLE `all_pay` DISABLE KEYS */;
/*!40000 ALTER TABLE `all_pay` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `all_phb`
--

DROP TABLE IF EXISTS `all_phb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `all_phb` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '标识',
  `wjid` int(11) NOT NULL COMMENT '玩家id',
  `wjmz` varchar(16) NOT NULL COMMENT '玩家名字',
  `vip` int(11) NOT NULL,
  `phb1` bigint(20) unsigned NOT NULL COMMENT '气血榜',
  `phb2` bigint(20) unsigned NOT NULL COMMENT '攻击榜',
  `phb3` bigint(20) unsigned NOT NULL COMMENT '魔攻榜',
  `phb4` bigint(20) unsigned NOT NULL COMMENT '防御榜',
  `phb5` bigint(20) unsigned NOT NULL COMMENT '等级榜',
  `phb6` bigint(20) unsigned NOT NULL COMMENT '银两榜',
  `phb7` bigint(20) unsigned NOT NULL COMMENT '金豆榜',
  `phb8` bigint(20) unsigned NOT NULL COMMENT '充值榜',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `all_phb`
--

LOCK TABLES `all_phb` WRITE;
/*!40000 ALTER TABLE `all_phb` DISABLE KEYS */;
/*!40000 ALTER TABLE `all_phb` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `all_pk`
--

DROP TABLE IF EXISTS `all_pk`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `all_pk` (
  `pk_id` int(11) NOT NULL DEFAULT '0',
  `pk_wjid` int(11) NOT NULL DEFAULT '0',
  `pk_name` varchar(11) NOT NULL DEFAULT '0',
  `pk_max_hp` int(50) NOT NULL DEFAULT '0',
  `pk_max_mp` int(50) NOT NULL DEFAULT '0',
  `pk_gj` int(50) NOT NULL DEFAULT '0',
  `pk_fy` int(50) NOT NULL DEFAULT '0',
  `pk_mg` int(50) NOT NULL DEFAULT '0',
  `pk_bg` int(50) NOT NULL DEFAULT '0',
  `pk_hg` int(50) NOT NULL DEFAULT '0',
  `pk_lg` int(50) NOT NULL DEFAULT '0',
  `pk_bf` int(50) NOT NULL DEFAULT '0',
  `pk_hf` int(50) NOT NULL DEFAULT '0',
  `pk_lf` int(50) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `all_pk`
--

LOCK TABLES `all_pk` WRITE;
/*!40000 ALTER TABLE `all_pk` DISABLE KEYS */;
/*!40000 ALTER TABLE `all_pk` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `all_pm`
--

DROP TABLE IF EXISTS `all_pm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `all_pm` (
  `id` int(11) NOT NULL DEFAULT '0' COMMENT '标识',
  `wjid` int(11) NOT NULL DEFAULT '0' COMMENT '玩家id',
  `wjmz` text NOT NULL COMMENT '玩家名字',
  `pmtime` datetime NOT NULL COMMENT '拍卖时间',
  `pmwpid` int(11) NOT NULL DEFAULT '0' COMMENT '拍卖物品id',
  `pmwpmz` text NOT NULL COMMENT '拍卖物品名字',
  `pmwpsl` int(11) NOT NULL DEFAULT '0' COMMENT '拍卖物品数量',
  `pmwpjg` text NOT NULL COMMENT '拍卖物品价格',
  `pmsjc` int(11) NOT NULL DEFAULT '0' COMMENT '拍卖时间搓',
  `pmwpfl` int(11) NOT NULL DEFAULT '0' COMMENT '拍卖物品分类'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `all_pm`
--

LOCK TABLES `all_pm` WRITE;
/*!40000 ALTER TABLE `all_pm` DISABLE KEYS */;
/*!40000 ALTER TABLE `all_pm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `all_qd`
--

DROP TABLE IF EXISTS `all_qd`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `all_qd` (
  `id` int(11) NOT NULL,
  `wjid` int(11) NOT NULL COMMENT '玩家id',
  `qdsj` datetime NOT NULL COMMENT '签到时间',
  `qdcs` int(11) NOT NULL COMMENT '签到次数',
  `qdy` int(11) NOT NULL COMMENT '签到月份',
  `qd1` int(11) NOT NULL COMMENT '签到1',
  `qd2` int(11) NOT NULL COMMENT '签到2',
  `qd3` int(11) NOT NULL COMMENT '签到3',
  `qd4` int(11) NOT NULL COMMENT '签到4',
  `qd5` int(11) NOT NULL COMMENT '签到5'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `all_qd`
--

LOCK TABLES `all_qd` WRITE;
/*!40000 ALTER TABLE `all_qd` DISABLE KEYS */;
/*!40000 ALTER TABLE `all_qd` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `all_qggz`
--

DROP TABLE IF EXISTS `all_qggz`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `all_qggz` (
  `id` int(11) NOT NULL,
  `qgxx` text NOT NULL,
  `qgmz` text NOT NULL,
  `wjid` int(11) NOT NULL,
  `qgjg` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `all_qggz`
--

LOCK TABLES `all_qggz` WRITE;
/*!40000 ALTER TABLE `all_qggz` DISABLE KEYS */;
/*!40000 ALTER TABLE `all_qggz` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `all_qtjc`
--

DROP TABLE IF EXISTS `all_qtjc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `all_qtjc` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '编号id',
  `wjid` int(11) NOT NULL DEFAULT '0' COMMENT '玩家id',
  `vip` int(11) NOT NULL DEFAULT '0' COMMENT 'vip等级',
  `wjmz` varchar(32) NOT NULL COMMENT '玩家名字',
  `jcjg` varchar(255) NOT NULL COMMENT '竞猜价格',
  `cq` int(11) NOT NULL DEFAULT '0' COMMENT '出拳',
  `timex` varchar(32) NOT NULL COMMENT '竞猜时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `all_qtjc`
--

LOCK TABLES `all_qtjc` WRITE;
/*!40000 ALTER TABLE `all_qtjc` DISABLE KEYS */;
/*!40000 ALTER TABLE `all_qtjc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `all_sdk`
--

DROP TABLE IF EXISTS `all_sdk`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `all_sdk` (
  `sdkid` int(11) NOT NULL,
  `sdk` text NOT NULL,
  `sdktime` datetime NOT NULL,
  `sdkfl` int(11) NOT NULL,
  `sdksy` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `all_sdk`
--

LOCK TABLES `all_sdk` WRITE;
/*!40000 ALTER TABLE `all_sdk` DISABLE KEYS */;
/*!40000 ALTER TABLE `all_sdk` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `all_sq`
--

DROP TABLE IF EXISTS `all_sq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `all_sq` (
  `wjid` int(11) NOT NULL DEFAULT '0' COMMENT '玩家ID',
  `sqpj1` int(11) unsigned zerofill NOT NULL DEFAULT '00000000000' COMMENT '神器等级',
  `sqpj2` int(11) unsigned zerofill NOT NULL DEFAULT '00000000000' COMMENT '神器等级',
  `sqpj3` int(11) unsigned zerofill NOT NULL DEFAULT '00000000000' COMMENT '神器等级',
  PRIMARY KEY (`wjid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `all_sq`
--

LOCK TABLES `all_sq` WRITE;
/*!40000 ALTER TABLE `all_sq` DISABLE KEYS */;
/*!40000 ALTER TABLE `all_sq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `all_user`
--

DROP TABLE IF EXISTS `all_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `all_user` (
  `wjid` int(11) NOT NULL,
  `id` int(11) NOT NULL,
  `wjname` text NOT NULL,
  `wjtime` datetime NOT NULL,
  `utime` int(11) NOT NULL,
  `fl` int(11) NOT NULL,
  `yj` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `all_user`
--

LOCK TABLES `all_user` WRITE;
/*!40000 ALTER TABLE `all_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `all_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `all_xjhb`
--

DROP TABLE IF EXISTS `all_xjhb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `all_xjhb` (
  `id` int(11) NOT NULL,
  `wjid` int(11) NOT NULL,
  `wjmz` text NOT NULL,
  `wjje` int(11) NOT NULL,
  `zh1` text NOT NULL,
  `zh2` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `all_xjhb`
--

LOCK TABLES `all_xjhb` WRITE;
/*!40000 ALTER TABLE `all_xjhb` DISABLE KEYS */;
/*!40000 ALTER TABLE `all_xjhb` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `all_yd01`
--

DROP TABLE IF EXISTS `all_yd01`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `all_yd01` (
  `id` int(11) NOT NULL,
  `wjid` int(11) NOT NULL,
  `wjmz` text NOT NULL,
  `vip` int(11) NOT NULL,
  `ds01` int(11) NOT NULL,
  `ds02` int(11) NOT NULL,
  `dy01_time` datetime NOT NULL,
  `yd01` int(11) NOT NULL COMMENT '免费',
  `yd02` int(11) NOT NULL COMMENT '收费'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `all_yd01`
--

LOCK TABLES `all_yd01` WRITE;
/*!40000 ALTER TABLE `all_yd01` DISABLE KEYS */;
/*!40000 ALTER TABLE `all_yd01` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `all_yd02`
--

DROP TABLE IF EXISTS `all_yd02`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `all_yd02` (
  `id` int(11) NOT NULL,
  `wjid` int(11) NOT NULL,
  `wjmz` text NOT NULL,
  `vip` int(11) NOT NULL,
  `ds01` int(11) NOT NULL,
  `ds02` int(11) NOT NULL,
  `dy01_time` datetime NOT NULL,
  `yd01` int(11) NOT NULL COMMENT '免费',
  `yd02` int(11) NOT NULL COMMENT '收费'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `all_yd02`
--

LOCK TABLES `all_yd02` WRITE;
/*!40000 ALTER TABLE `all_yd02` DISABLE KEYS */;
/*!40000 ALTER TABLE `all_yd02` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `all_yd03`
--

DROP TABLE IF EXISTS `all_yd03`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `all_yd03` (
  `id` int(11) NOT NULL,
  `wjid` int(11) NOT NULL,
  `wjmz` text NOT NULL,
  `vip` int(11) NOT NULL,
  `ds01` int(11) NOT NULL,
  `ds02` int(11) NOT NULL,
  `dy01_time` datetime NOT NULL,
  `yd01` int(11) NOT NULL COMMENT '免费',
  `yd02` int(11) NOT NULL COMMENT '收费'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `all_yd03`
--

LOCK TABLES `all_yd03` WRITE;
/*!40000 ALTER TABLE `all_yd03` DISABLE KEYS */;
/*!40000 ALTER TABLE `all_yd03` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `all_yd04`
--

DROP TABLE IF EXISTS `all_yd04`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `all_yd04` (
  `id` int(11) NOT NULL,
  `wjid` int(11) NOT NULL,
  `wjmz` text NOT NULL,
  `vip` int(11) NOT NULL,
  `ds01` int(11) NOT NULL,
  `ds02` int(11) NOT NULL,
  `dy01_time` datetime NOT NULL,
  `yd01` int(11) NOT NULL COMMENT '免费',
  `yd02` int(11) NOT NULL COMMENT '收费'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `all_yd04`
--

LOCK TABLES `all_yd04` WRITE;
/*!40000 ALTER TABLE `all_yd04` DISABLE KEYS */;
/*!40000 ALTER TABLE `all_yd04` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `all_yl`
--

DROP TABLE IF EXISTS `all_yl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `all_yl` (
  `wjid` int(11) NOT NULL COMMENT '玩家id',
  `bbyl` text NOT NULL COMMENT '背包银两',
  `ckyl` text NOT NULL COMMENT '仓库银两'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `all_yl`
--

LOCK TABLES `all_yl` WRITE;
/*!40000 ALTER TABLE `all_yl` DISABLE KEYS */;
/*!40000 ALTER TABLE `all_yl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `all_ylck`
--

DROP TABLE IF EXISTS `all_ylck`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `all_ylck` (
  `wjid` int(11) NOT NULL DEFAULT '0' COMMENT '玩家id',
  `yl01` text NOT NULL COMMENT '银两',
  `yl02` text NOT NULL COMMENT '金豆',
  `yl03` text NOT NULL COMMENT '金带'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `all_ylck`
--

LOCK TABLES `all_ylck` WRITE;
/*!40000 ALTER TABLE `all_ylck` DISABLE KEYS */;
/*!40000 ALTER TABLE `all_ylck` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `all_zt`
--

DROP TABLE IF EXISTS `all_zt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `all_zt` (
  `wjid` int(11) NOT NULL COMMENT '玩家id',
  `username` varchar(16) NOT NULL COMMENT '玩家名字',
  `sex` int(11) NOT NULL COMMENT '玩家性别',
  `tx` varchar(64) NOT NULL COMMENT '玩家头衔',
  `peiou` varchar(32) NOT NULL COMMENT '配偶名字',
  `peiouid` int(11) NOT NULL COMMENT '配偶ID',
  `zzmz` varchar(32) NOT NULL COMMENT '住宅名字',
  `zzid` int(11) NOT NULL COMMENT '住宅ID',
  `zzfl` int(11) NOT NULL COMMENT '住宅分类',
  `dj` int(11) NOT NULL COMMENT '玩家等级',
  `mpp` int(11) NOT NULL COMMENT '门派',
  `bpmz` varchar(32) NOT NULL COMMENT '帮派名字',
  `bpid` int(11) NOT NULL COMMENT '帮派ID',
  `vip` int(11) NOT NULL COMMENT 'VIP等级',
  `vipjy` int(11) NOT NULL COMMENT 'VIP经验',
  `gsrl` int(11) NOT NULL COMMENT '挂售容量',
  `bbrl` int(11) NOT NULL COMMENT '背包容量',
  `ckrl` int(11) NOT NULL COMMENT '仓库容量',
  `emz` int(11) NOT NULL COMMENT '恶名值',
  `lh` int(11) NOT NULL COMMENT '靓号',
  `sqpj_1` int(11) NOT NULL DEFAULT '1',
  `sqpj_2` int(11) NOT NULL DEFAULT '1',
  `sqpj_3` int(11) NOT NULL DEFAULT '1',
  `sqxj_1` int(11) NOT NULL DEFAULT '1',
  `sqxj_2` int(11) NOT NULL DEFAULT '1',
  `sqxj_3` int(11) NOT NULL DEFAULT '1',
  `u_fmtcs` int(11) NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `all_zt`
--

LOCK TABLES `all_zt` WRITE;
/*!40000 ALTER TABLE `all_zt` DISABLE KEYS */;
/*!40000 ALTER TABLE `all_zt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bl`
--

DROP TABLE IF EXISTS `bl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bl` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fqid` int(10) unsigned NOT NULL DEFAULT '0',
  `bll1` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bl`
--

LOCK TABLES `bl` WRITE;
/*!40000 ALTER TABLE `bl` DISABLE KEYS */;
/*!40000 ALTER TABLE `bl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bp`
--

DROP TABLE IF EXISTS `bp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bp` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `bpid` int(10) unsigned NOT NULL DEFAULT '0',
  `usermz` varchar(100) NOT NULL DEFAULT '',
  `userid` int(10) unsigned NOT NULL DEFAULT '0',
  `gx` int(10) unsigned NOT NULL DEFAULT '0',
  `bpswcs` int(10) unsigned NOT NULL DEFAULT '0',
  `bpjf` int(10) unsigned NOT NULL DEFAULT '0',
  `lsgx` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bp`
--

LOCK TABLES `bp` WRITE;
/*!40000 ALTER TABLE `bp` DISABLE KEYS */;
/*!40000 ALTER TABLE `bp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ckqt`
--

DROP TABLE IF EXISTS `ckqt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ckqt` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `wjid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '玩家ID',
  `wpid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '物品ID',
  `wpsl` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '物品数量',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='仓库其他物品';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ckqt`
--

LOCK TABLES `ckqt` WRITE;
/*!40000 ALTER TABLE `ckqt` DISABLE KEYS */;
/*!40000 ALTER TABLE `ckqt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ckwp`
--

DROP TABLE IF EXISTS `ckwp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ckwp` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '编号ID',
  `wjid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '玩家ID',
  `wpid` int(11) NOT NULL DEFAULT '0' COMMENT '仓库物品ID',
  `wpsl` int(11) NOT NULL DEFAULT '0' COMMENT '仓库物品数量',
  `wpfl` int(11) NOT NULL DEFAULT '0' COMMENT '仓库物品分类',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='仓库物品';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ckwp`
--

LOCK TABLES `ckwp` WRITE;
/*!40000 ALTER TABLE `ckwp` DISABLE KEYS */;
/*!40000 ALTER TABLE `ckwp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ckzb`
--

DROP TABLE IF EXISTS `ckzb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ckzb` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '编号ID',
  `wjid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '玩家ID',
  `zbid` int(11) NOT NULL DEFAULT '0' COMMENT '仓库装备ID',
  `zbxj` int(11) NOT NULL DEFAULT '0' COMMENT '仓库装备星级',
  `zbk1` int(11) NOT NULL DEFAULT '0' COMMENT '仓库装备孔1',
  `zbxq1` int(11) NOT NULL DEFAULT '0' COMMENT '仓库镶嵌1',
  `zbk2` int(11) NOT NULL DEFAULT '0' COMMENT '仓库装备孔2',
  `zbxq2` int(11) NOT NULL DEFAULT '0' COMMENT '仓库镶嵌2',
  `zbk3` int(11) NOT NULL DEFAULT '0' COMMENT '仓库装备孔3',
  `zbxq3` int(11) NOT NULL DEFAULT '0' COMMENT '仓库镶嵌3',
  `zbk4` int(11) NOT NULL DEFAULT '0' COMMENT '仓库装备孔4',
  `zbxq4` int(11) NOT NULL DEFAULT '0' COMMENT '仓库镶嵌4',
  `zbk5` int(11) NOT NULL DEFAULT '0' COMMENT '仓库装备孔5',
  `zbxq5` int(11) NOT NULL DEFAULT '0' COMMENT '仓库镶嵌5',
  `zbpd` int(11) NOT NULL DEFAULT '0' COMMENT '仓库装备佩戴',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='仓库装备';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ckzb`
--

LOCK TABLES `ckzb` WRITE;
/*!40000 ALTER TABLE `ckzb` DISABLE KEYS */;
/*!40000 ALTER TABLE `ckzb` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cw`
--

DROP TABLE IF EXISTS `cw`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cw` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '编号ID',
  `wjid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '玩家ID',
  `cwid` int(11) NOT NULL DEFAULT '0' COMMENT '宠物id',
  `cwmz` text NOT NULL COMMENT '宠物名字',
  `cwdj` int(11) NOT NULL DEFAULT '0' COMMENT '宠物等级',
  `cwxj` int(11) NOT NULL DEFAULT '0' COMMENT '宠物星级',
  `cwby` int(11) NOT NULL DEFAULT '0' COMMENT '宠物变异',
  `cwxb` int(11) NOT NULL DEFAULT '0' COMMENT '宠物品质',
  `cwcz` int(11) NOT NULL DEFAULT '0' COMMENT '宠物出战',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='宠物';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cw`
--

LOCK TABLES `cw` WRITE;
/*!40000 ALTER TABLE `cw` DISABLE KEYS */;
/*!40000 ALTER TABLE `cw` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cwzbb`
--

DROP TABLE IF EXISTS `cwzbb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cwzbb` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '编号ID',
  `wjid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '玩家ID',
  `zbid` int(11) NOT NULL DEFAULT '0' COMMENT '装备ID',
  `zbxj` int(11) NOT NULL DEFAULT '0' COMMENT '装备星级',
  `zbk1` int(11) NOT NULL DEFAULT '0' COMMENT '装备孔1',
  `zbxq1` int(11) NOT NULL DEFAULT '0' COMMENT '镶嵌1',
  `zbk2` int(11) NOT NULL DEFAULT '0' COMMENT '装备孔2',
  `zbxq2` int(11) NOT NULL DEFAULT '0' COMMENT '镶嵌2',
  `zbk3` int(11) NOT NULL DEFAULT '0' COMMENT '装备孔3',
  `zbxq3` int(11) NOT NULL DEFAULT '0' COMMENT '镶嵌3',
  `zbk4` int(11) NOT NULL DEFAULT '0' COMMENT '装备孔4',
  `zbxq4` int(11) NOT NULL DEFAULT '0' COMMENT '镶嵌4',
  `zbk5` int(11) NOT NULL DEFAULT '0' COMMENT '装备孔5',
  `zbxq5` int(11) NOT NULL DEFAULT '0' COMMENT '镶嵌5',
  `zbfl` int(11) NOT NULL DEFAULT '0' COMMENT '装备分类',
  `cwid` text NOT NULL COMMENT '宠物ID',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cwzbb`
--

LOCK TABLES `cwzbb` WRITE;
/*!40000 ALTER TABLE `cwzbb` DISABLE KEYS */;
/*!40000 ALTER TABLE `cwzbb` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dyxx`
--

DROP TABLE IF EXISTS `dyxx`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dyxx` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `wjid` int(10) unsigned NOT NULL DEFAULT '0',
  `wpid` int(11) NOT NULL DEFAULT '0' COMMENT '丹药ID',
  `sycs` int(11) NOT NULL DEFAULT '0' COMMENT '丹药使用次数',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dyxx`
--

LOCK TABLES `dyxx` WRITE;
/*!40000 ALTER TABLE `dyxx` DISABLE KEYS */;
/*!40000 ALTER TABLE `dyxx` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fb`
--

DROP TABLE IF EXISTS `fb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fb` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `wjid` int(10) unsigned NOT NULL DEFAULT '0',
  `fbid` int(11) NOT NULL DEFAULT '0' COMMENT '编号ID',
  `fb` datetime NOT NULL COMMENT '副本时间',
  `wc` int(11) NOT NULL DEFAULT '0' COMMENT '副本完成',
  `cs` int(11) NOT NULL DEFAULT '0' COMMENT '副本次数',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fb`
--

LOCK TABLES `fb` WRITE;
/*!40000 ALTER TABLE `fb` DISABLE KEYS */;
/*!40000 ALTER TABLE `fb` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gmuser`
--

DROP TABLE IF EXISTS `gmuser`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gmuser` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) NOT NULL,
  `username` varchar(25) NOT NULL,
  `password` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gmuser`
--

LOCK TABLES `gmuser` WRITE;
/*!40000 ALTER TABLE `gmuser` DISABLE KEYS */;
/*!40000 ALTER TABLE `gmuser` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gsqt`
--

DROP TABLE IF EXISTS `gsqt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gsqt` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '编号ID',
  `wjid` int(10) unsigned NOT NULL DEFAULT '0',
  `wpid` int(11) NOT NULL DEFAULT '0' COMMENT '挂售其他id',
  `wpsl` int(11) NOT NULL DEFAULT '0' COMMENT '挂售其他数量',
  `gsjg` text NOT NULL COMMENT '挂售价格',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gsqt`
--

LOCK TABLES `gsqt` WRITE;
/*!40000 ALTER TABLE `gsqt` DISABLE KEYS */;
/*!40000 ALTER TABLE `gsqt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gswp`
--

DROP TABLE IF EXISTS `gswp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gswp` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '编号ID',
  `wjid` int(10) unsigned NOT NULL DEFAULT '0',
  `wpid` int(11) NOT NULL DEFAULT '0' COMMENT '挂售物品id',
  `wpsl` int(11) NOT NULL DEFAULT '0' COMMENT '挂售物品数量',
  `gsjg` text NOT NULL COMMENT '挂售价格',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gswp`
--

LOCK TABLES `gswp` WRITE;
/*!40000 ALTER TABLE `gswp` DISABLE KEYS */;
/*!40000 ALTER TABLE `gswp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gszb`
--

DROP TABLE IF EXISTS `gszb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gszb` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '编号ID',
  `wjid` int(10) unsigned NOT NULL DEFAULT '0',
  `zbid` int(11) NOT NULL DEFAULT '0' COMMENT '挂售装备ID',
  `zbxj` int(11) NOT NULL DEFAULT '0' COMMENT '挂售装备星级',
  `zbk1` int(11) NOT NULL DEFAULT '0' COMMENT '挂售装备孔1',
  `zbxq1` int(11) NOT NULL DEFAULT '0' COMMENT '挂售镶嵌1',
  `zbk2` int(11) NOT NULL DEFAULT '0' COMMENT '挂售装备孔2',
  `zbxq2` int(11) NOT NULL DEFAULT '0' COMMENT '挂售镶嵌2',
  `zbk3` int(11) NOT NULL DEFAULT '0' COMMENT '挂售装备孔3',
  `zbxq3` int(11) NOT NULL DEFAULT '0' COMMENT '挂售镶嵌3',
  `zbk4` int(11) NOT NULL DEFAULT '0' COMMENT '挂售装备孔4',
  `zbxq4` int(11) NOT NULL DEFAULT '0' COMMENT '挂售镶嵌4',
  `zbk5` int(11) NOT NULL DEFAULT '0' COMMENT '挂售装备孔5',
  `zbxq5` int(11) NOT NULL DEFAULT '0' COMMENT '挂售镶嵌5',
  `zbpd` int(11) NOT NULL DEFAULT '0' COMMENT '挂售装备佩戴',
  `gsjg` text NOT NULL COMMENT '挂售价格',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gszb`
--

LOCK TABLES `gszb` WRITE;
/*!40000 ALTER TABLE `gszb` DISABLE KEYS */;
/*!40000 ALTER TABLE `gszb` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gz01`
--

DROP TABLE IF EXISTS `gz01`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gz01` (
  `zcid` int(11) NOT NULL,
  `zlgj` text NOT NULL,
  `zlgjid` int(11) NOT NULL,
  `gjjz` text NOT NULL,
  `gjjzid` int(11) NOT NULL,
  `czz` text NOT NULL,
  `czzid` int(11) NOT NULL,
  `zlsj` char(8) NOT NULL DEFAULT '' COMMENT '占领时间',
  `czwz` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '夺杖后重置位置'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gz01`
--

LOCK TABLES `gz01` WRITE;
/*!40000 ALTER TABLE `gz01` DISABLE KEYS */;
/*!40000 ALTER TABLE `gz01` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gz03`
--

DROP TABLE IF EXISTS `gz03`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gz03` (
  `id` int(11) NOT NULL,
  `gjmz` varchar(16) NOT NULL DEFAULT '',
  `gjid` int(11) NOT NULL DEFAULT '0',
  `jzmz` varchar(16) NOT NULL DEFAULT '',
  `jzid` int(11) NOT NULL DEFAULT '0',
  `zjf` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '周积分',
  `rjf` int(11) NOT NULL DEFAULT '0' COMMENT '日积分',
  `cjsj` char(8) NOT NULL DEFAULT '' COMMENT '参加时间',
  `zlq` int(11) NOT NULL DEFAULT '0',
  `rlq` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '日领取'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gz03`
--

LOCK TABLES `gz03` WRITE;
/*!40000 ALTER TABLE `gz03` DISABLE KEYS */;
/*!40000 ALTER TABLE `gz03` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gz04`
--

DROP TABLE IF EXISTS `gz04`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gz04` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `wjid` int(11) NOT NULL DEFAULT '0',
  `wjmz` varchar(16) NOT NULL,
  `zjf` int(11) NOT NULL DEFAULT '0' COMMENT '周积分',
  `rjf` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '日积分',
  `swcs` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '死亡次数',
  `swsj` timestamp NULL DEFAULT NULL COMMENT '死亡时间',
  `cjsj` char(8) NOT NULL DEFAULT '' COMMENT '参加时间',
  `zlq` int(11) NOT NULL DEFAULT '0' COMMENT '周领取',
  `rlq` int(11) NOT NULL DEFAULT '0' COMMENT '日领取',
  `czwz` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '夺杖后重置战场位置',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gz04`
--

LOCK TABLES `gz04` WRITE;
/*!40000 ALTER TABLE `gz04` DISABLE KEYS */;
/*!40000 ALTER TABLE `gz04` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gz05`
--

DROP TABLE IF EXISTS `gz05`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gz05` (
  `id` int(11) NOT NULL,
  `gztime` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gz05`
--

LOCK TABLES `gz05` WRITE;
/*!40000 ALTER TABLE `gz05` DISABLE KEYS */;
/*!40000 ALTER TABLE `gz05` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gz06`
--

DROP TABLE IF EXISTS `gz06`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gz06` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fsgjid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '防守国家id',
  `fsgj` varchar(16) NOT NULL DEFAULT '' COMMENT '防守国家',
  `fssj` timestamp NULL DEFAULT NULL COMMENT '防守时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gz06`
--

LOCK TABLES `gz06` WRITE;
/*!40000 ALTER TABLE `gz06` DISABLE KEYS */;
/*!40000 ALTER TABLE `gz06` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hd`
--

DROP TABLE IF EXISTS `hd`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hd` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `wjid` int(10) unsigned NOT NULL DEFAULT '0',
  `hdid` int(11) NOT NULL DEFAULT '0' COMMENT '编号ID',
  `hdtime` datetime NOT NULL COMMENT '活动时间',
  `hdcs` int(11) NOT NULL DEFAULT '0' COMMENT '活动次数',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hd`
--

LOCK TABLES `hd` WRITE;
/*!40000 ALTER TABLE `hd` DISABLE KEYS */;
/*!40000 ALTER TABLE `hd` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hy`
--

DROP TABLE IF EXISTS `hy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hy` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '编号ID',
  `wjid` int(10) unsigned NOT NULL DEFAULT '0',
  `hyid` int(11) NOT NULL DEFAULT '0' COMMENT '好友id',
  `hymz` text NOT NULL COMMENT '好友名字',
  `hyfl` int(11) NOT NULL DEFAULT '0' COMMENT '好友分类',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hy`
--

LOCK TABLES `hy` WRITE;
/*!40000 ALTER TABLE `hy` DISABLE KEYS */;
/*!40000 ALTER TABLE `hy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jfdj`
--

DROP TABLE IF EXISTS `jfdj`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jfdj` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '编号id',
  `wjid` int(10) unsigned NOT NULL DEFAULT '0',
  `jfid` int(10) unsigned NOT NULL DEFAULT '0',
  `jfdj` int(11) NOT NULL DEFAULT '0' COMMENT '解封等级',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jfdj`
--

LOCK TABLES `jfdj` WRITE;
/*!40000 ALTER TABLE `jfdj` DISABLE KEYS */;
/*!40000 ALTER TABLE `jfdj` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jj`
--

DROP TABLE IF EXISTS `jj`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jj` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '编号ID',
  `wjid` int(10) unsigned NOT NULL DEFAULT '0',
  `jjid` int(11) NOT NULL DEFAULT '0' COMMENT '家具ID',
  `jjdj` int(11) NOT NULL DEFAULT '0' COMMENT '家具等级',
  `jjbf` int(11) NOT NULL DEFAULT '0' COMMENT '家具摆放',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jj`
--

LOCK TABLES `jj` WRITE;
/*!40000 ALTER TABLE `jj` DISABLE KEYS */;
/*!40000 ALTER TABLE `jj` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jnn`
--

DROP TABLE IF EXISTS `jnn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jnn` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '编号ID',
  `wjid` int(10) unsigned NOT NULL DEFAULT '0',
  `jnid` int(11) NOT NULL DEFAULT '0' COMMENT '技能id',
  `jndj` int(11) NOT NULL DEFAULT '0' COMMENT '技能等级',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jnn`
--

LOCK TABLES `jnn` WRITE;
/*!40000 ALTER TABLE `jnn` DISABLE KEYS */;
/*!40000 ALTER TABLE `jnn` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `map`
--

DROP TABLE IF EXISTS `map`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `map` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `mz` varchar(32) NOT NULL DEFAULT '',
  `ms` varchar(100) NOT NULL DEFAULT '',
  `dtx` int(10) unsigned NOT NULL DEFAULT '0',
  `dty` int(10) unsigned NOT NULL DEFAULT '0',
  `dtxy` varchar(100) NOT NULL DEFAULT '',
  `up` varchar(100) NOT NULL DEFAULT '',
  `down` varchar(100) NOT NULL DEFAULT '',
  `left` varchar(100) NOT NULL DEFAULT '',
  `right` varchar(100) NOT NULL DEFAULT '',
  `up_jump` varchar(100) NOT NULL DEFAULT '',
  `down_jump` varchar(100) NOT NULL DEFAULT '',
  `left_jump` varchar(100) NOT NULL DEFAULT '',
  `right_jump` varchar(100) NOT NULL DEFAULT '',
  `up_distance` int(10) unsigned NOT NULL DEFAULT '0',
  `down_distance` int(10) unsigned NOT NULL DEFAULT '0',
  `left_distance` int(10) unsigned NOT NULL DEFAULT '0',
  `right_distance` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `map_dtxy_IDX` (`dtxy`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `map`
--

LOCK TABLES `map` WRITE;
/*!40000 ALTER TABLE `map` DISABLE KEYS */;
/*!40000 ALTER TABLE `map` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mtcz`
--

DROP TABLE IF EXISTS `mtcz`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mtcz` (
  `wjid` int(11) NOT NULL,
  `hdid` int(11) NOT NULL,
  `hdtime` int(11) NOT NULL,
  `hdcs` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mtcz`
--

LOCK TABLES `mtcz` WRITE;
/*!40000 ALTER TABLE `mtcz` DISABLE KEYS */;
/*!40000 ALTER TABLE `mtcz` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `o_user_list`
--

DROP TABLE IF EXISTS `o_user_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `o_user_list` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `m_id` varchar(5) NOT NULL,
  `name` text NOT NULL,
  `username` varchar(25) NOT NULL,
  `password` varchar(64) NOT NULL,
  `n` int(11) NOT NULL DEFAULT '0' COMMENT '年',
  `y` int(11) NOT NULL DEFAULT '0' COMMENT '月',
  `r` int(11) NOT NULL DEFAULT '0' COMMENT '日',
  `s` int(11) NOT NULL DEFAULT '0' COMMENT '时',
  `f` int(11) NOT NULL DEFAULT '0' COMMENT '分',
  `m` int(11) NOT NULL DEFAULT '0' COMMENT '秒',
  `ma` text NOT NULL,
  `aqm` text NOT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `o_user_list`
--

LOCK TABLES `o_user_list` WRITE;
/*!40000 ALTER TABLE `o_user_list` DISABLE KEYS */;
INSERT INTO `o_user_list` VALUES (1,'0','给我','WW123456','a411eb68bae78b0059a34cd6c2939df6',2025,3,5,8,44,29,'3XKGVWc7HabL3HoW2GdQcmQ56rZZnbWU','a411eb68bae78b0059a34cd6c2939df6');
/*!40000 ALTER TABLE `o_user_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `qt`
--

DROP TABLE IF EXISTS `qt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qt` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `wjid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '玩家ID',
  `wpid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '物品ID',
  `wpsl` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '物品数量',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='其他物品';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `qt`
--

LOCK TABLES `qt` WRITE;
/*!40000 ALTER TABLE `qt` DISABLE KEYS */;
/*!40000 ALTER TABLE `qt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sw`
--

DROP TABLE IF EXISTS `sw`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sw` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `wjid` int(10) unsigned NOT NULL DEFAULT '0',
  `swid` int(11) NOT NULL DEFAULT '0' COMMENT '声望ID',
  `swzz` int(11) NOT NULL DEFAULT '0' COMMENT '声望值',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sw`
--

LOCK TABLES `sw` WRITE;
/*!40000 ALTER TABLE `sw` DISABLE KEYS */;
/*!40000 ALTER TABLE `sw` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx`
--

DROP TABLE IF EXISTS `tx`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `wjid` int(10) unsigned NOT NULL DEFAULT '0',
  `txid` int(11) NOT NULL DEFAULT '0' COMMENT '头衔ID',
  `txxs` int(11) NOT NULL DEFAULT '0' COMMENT '头衔显示',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx`
--

LOCK TABLES `tx` WRITE;
/*!40000 ALTER TABLE `tx` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `wjid` int(10) unsigned NOT NULL DEFAULT '0',
  `yxm` varchar(64) NOT NULL DEFAULT '' COMMENT '游戏码',
  `cmid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '游戏页面',
  `npc` varchar(100) NOT NULL DEFAULT '' COMMENT '参数',
  `xcmid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最小命令数值',
  `dcmid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最大命令数值',
  `ycmid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上一个页面值',
  `ynpc` varchar(100) NOT NULL DEFAULT '' COMMENT '上一个参数值',
  `x` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '地图区域编号',
  `y` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '地图编号',
  `cwmz` varchar(32) NOT NULL DEFAULT '' COMMENT '宠物名字',
  `ckid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '对象编号',
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '时间',
  `cmds` varchar(10000) NOT NULL DEFAULT '' COMMENT '链接数组',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wj_jj`
--

DROP TABLE IF EXISTS `wj_jj`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wj_jj` (
  `wjid` int(11) NOT NULL,
  `wj_jj` int(11) NOT NULL DEFAULT '1',
  `jj_cs` int(11) NOT NULL DEFAULT '1',
  `jj_sx` int(255) NOT NULL DEFAULT '100',
  `jj_jsgw` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wj_jj`
--

LOCK TABLES `wj_jj` WRITE;
/*!40000 ALTER TABLE `wj_jj` DISABLE KEYS */;
/*!40000 ALTER TABLE `wj_jj` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp`
--

DROP TABLE IF EXISTS `wp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '编号ID',
  `wjid` int(10) unsigned NOT NULL DEFAULT '0',
  `wpid` int(11) NOT NULL DEFAULT '0' COMMENT '物品ID',
  `wpsl` int(11) NOT NULL DEFAULT '0' COMMENT '物品数量',
  `wpfl` int(11) NOT NULL DEFAULT '0' COMMENT '物品分类',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp`
--

LOCK TABLES `wp` WRITE;
/*!40000 ALTER TABLE `wp` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wpp`
--

DROP TABLE IF EXISTS `wpp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wpp` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `wjid` int(10) unsigned NOT NULL DEFAULT '0',
  `wpid` int(11) NOT NULL DEFAULT '0' COMMENT '物品ID',
  `wpcs` int(11) NOT NULL DEFAULT '0' COMMENT '物品使用次数',
  `n` int(11) NOT NULL DEFAULT '0' COMMENT '年',
  `y` int(11) NOT NULL DEFAULT '0' COMMENT '月',
  `r` int(11) NOT NULL DEFAULT '0' COMMENT '日',
  `s` int(11) NOT NULL DEFAULT '0' COMMENT '时',
  `f` int(11) NOT NULL DEFAULT '0' COMMENT '分',
  `m` int(11) NOT NULL DEFAULT '0' COMMENT '秒',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wpp`
--

LOCK TABLES `wpp` WRITE;
/*!40000 ALTER TABLE `wpp` DISABLE KEYS */;
/*!40000 ALTER TABLE `wpp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wpxx`
--

DROP TABLE IF EXISTS `wpxx`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wpxx` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '物品编号',
  `mz` varchar(32) NOT NULL DEFAULT '' COMMENT '物品名字',
  `ms` varchar(100) NOT NULL DEFAULT '' COMMENT '描述',
  `fl` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '分类',
  `jd` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '金豆价格',
  `jg` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '价格',
  `dj` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '等级',
  `zl` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '重量',
  `bd` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '是否绑定',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1152 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wpxx`
--

LOCK TABLES `wpxx` WRITE;
/*!40000 ALTER TABLE `wpxx` DISABLE KEYS */;
INSERT INTO `wpxx` VALUES (1,'回城卷','使用可回到长安十字街头',1,2,1000,1,1,1),(2,'打猎心得','上面记载着打猎的秘籍',1,2,1000,1,1,1),(3,'宠物指南','使用学会技能捕捉术！',1,2,1000,1,1,1),(4,'门派秘籍','使用可学习对应门派的技能',1,2,1000,1,1,1),(5,'【VIP练级卷】','使用可获得30分钟VIP练级祝福时间，拥有VIP练级祝福时间就可以进入刷级通道了！',1,2,1000,1,1,0),(8,'腾云符','使用此符可飞到你想去的地方简直是飞机中的战斗机！',1,2,1000,1,1,1),(9,'〖1千傲来国声望卷〗','使用可获得1000傲来国声望！',1,2,1000,60,1,1),(10,'〖1千宝象国声望卷〗','使用可获得1000宝象国声望！',1,2,1000,60,1,1),(11,'〖1千将军府声望卷〗','使用可获得1000将军府声望！',1,2,1000,60,1,1),(12,'〖1千普陀山声望卷〗','使用可获得1000普陀山声望！',1,2,1000,60,1,1),(13,'〖1千龙宫声望卷〗','使用可获得1000龙宫声望！',1,2,1000,60,1,1),(14,'〖1千月宫声望卷〗','使用可获得1000月宫声望！',1,2,1000,60,1,1),(15,'〖1千方寸山声望卷〗','使用可获得1000方寸山声望！',1,2,1000,60,1,1),(16,'〖1千天宫声望卷〗','使用可获得1000天宫声望！',1,2,1000,60,1,1),(17,'〖1千地府声望卷〗','使用可获得1000地府声望！',1,2,1000,60,1,1),(18,'〖1千西游声望卷〗','使用可获得1000西游声望！',1,2,1000,60,1,1),(19,'〖1千乌鸡国声望卷〗','使用可获得1000乌鸡国声望！',1,2,1000,60,1,1),(20,'〖1千恶魔广场声望卷〗','使用可获得1000恶魔声望！',1,2,1000,60,1,1),(21,'〖1千夫妻声望卷〗','使用可获得1000夫妻声望！',1,1,1000,60,1,1),(22,'红宝石一','稀少难得的红宝石一，升级装备的必须品！',2,2,1000,1,1,1),(23,'红水晶一','稀少难得的红水晶一，升级装备的必须品！',2,2,1000,1,1,1),(24,'蓝宝石一','稀少难得的蓝宝石一，升级装备的必须品！',2,2,1000,1,1,1),(25,'蓝水晶一','稀少难得的蓝水晶一，升级装备的必须品！',2,2,1000,1,1,1),(26,'黄宝石一','稀少难得的黄宝石一，升级装备的必须品！',2,2,1000,1,1,1),(27,'黄水晶一','稀少难得的黄水晶一，升级装备的必须品！',2,2,1000,1,1,1),(28,'金刚石一','稀少难得的金刚石一，升级装备的必须品！',2,2,1000,1,1,1),(29,'佛印石一','稀少难得的佛印石一，升级装备的必须品！',2,2,1000,1,1,1),(30,'玄武石一','稀少难得的玄武石一，升级装备的必须品！',2,2,1000,1,1,1),(31,'红宝石二','稀少难得的红宝石二，升级装备的必须品！',2,2,1000,1,1,1),(32,'红水晶二','稀少难得的红水晶二，升级装备的必须品！',2,2,1000,1,1,1),(33,'蓝宝石二','稀少难得的蓝宝石二，升级装备的必须品！',2,2,1000,1,1,1),(34,'蓝水晶二','稀少难得的蓝水晶二，升级装备的必须品！',2,2,1000,1,1,1),(35,'黄宝石二','稀少难得的黄宝石二，升级装备的必须品！',2,2,1000,1,1,1),(36,'黄水晶二','稀少难得的黄水晶二，升级装备的必须品！',2,2,1000,1,1,1),(37,'金刚石二','稀少难得的金刚石二，升级装备的必须品！',2,2,1000,1,1,1),(38,'佛印石二','稀少难得的佛印石二，升级装备的必须品！',2,2,1000,1,1,1),(39,'玄武石二','稀少难得的玄武石二，升级装备的必须品！',2,2,1000,1,1,1),(40,'红宝石三','稀少难得的红宝石三，升级装备的必须品！',2,2,1000,1,1,1),(41,'红水晶三','稀少难得的红水晶三，升级装备的必须品！',2,2,1000,1,1,1),(42,'蓝宝石三','稀少难得的蓝宝石三，升级装备的必须品！',2,2,1000,1,1,1),(43,'蓝水晶三','稀少难得的蓝水晶三，升级装备的必须品！',2,2,1000,1,1,1),(44,'黄宝石三','稀少难得的黄宝石三，升级装备的必须品！',2,2,1000,1,1,1),(45,'黄水晶三','稀少难得的黄水晶三，升级装备的必须品！',2,2,1000,1,1,1),(46,'金刚石三','稀少难得的金刚石三，升级装备的必须品！',2,2,1000,1,1,1),(47,'佛印石三','稀少难得的佛印石三，升级装备的必须品！',2,2,1000,1,1,1),(48,'玄武石三','稀少难得的玄武石三，升级装备的必须品！',2,2,1000,1,1,1),(49,'红宝石四','稀少难得的红宝石四，升级装备的必须品！',2,2,1000,1,1,1),(50,'红水晶四','稀少难得的红水晶四，升级装备的必须品！',2,2,1000,1,1,1),(51,'蓝宝石四','稀少难得的蓝宝石四，升级装备的必须品！',2,2,1000,1,1,1),(52,'蓝水晶四','稀少难得的蓝水晶四，升级装备的必须品！',2,2,1000,1,1,1),(53,'黄宝石四','稀少难得的黄宝石四，升级装备的必须品！',2,2,1000,1,1,1),(54,'黄水晶四','稀少难得的黄水晶四，升级装备的必须品！',2,2,1000,1,1,1),(55,'金刚石四','稀少难得的金刚石四，升级装备的必须品！',2,2,1000,1,1,1),(56,'佛印石四','稀少难得的佛印石四，升级装备的必须品！',2,2,1000,1,1,1),(57,'玄武石四','稀少难得的玄武石四，升级装备的必须品！',2,2,1000,1,1,1),(58,'红宝石五','稀少难得的红宝石五，升级装备的必须品！',2,2,1000,1,1,1),(59,'红水晶五','稀少难得的红水晶五，升级装备的必须品！',2,2,1000,1,1,1),(60,'蓝宝石五','稀少难得的蓝宝石五，升级装备的必须品！',2,2,1000,1,1,1),(61,'蓝水晶五','稀少难得的蓝水晶五，升级装备的必须品！',2,2,1000,1,1,1),(62,'黄宝石五','稀少难得的黄宝石五，升级装备的必须品！',2,2,1000,1,1,1),(63,'黄水晶五','稀少难得的黄水晶五，升级装备的必须品！',2,2,1000,1,1,1),(64,'金刚石五','稀少难得的金刚石五，升级装备的必须品！',2,2,1000,1,1,1),(65,'佛印石五','稀少难得的佛印石五，升级装备的必须品！',2,2,1000,1,1,1),(66,'玄武石五','稀少难得的玄武石五，升级装备的必须品！',2,2,1000,1,1,1),(67,'红宝石六','稀少难得的红宝石六，升级装备的必须品！',2,2,1000,1,1,1),(68,'红水晶六','稀少难得的红水晶六，升级装备的必须品！',2,2,1000,1,1,1),(69,'蓝宝石六','稀少难得的蓝宝石六，升级装备的必须品！',2,2,1000,1,1,1),(70,'蓝水晶六','稀少难得的蓝水晶六，升级装备的必须品！',2,2,1000,1,1,1),(71,'黄宝石六','稀少难得的黄宝石六，升级装备的必须品！',2,2,1000,1,1,1),(72,'黄水晶六','稀少难得的黄水晶六，升级装备的必须品！',2,2,1000,1,1,1),(73,'金刚石六','稀少难得的金刚石六，升级装备的必须品！',2,2,1000,1,1,1),(74,'佛印石六','稀少难得的佛印石六，升级装备的必须品！',2,2,1000,1,1,1),(75,'玄武石六','稀少难得的玄武石六，升级装备的必须品！',2,2,1000,1,1,1),(76,'【冰晶】','稀少难得的【冰晶】，升级装备的必须品！',2,2,1000,1,1,0),(77,'【雷晶】','稀少难得的【雷晶】，升级装备的必须品！',2,2,1000,1,1,0),(78,'【白骨靴】','稀少难得的【白骨靴】，升级装备的必须品！',2,2,1000,1,1,0),(79,'【食尸鬼之皮】','稀少难得的【食尸鬼之皮】，升级装备的必须品！',2,2,1000,1,1,0),(80,'【祭祀之帽】','稀少难得的【祭祀之帽】，升级装备的必须品！',2,2,1000,1,1,0),(81,'【剥皮鬼之皮】','稀少难得的【剥皮鬼之皮】，升级装备的必须品！',2,2,1000,1,1,0),(82,'【白骨项链】','稀少难得的【白骨项链】，升级装备的必须品！',2,2,1000,1,1,0),(83,'【炼尸宝石】','稀少难得的【炼尸宝石】，升级装备的必须品！',2,2,1000,1,1,0),(84,'【黄袍武器】','稀少难得的【黄袍武器】，升级装备的必须品！',2,2,1000,1,1,0),(85,'【锻造图】','稀少难得的【锻造图】，升级装备的必须品！',2,2,1000,1,1,0),(86,'【黑熊宝石】','稀少难得的【黑熊宝石】，升级装备的必须品！',2,2,1000,1,1,0),(87,'【鹿角手镯】','稀少难得的【鹿角手镯】，升级装备的必须品！',2,2,1000,1,1,0),(88,'【妖将合金】','稀少难得的【妖将合金】，升级装备的必须品！',2,2,1000,1,1,0),(89,'【野熊铠甲】','稀少难得的【野熊铠甲】，升级装备的必须品！',2,2,1000,1,1,0),(90,'【火红毛皮】','稀少难得的【火红毛皮】，升级装备的必须品！',2,2,1000,1,1,0),(91,'【玉衣片】','稀少难得的【玉衣片】，升级装备的必须品！',2,2,1000,1,1,0),(92,'【淡黄狐尾】','稀少难得的【淡黄狐尾】，升级装备的必须品！',2,2,1000,1,1,0),(93,'【猩红石】','稀少难得的【猩红石】，升级装备的必须品！',2,2,1000,1,1,0),(94,'【拔地鼠筋】','稀少难得的【拔地鼠筋】，升级装备的必须品！',2,2,1000,1,1,0),(95,'【天香碧玉竹】','稀少难得的【天香碧玉竹】，升级装备的必须品！',2,2,1000,1,1,0),(96,'【骷髅头】','稀少难得的【骷髅头】，升级装备的必须品！',2,2,1000,1,1,0),(97,'【银犀角】','稀少难得的【银犀角】，升级装备的必须品！',2,2,1000,1,1,0),(98,'【玄铁手镯】','稀少难得的【玄铁手镯】，升级装备的必须品！',2,2,1000,1,1,0),(99,'【黑晶】','稀少难得的【黑晶】，升级装备的必须品！',2,2,1000,1,1,0),(100,'【金精】','稀少难得的【金精】，升级装备的必须品！',2,2,1000,1,1,0),(101,'【金犀角】','稀少难得的【金犀角】，升级装备的必须品！',2,2,1000,1,1,0),(102,'【烈焰火羽】','稀少难得的【烈焰火羽】，升级装备的必须品！',2,2,1000,1,1,0),(103,'【冰凌石】','稀少难得的【冰凌石】，升级装备的必须品！',2,2,1000,1,1,0),(104,'【逆鳞】','稀少难得的【逆鳞】，升级装备的必须品！',2,2,1000,1,1,0),(105,'【紫金】','稀少难得的【紫金】，升级装备的必须品！',2,2,1000,1,1,0),(106,'【琉璃】','稀少难得的【琉璃】，升级装备的必须品！',2,2,1000,1,1,0),(107,'【灵晶】','稀少难得的【灵晶】，升级装备的必须品！',2,2,1000,1,1,0),(108,'【引魄】','稀少难得的【引魄】，升级装备的必须品！',2,2,1000,1,1,0),(109,'【勾魂】','稀少难得的【勾魂】，升级装备的必须品！',2,2,1000,1,1,0),(110,'【东海神铁】','稀少难得的【东海神铁】，升级装备的必须品！',2,2,1000,1,1,0),(111,'【千年寒冰】','稀少难得的【千年寒冰】，升级装备的必须品！',2,2,1000,1,1,0),(112,'〖黑曜石〗','稀少难得的〖黑曜石〗，升级装备的必须品！',2,2,1000,1,1,1),(113,'【玉鼎黄色碎片】','稀少难得的【玉鼎黄色碎片】，升级装备的必须品！',2,2,1000,1,1,0),(114,'【玉鼎红色碎片】','稀少难得的【玉鼎红色碎片】，升级装备的必须品！',2,2,1000,1,1,0),(115,'【玉鼎绿色碎片】','稀少难得的【玉鼎绿色碎片】，升级装备的必须品！',2,2,1000,1,1,0),(116,'【玉鼎橙色碎片】','稀少难得的【玉鼎橙色碎片】，升级装备的必须品！',2,2,1000,1,1,0),(117,'〖苍白内丹〗','稀少难得的〖苍白内丹〗，升级装备的必须品！',2,2,1000,1,1,1),(118,'〖黄澄内丹〗','稀少难得的〖黄澄内丹〗，升级装备的必须品！',2,2,1000,1,1,1),(119,'【千年冰魄】','稀少难得的【千年冰魄】，升级装备的必须品！',2,2,1000,1,1,0),(120,'黑龙之牙','稀少难得的黑龙之牙，升级装备的必须品！',2,2,1000,1,1,1),(121,'〖妖魔内丹〗','妖怪们修炼得内丹！',2,2,1000,1,1,1),(122,'【英雄牌】','英雄的象征，完成各大副本可以获得！',2,2,1000,1,1,0),(123,'〖石块〗','国家建设资源！',2,2,1000,1,1,1),(124,'〖木头〗','国家建设资源！',2,2,1000,1,1,1),(125,'〖硫磺〗','国家建设资源！',2,2,1000,1,1,1),(126,'小幸运草','稀少难得的小幸运草，升级装备的必须品！（直接在身上装备升级消耗）',4,1,1000,1,1,1),(127,'〖金豆〗','人人都喜欢的金豆子！',4,2,1000,1,1,1),(128,'【万能果】','据说这是无所不能的果子~~',4,2,1000,1,1,0),(129,'【新手礼包】（1级）','精心为新手准备的礼包，打开可获得大量物品～',4,2,1000,1,1,0),(130,'【新手礼包】（10级）','精心为新手准备的礼包，打开可获得大量物品～',4,2,1000,10,1,0),(131,'【新手礼包】（30级）','精心为新手准备的礼包，打开可获得大量物品～',4,2,1000,30,1,0),(132,'【新手礼包】（50级）','精心为新手准备的礼包，打开可获得大量物品～',4,2,1000,50,1,0),(133,'【新手礼包】（70级）','精心为新手准备的礼包，打开可获得大量物品～',4,2,1000,70,1,0),(134,'【新手礼包】（90级）','精心为新手准备的礼包，打开可获得大量物品～',4,2,1000,90,1,0),(136,'〖如意毫毛〗','使用可获得1个月属性祝福，生命增加10000点，防御增加7000点，攻击增加6000点，魔攻增加6000点',4,30,1000,1,1,1),(137,'【人参果】','使用可获得半个月属性祝福，生命增加5000点，防御增加3500点，攻击增加3000点，魔攻增加3000点',4,2,1000,1,1,0),(138,'【神秘人参果】','使用可获得1个月属性祝福，生命增加10000点，防御增加7000点，攻击增加6000点，魔攻增加6000点',4,2,1000,1,1,0),(147,'〖属性之王〗','使用后可以永久增加HP60000，攻击35000，防御40000，魔攻30000',4,2,1000,1,1,1),(148,'〖西游之星〗','使用可获得西游之星称号！附带永久生命值88888点！限用一次！',4,2,1000,1,1,1),(151,'〖小富豪〗','使用可获得小富豪称号，生命永久增加58888！',4,2,1000,1,1,1),(152,'〖富豪〗','使用可获得富豪称号！生命永久增加88888！',4,2,1000,1,1,1),(155,'〖三千年蟠桃礼包〗','使用可获得20个〖三千年蟠桃〗！',4,6,1000,1,1,1),(156,'〖六千年蟠桃礼包〗','使用可获得8个〖六千年蟠桃〗！',4,8,1000,1,1,1),(157,'〖九千年蟠桃礼包〗','使用可获得5个〖九千年蟠桃〗！',4,10,1000,1,1,1),(158,'〖仙魂套装〗','打开可获得仙魂装备一套！',4,2,1000,1,1,1),(159,'【三千年蟠桃礼包】','打开可获得20个【三千年蟠桃】！',4,2,1000,1,1,0),(160,'【六千年蟠桃礼包】','打开可获得8【六千年蟠桃】！',4,2,1000,1,1,0),(161,'【九千年蟠桃礼包】','打开可获得5个【九千年蟠桃】！',4,2,1000,1,1,0),(162,'〖师门声望礼包〗','打开可获得20张相应师门的声望卷！',4,5,1000,1,1,1),(163,'〖宝象国声望礼包〗','打开可获得20张〖宝象国声望卷〗！',4,5,1000,1,1,1),(164,'〖天宫声望礼包〗','打开可获得20张〖天宫声望卷〗！',4,5,1000,1,1,1),(168,'〖地府声望礼包〗','打开可获得20张〖地府声望卷〗！',4,5,1000,1,1,1),(169,'〖傲来国声望礼包〗','打开可获得20张〖傲来国声望卷〗！',4,5,1000,1,1,1),(170,'〖乌鸡国声望礼包〗','打开可获得20张〖乌鸡国声望卷〗！',4,5,1000,1,1,1),(175,'〖仓库扩容卷〗','使用后增加仓库容量加1000',4,5,1000,1,1,1),(191,'云南白药（中捆）','使用可恢复5000体力！',5,2,1000,1,1,1),(192,'灵丹（小捆）','使用恢复1000内力！',5,2,1000,1,1,1),(193,'冰糖葫芦','使用恢复MP800点！',5,2,1000,1,1,1),(194,'云南白药（小捆）','使用恢复2500体力！',5,2,1000,1,1,1),(195,'红烧狗肉','使用可恢复HP220点！',5,2,1000,1,1,1),(196,'花雕酒','使用可恢复MP110点！',5,2,1000,1,1,1),(197,'素菜包','香喷喷的素菜包！使用可恢复HP250',5,2,1000,1,1,1),(198,'猪肉包','香喷喷的猪肉包！使用可恢复HP370',5,2,1000,1,1,1),(199,'神仙汤','使用可恢复HP500点！',5,2,1000,1,1,1),(200,'【保命丸】','使用可恢复150000体力!',5,2,1000,1,1,0),(201,'〖小生命丹〗','1级丹药，使用增加100HP，每人限用100个。住宅炼丹房炼制；金豆超市购买获得！',5,30,1000,1,1,1),(203,'〖中生命丹〗','3级丹药，使用增加500HP，每人限用100个。住宅炼丹房炼制；金豆超市购买获得！',5,2,1000,1,1,1),(204,'〖大生命丹〗','4级丹药，使用增加5000HP，每人限用100个。住宅炼丹房炼制；金豆超市购买获得！',5,2,1000,1,1,1),(205,'〖小积分丹〗','使用增加200HP， 每人限用100颗。消费积分奖励！',5,2,1000,1,1,1),(206,'〖积分体力丹〗','使用增加200HP， 每人限用100颗。消费积分奖励！',5,2,1000,1,1,1),(207,'〖积分中生命丹〗','使用增加300HP， 每人限用100颗。消费积分奖励！',5,2,1000,1,1,1),(208,'〖积分大生命丹〗','使用增加500HP， 每人限用100颗。消费积分奖励！',5,2,1000,1,1,1),(209,'〖积分超级体力丹〗','使用增加1000HP， 每人限用100颗。消费积分奖励！',5,2,1000,1,1,1),(210,'〖神秘体力丹〗','使用增加200HP，每人限用100个。金豆超市购买获得！',5,2,1000,1,1,1),(211,'〖冰火丹〗','使用增加100HP，每人限用100颗！',5,2,1000,1,1,1),(212,'〖鬼面丹〗','使用增加100HP，每人限用100颗！',5,2,1000,1,1,1),(213,'〖混世丹〗','使用增加100HP，每人限用100颗！',5,2,1000,1,1,1),(214,'〖金银丹〗','使用增加200HP，每人限用100颗！',5,2,1000,1,1,1),(215,'〖金兜丹〗','使用增加200HP，每人限用100颗！',5,2,1000,1,1,1),(216,'〖魔牛丹〗','使用增加200HP，每人限用100颗！',5,2,1000,1,1,1),(217,'〖凤仙丸〗','使用增加300HP，每人限用100颗！',5,2,1000,1,1,1),(218,'〖麒麟丹〗','使用增加100HP，每人限用100颗！',5,2,1000,1,1,1),(219,'〖玉华丸〗','使用增加300HP，每人限用100颗！',5,2,1000,1,1,1),(220,'〖金平丸〗','使用增加300HP，每人限用100颗！',5,2,1000,1,1,1),(221,'〖龙虎豹胎丸〗','使用增加100HP，每人限用100颗！',5,2,1000,1,1,1),(222,'〖血河丹〗','使用增加200HP，每人限用100颗！',5,2,1000,1,1,1),(223,'〖白巫丹〗','使用增加200HP，每人限用100颗！',5,2,1000,1,1,1),(224,'〖玲珑丹〗','使用增加500HP，每人限用100颗！',5,2,1000,1,1,1),(225,'〖朱紫丸〗','使用增加300HP，每人限用100颗！',5,2,1000,1,1,1),(226,'〖比丘丸〗','使用增加100HP，每人限用100颗！',5,2,1000,1,1,1),(227,'〖比丘丹〗','使用增加200HP，每人限用100颗！',5,2,1000,1,1,1),(228,'〖天法丸〗','使用增加200HP，每人限用100颗！',5,2,1000,1,1,1),(229,'〖天竺丸〗','使用增加500HP，每人限用100颗！',5,2,1000,1,1,1),(230,'【公测生命丹】','使用增加300HP，每人限用100颗！',5,2,1000,1,1,0),(231,'【公测攻击丹】','使用永久增加攻击120点！最多可使用100颗！',5,2,1000,1,1,0),(232,'【公测防御丹】','使用永久增加防御250点！最多可使用100颗！',5,2,1000,1,1,0),(233,'【公测魔攻丹】','使用永久增加魔攻120点！最多可使用100颗！',5,2,1000,1,1,0),(234,'【99级解封丹】','使用后可解封99级继续升级到109级！',5,2,1000,1,1,0),(235,'〖经验丹〗','使用可获得300万经验(每日限制10次)',5,2,1000,1,1,1),(236,'【小蟠桃】','天宫蟠桃园的蟠桃，使用后可获得35万经验。（每日限用10次）',5,2,1000,1,1,0),(237,'【蟠桃】','天宫蟠桃园的蟠桃，使用后可获得80万经验。（每日限用10次）',5,2,1000,1,1,0),(238,'【三千年蟠桃】','王母娘娘蟠桃大会上用的蟠桃，使用可增加300万经验！（每日限用10次）',5,2,1000,1,1,0),(239,'【六千年蟠桃】','王母娘娘蟠桃大会上用的蟠桃，使用可增加700万经验！（每日限用10次）',5,2,1000,1,1,0),(240,'【九千年蟠桃】','王母娘娘蟠桃大会上用的蟠桃，使用可增加1500万经验！（每日限用10次）',5,2,1000,1,1,0),(241,'〖三千年蟠桃〗','王母娘娘蟠桃大会上用的蟠桃，使用可增加300万经验！（每日限用10次）',5,2,1000,1,1,1),(242,'〖六千年蟠桃〗','王母娘娘蟠桃大会上用的蟠桃，使用可增加700万经验！（每日限用10次）',5,2,1000,1,1,1),(243,'〖九千年蟠桃〗','王母娘娘蟠桃大会上用的蟠桃，使用可增加1500万经验！（每日限用10次）',5,2,1000,1,1,1),(244,'灵丹','使用可恢复MP500点',5,2,1000,1,1,1),(245,'猕猴桃干','使用恢复HP3690点！',5,2,1000,1,1,1),(246,'云南白药','使用恢复HP1000点！',5,2,1000,1,1,1),(247,'清酒','使用后恢复MP80点',5,2,500,1,1,1),(248,'饭团','使用后可恢复HP100点',5,2,500,1,1,1),(249,'云南白药（大捆）','使用可恢复10000体力！',5,2,1000,1,1,1),(250,'云南白药（超大捆）','使用可恢复80000体力！',5,2,1000,1,1,1),(252,'船票','任务物品村长赠予的船票',6,2,1000,1,1,0),(253,'桂花酒','任务物品桂花酒',6,2,1000,1,1,0),(256,'村长的信','村长的介绍信',6,2,1000,1,1,0),(257,'动物碎齿','动物碎齿!',2,2,1000,1,1,1),(258,'仙露','任务物品请勿丢弃!',6,2,1,1,1,1),(260,'鹿茸（药引）','任务物品请勿丢弃!',6,2,1,1,1,1),(262,'活鲤鱼','任务物品请勿丢弃!',6,2,1,1,1,1),(263,'包袱','任务物品请勿丢弃!',6,2,1,1,1,1),(264,'耳坠珠子','任务物品请勿丢弃!',6,2,1,1,1,1),(265,'闪光磷粉','任务物品请勿丢弃!',6,2,1,1,1,1),(266,'〖玄铁令〗','用于建立国家的重要信物',4,2,1000,1,1,1),(276,'〖铁宝箱〗','打开箱子可随机获得物品（需要万能钥匙开启）',8,2,1000,1,1,1),(278,'〖银宝箱〗','打开箱子可随机获得物品（需要万能钥匙开启）',8,2,1000,1,1,1),(302,'〖打孔器〗','此物品可为装备打造第一个孔（可在长安城兵器铺找装备锻造商进行使用）',2,1,1000,1,1,1),(303,'〖普通打孔器〗','此物品可为装备打造第二个孔（可在长安城兵器铺找装备锻造商进行使用）',2,2,1000,1,1,1),(304,'〖高级打孔器〗','此物品可为装备打造第三个孔（可在长安城兵器铺找装备锻造商进行使用）',2,3,1000,1,1,1),(305,'〖强化打孔器〗','此物品可为装备打造第四个孔（可在长安城兵器铺找装备锻造商进行使用）',2,5,1000,1,1,1),(306,'〖究极打孔器〗','此物品可为装备打造第五个孔（可在长安城兵器铺找装备锻造商进行使用）',2,10,1000,1,1,1),(307,'大幸运草','可以为装备打孔或者装备升星提示10%的成功率，锻造装备必备！（直接在身上装备升级消耗）',4,3,1000,1,1,1),(308,'〖铁魂〗','升星装备的材料之铁魂（可在长安城兵器铺找装备锻造商进行使用）',2,2,1000,1,1,1),(309,'〖铜魂〗','升星装备的材料之铜魂（可在长安城兵器铺找装备锻造商进行使用）',2,2,1000,1,1,1),(310,'〖银魂〗','升星装备的材料之银魂（可在长安城兵器铺找装备锻造商进行使用）',2,2,1000,1,1,1),(311,'〖金魂〗','升星装备的材料之铁魂（可在长安城兵器铺找装备锻造商进行使用）',2,2,1000,1,1,1),(312,'〖钻魂〗','升星装备的材料之钻魂（可在长安城兵器铺找装备锻造商进行使用）',2,2,1000,1,1,1),(313,'〖陨魂〗','升星装备的材料之铁魂（可在长安城兵器铺找装备锻造商进行使用）',2,2,1000,1,1,1),(314,'〖铁星升星符〗','拥有这强大的力量的符咒，可将百分之百将铁星的装备升星成功！（可在长安城兵器铺找装备锻造商进行使用）',4,2,1000,1,1,1),(315,'〖铜星升星符〗','拥有这强大的力量的符咒，可将百分之百将铜星的装备升星成功！（可在长安城兵器铺找装备锻造商进行使用）',4,5,1000,1,1,1),(316,'〖银星升星符〗','拥有这强大的力量的符咒，可将百分之百将银星的装备升星成功！（可在长安城兵器铺找装备锻造商进行使用）',4,10,1000,1,1,1),(317,'〖金星升星符〗','拥有这强大的力量的符咒，可将百分之百将金星的装备升星成功！（可在长安城兵器铺找装备锻造商进行使用）',4,20,1000,1,1,1),(318,'〖钻星升星符〗','拥有这强大的力量的符咒，可将百分之百将钻星的装备升星成功！（可在长安城兵器铺找装备锻造商进行使用）',4,60,1000,1,1,1),(319,'〖陨星升星符〗','拥有这强大的力量的符咒，可将百分之百将陨星的装备升星成功！（可在长安城兵器铺找装备锻造商进行使用）',4,200,1000,1,1,1),(320,'【幻想武器包】','打开可获得相应职业绝版武器一把！',4,2,1000,1,1,0),(321,'【幻想防具包】','打开可获得相应职业绝版衣服头盔鞋子！',4,2,1000,1,1,0),(322,'【幻想首饰包】','打开可获得相应职业绝版项链和手镯！',4,2,1000,1,1,0),(323,'〖雷皇套装〗','打开可获得雷皇装备一套',4,2,1000,1,1,1),(324,'〖小巨灵套装〗','打开可获得小巨灵装备一套',4,2,1000,1,1,1),(325,'〖玄冰套装〗','打开可获得玄冰装备一套',4,2,1000,1,1,1),(326,'〖仙魂套装〗','打开可获得仙魂装备一套',4,2,1000,1,1,1),(327,'螃蟹肉','美味可口的螃蟹肉',2,2,1000,1,1,1),(328,'海贼头巾','看上去有点破旧的头巾',2,2,1000,1,1,1),(329,'鳅鱼皮','鳅鱼精身上的皮甲',2,2,1000,1,1,1),(330,'赤背虾皮','赤背虾精身上的皮甲',2,2,1000,1,1,1),(331,'〖百年魔珠〗','妖魔修炼百年的魔珠',2,2,1000,1,1,1),(332,'皮皮虾','虾兵身上的宝贝',2,2,1000,1,1,1),(333,'大炸蟹','看上去美味可口',2,2,1000,1,1,1),(334,'巨鳌肉','看上去美味可口',2,2,1000,1,1,1),(335,'鲨鱼肉','看上去美味可口',2,2,1000,1,1,1),(336,'桂花枝','桂花树上的树枝',2,2,1000,1,1,1),(337,'杏花果','杏花树上的果实',2,2,1000,1,1,1),(338,'狼皮','老狼的皮毛',2,2,1000,1,1,1),(339,'西瓜籽','西瓜精掉落的西瓜籽',2,2,1000,1,1,1),(340,'竹子','细细长长的竹子',2,2,1000,1,1,1),(341,'蛇胆','青蛇怪的蛇胆',2,2,1000,1,1,1),(342,'黄雀羽毛','黄雀的羽毛',2,2,1000,1,1,1),(343,'磷粉','闪闪发光的磷粉',2,2,1000,1,1,1),(344,'兔毛','野兔的毛',2,2,1000,1,1,1),(345,'兔皮','野兔的皮',2,2,1000,1,1,1),(346,'野狼肉','野狼的肉',2,2,1000,1,1,1),(347,'山猪皮','山猪的皮甲',2,2,1000,1,1,1),(348,'灯芯','快要熄灭的灯芯',2,2,1000,1,1,1),(349,'扫帚','仿佛能看的它过去的凶残',2,2,1000,1,1,1),(350,'灯笼','红红的大灯笼',2,2,1000,1,1,1),(351,'蜡烛','好像快要熄灭了',2,2,1000,1,1,1),(352,'马刀兵俑泥人','马刀兵俑的原型',2,2,1000,1,1,1),(353,'长矛兵俑泥人','长矛兵俑的原型',2,2,1000,1,1,1),(354,'宣纸','普普通通的宣纸',2,2,1000,1,1,1),(355,'油墨','黑死的油墨',2,2,1000,1,1,1),(356,'银色星辰','天兵银色星辰',2,2,1000,1,1,1),(357,'金色星辰','天将银色星辰',2,2,1000,1,1,1),(358,'花粉','仙灵蝴蝶的花粉',2,2,1000,1,1,1),(359,'游荡魂魄','游荡妖魂最后的一丝魂魄',2,2,1000,1,1,1),(360,'蟠璃','蟠璃材料',2,2,1000,1,1,1),(361,'蟠龙','蟠龙材料',2,2,1000,1,1,1),(362,'花斑虎皮','花斑虎的皮甲',2,2,1000,1,1,1),(363,'鹿皮','野鹿的皮甲',2,2,1000,1,1,1),(364,'鹿角','野鹿的角',2,2,1000,1,1,1),(365,'熊胆','野熊的熊胆',2,2,1000,1,1,1),(366,'熊掌','野熊的熊掌',2,2,1000,1,1,1),(367,'山妖皮','野山妖皮',2,2,1000,1,1,1),(368,'大头骨','骷髅怪的头颅',2,2,1000,1,1,1),(369,'腐尸皮','腐尸怪的皮甲',2,2,1000,1,1,1),(370,'僵尸皮','僵尸怪的皮甲',2,2,1000,1,1,1),(371,'豹皮','豹妖的皮甲',2,2,1000,1,1,1),(372,'猫皮','猫妖的皮甲',2,2,1000,1,1,1),(373,'羚羊角','羚羊怪的角',2,2,1000,1,1,1),(374,'花鹿角','花鹿怪的角',2,2,1000,1,1,1),(375,'狐狸皮','狐狸精的皮甲',2,2,1000,1,1,1),(376,'野獾皮','野獾精的皮甲',2,2,1000,1,1,1),(378,'桃皮','桃妖的树皮',2,2,1000,1,1,1),(379,'雪球','圆圆的雪球',2,2,1000,1,1,1),(380,'雪莲','雪莲精的雪莲',2,2,1000,1,1,1),(381,'雪豹肉','雪豹的肉',2,2,1000,1,1,1),(382,'雪狼肉','雪狼的肉',2,2,1000,1,1,1),(383,'紫竹根','紫竹战士的根',2,2,1000,1,1,1),(384,'孤魂魄','孤魂的魂魄',2,2,1000,1,1,1),(385,'厉鬼魂','厉鬼的魂魄',2,2,1000,1,1,1),(386,'佛珠','冰晶塔掉落的佛珠',2,2,1000,1,1,1),(387,'牛角','一个普通的牛角',2,2,1000,1,1,1),(389,'芭蕉','芭蕉怪身上的芭蕉',2,2,1000,1,1,1),(390,'蜘蛛网','人面蛛妖的蜘蛛网',2,2,1000,1,1,1),(391,'麒麟肉','麒麟的肉',2,2,1000,1,1,1),(392,'惨白树皮','惨白树精的皮',2,2,1000,1,1,1),(393,'疯狂树皮','疯狂树精的皮',2,2,1000,1,1,1),(394,'【英雄牌】','通过完成各大副本所得的奖励，可在长安城英雄大厅兑换奖励',4,2,1000,1,1,0),(395,'〖储物袋〗','大小遗迹储物容量增加5,最多扩容15,在遗迹内使用',4,2,1000,1,1,1),(396,'〖豪宅优惠券〗','使用金豆在开封广场购买房子时会获得一定的优惠',4,2,1000,1,1,1),(397,'〖求婚玫瑰〗','赠人玫瑰收留余香，在月老处使用，可向自己心仪的玩家进行求婚',4,1,1000,1,1,1),(398,'〖小智慧果〗','使用后可获得60分钟的杀怪双倍经验',4,2,1000,1,1,1),(399,'〖大智慧果〗','使用后可获得60分钟的杀怪四倍经验',4,5,1000,1,1,1),(400,'〖背包扩容卷〗','使用后可增加背包容量1000',4,5,1000,1,1,1),(401,'〖万能钥匙〗','用于开启铜铁银金宝箱的钥匙',4,5,1000,1,1,1),(402,'【内测福利】','GM精心为大家准备的的小小礼物',4,5,1000,1,1,0),(403,'〖元旦宝箱〗','元旦节日宝箱(传说能开出各种宝贝绝对超值)',8,5,1000,1,1,1),(404,'【元】','元旦节日-【元】字(凑齐元旦快乐可以在元旦大使那里兑换〖元旦宝箱〗哦)',2,5,1000,1,1,0),(405,'【旦】','元旦节日-【旦】字(凑齐元旦快乐可以在元旦大使那里兑换〖元旦宝箱〗哦)',2,5,1000,1,1,0),(406,'【快】','元旦节日-【快】字(凑齐元旦快乐可以在元旦大使那里兑换〖元旦宝箱〗哦)',2,5,1000,1,1,0),(407,'【乐】','元旦节日-【乐】字(凑齐元旦快乐可以在元旦大使那里兑换〖元旦宝箱〗哦)',2,5,1000,1,1,0),(408,'〖元旦节日勋章〗','〖元旦节日勋章〗(可以在元旦大使那里兑换【元】【旦】【快】【乐】任意一个)',4,8,1000,1,1,1),(409,'【副本重置令】','vip每日的专属令牌用于各大副本重置无须再等待',4,5,1000,1,1,0),(410,'【GM的小内裤】','【GM的小内裤】(WHAT!?我没有看错吧?这居然GM的内裤到被爆出来了,GM太没节操了,暖冬活动限定可用于兑换积分,当然也可留做当纪念)',2,8,1000,1,1,0),(411,'〖暖〗','暖冬活动限定-〖暖〗字(凑齐-暖冬祝福每样五个可兑换暖冬积分参与暖冬大比拼)',2,8,1000,1,1,1),(412,'〖冬〗','暖冬活动限定-〖冬〗字(凑齐-暖冬祝福每样五个可兑换暖冬积分参与暖冬大比拼)',2,8,1000,1,1,1),(413,'〖祝〗','暖冬活动限定-〖祝〗字(凑齐-暖冬祝福每样五个可兑换暖冬积分参与暖冬大比拼)',2,8,1000,1,1,1),(414,'〖福〗','暖冬活动限定-〖福〗字(凑齐-暖冬祝福每样五个可兑换暖冬积分参与暖冬大比拼)',2,8,1000,1,1,1),(415,'【五角碎片】','【五角碎片】(GM每个月总有那么一次的大放血还不死的神奇生物凑齐20个可以兑换【五角兑换卷】也可以兑换成暖冬积分)',4,8,1000,1,1,0),(416,'【一元碎片】','【一元碎片】(GM每个月总有那么一次的大放血还不死的神奇生物凑齐20个可以兑换【一元兑换卷】也可以兑换成暖冬积分)',4,8,1000,1,1,0),(417,'【两元碎片】','【两元碎片】(GM每个月总有那么一次的大放血还不死的神奇生物凑齐20个可以兑换【两元兑换卷】也可以兑换成暖冬积分)',4,8,1000,1,1,0),(418,'【五角兑换卷】','【五角兑换卷】(GM每个月总有那么一次的大放血还不死的神奇生物快去放GM的血吧)',4,8,1000,1,1,0),(419,'【一元兑换卷】','【一元兑换卷】(GM每个月总有那么一次的大放血还不死的神奇生物快去放GM的血吧)',4,8,1000,1,1,0),(420,'【两元兑换卷】','【两元兑换卷】(GM每个月总有那么一次的大放血还不死的神奇生物快去放GM的血吧)',4,8,1000,1,1,0),(421,'〖暖冬宝箱〗','〖暖冬宝箱〗(在寒冷的冬季不再冷,为大家送上暖冬宝箱)',8,8,1000,1,1,1),(422,'〖1千法宝经验卷轴〗','使用后可获得1000法宝经验',1,8,1000,40,1,1),(423,'〖1万法宝经验卷轴〗','使用后可获得1万法宝经验',1,2,1000,40,1,1),(424,'〖10万法宝经验卷轴〗','使用后可获得10万法宝经验',1,20,1000,40,1,1),(425,'〖100万法宝经验卷轴〗','使用后可获得100万法宝经验',1,8,1000,40,1,1),(426,'〖魔化石〗','用于坐骑升级打造的必备物品',2,1,1000,1,1,1),(427,'〖1万西游声望卷轴〗','使用后可获得1万西声望',1,10,1000,1,1,1),(428,'〖风度偏偏〗','使用后可以永久增加HP24000，攻击45000，防御25000，魔攻45000',4,10,1000,1,1,1),(429,'〖至尊战神〗','使用后可以永久增加HP14000，攻击35000，防御15000，魔攻15000',4,10,1000,1,1,1),(430,'〖谁与争峰〗','使用后可以永久增加HP14000，攻击15000，防御15000，魔攻15000',4,10,1000,1,1,1),(431,'〖永不放弃〗','使用后可以永久增加HP24000，攻击25000，防御25000，魔攻25000',4,10,1000,1,1,1),(432,'〖威震幻影〗','使用后可以永久增加HP50000，攻击45000，防御45000，魔攻45000',4,10,1000,1,1,1),(433,'【新】','暖冬活动限定-【新】字(凑齐-新年快乐可在玄武大街找新年大使兑换新年宝箱)',2,10,1000,1,1,0),(434,'【年】','暖冬活动限定-【年】字(凑齐-新年快乐可在玄武大街找新年大使兑换新年宝箱)',2,10,1000,1,1,0),(435,'【快】','暖冬活动限定-【快】字(凑齐-新年快乐可在玄武大街找新年大使兑换新年宝箱)',2,10,1000,1,1,0),(436,'【乐】','暖冬活动限定-【乐】字(凑齐-新年快乐可在玄武大街找新年大使兑换新年宝箱)',2,10,1000,1,1,0),(437,'【新年宝箱】','携手共度2018年【新年宝箱】(可开出大量属性丹药)',8,10,1000,1,1,0),(438,'【新年卡片】','携手共度2018年【新年卡片】(可开使用此卡片兑换超值的2018新年称号)',2,10,1000,1,1,0),(439,'【新年攻击丹】','携手共度2018年【新年攻击丹】(增加攻击300点,限服100个)',5,10,1000,1,1,0),(440,'【新年魔攻丹】','携手共度2018年【新年魔攻丹】(增加魔攻300点,限服100个)',5,10,1000,1,1,0),(441,'【新年防御丹】','携手共度2018年【新年防御丹】(增加防御180点,限服100个)',5,10,1000,1,1,0),(442,'【新年气血丹】','携手共度2018年【新年气血丹】(增加血量888点,限服100个)',5,10,1000,1,1,0),(443,'【恶魔广场门票】','传送至恶魔广场的门票【恶魔广场门票】',1,10,1000,1,1,0),(444,'【年糕】','携手共度2018年【年糕】(用五个年糕在十字街头喂养每天10:00和20:00出现的年兽)',5,10,1000,1,1,0),(445,'〖2018新年狂人〗','使用后可以永久增加HP88888，攻击50000，防御40000，魔攻50000',4,10,1000,1,1,1),(446,'〖2018新年红包〗','使用后可以开出1-10元的红包可找母鸡妈妈兑换红包',4,10,1000,1,1,1),(447,'〖2018一元红包〗','可找母鸡妈妈兑换红包',4,10,1000,1,1,1),(448,'〖2018两元红包〗','可找母鸡妈妈兑换红包',4,10,1000,1,1,1),(449,'〖2018三元红包〗','可找母鸡妈妈兑换红包',4,10,1000,1,1,1),(450,'〖2018五元红包〗','可找母鸡妈妈兑换红包',4,10,1000,1,1,1),(451,'〖2018十元红包〗','可找母鸡妈妈兑换红包',4,10,1000,1,1,1),(452,'【恶魔血】','恶魔广场掉落（可在恶魔广场兑换恶魔声望）',2,10,1000,1,1,0),(453,'〖财宝箱〗','装有满满的2000万银两，瞬间成为高富帅，迎娶白富美',8,5,1000,1,1,1),(454,'〖双倍掉宝符〗','使用后获得10分钟双倍美滋滋的掉率（同类祝福不叠加按最好的掉宝算）',4,5,1000,1,1,1),(455,'〖四倍掉宝符〗','使用后获得10分钟四倍美滋滋的掉率（同类祝福不叠加按最好的掉宝算）',4,5,1000,1,1,1),(456,'〖八倍掉宝符〗','使用后获得10分钟八倍美滋滋的掉率（同类祝福不叠加按最好的掉宝算）',4,10,1000,1,1,1),(457,'〖极品6位ID号（111111）靓号卡〗','使用后ID变更为111111，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(458,'〖极品6位ID号（222222）靓号卡〗','使用后ID变更为222222，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(459,'〖极品6位ID号（333333）靓号卡〗','使用后ID变更为333333，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(460,'〖极品6位ID号（444444）靓号卡〗','使用后ID变更为444444，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(461,'〖极品6位ID号（555555）靓号卡〗','使用后ID变更为555555，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(462,'〖极品6位ID号（666666）靓号卡〗','使用后ID变更为666666，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(463,'〖极品6位ID号（777777）靓号卡〗','使用后ID变更为777777，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(464,'〖极品6位ID号（888888）靓号卡〗','使用后ID变更为888888，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(465,'〖极品6位ID号（999999）靓号卡〗','使用后ID变更为999999，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(466,'〖极品6位ID号（123456）靓号卡〗','使用后ID变更为123456，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(467,'〖极品6位ID号（654321）靓号卡〗','使用后ID变更为654321，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(468,'〖极品6位ID号（520520）靓号卡〗','使用后ID变更为520520，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(469,'〖极品6位ID号（122222）靓号卡〗','使用后ID变更为122222，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(470,'〖极品6位ID号（133333）靓号卡〗','使用后ID变更为133333，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(471,'〖极品6位ID号（144444）靓号卡〗','使用后ID变更为144444，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(472,'〖极品6位ID号（155555）靓号卡〗','使用后ID变更为155555，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(473,'〖极品6位ID号（166666）靓号卡〗','使用后ID变更为166666，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(474,'〖极品6位ID号（177777）靓号卡〗','使用后ID变更为177777，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(475,'〖极品6位ID号（188888）靓号卡〗','使用后ID变更为188888，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(476,'〖极品6位ID号（199999）靓号卡〗','使用后ID变更为199999，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(487,'〖大号财宝箱〗','装有满满的2亿银两，瞬间成为高富帅，迎娶白富美',8,45,1000,1,1,1),(488,'【宠物岛门票】','通往宠物岛的门票（需要前往天宫找宠物岛传送员使用）',1,1,1000,1,1,0),(489,'【西游宣传礼包】','每日推广游戏宣传获得',4,1,1000,1,1,0),(490,'【西游邀请礼包】','每次邀请一人即可获得该礼包',4,1,1000,1,1,0),(491,'【西游新人礼包】','仅限制于被邀请新来的玩家福利，永久只发放一次',4,1,1000,1,1,0),(492,'【公测礼包】','所有公测玩家的福利，绝对超值',4,1,1000,1,1,0),(493,'〖瞌睡虫〗（典藏版）','〖瞌睡虫〗宠物一只充值消费获得，绝对超值',4,1,1000,1,1,1),(494,'〖荣誉宝石包〗（2个）','打开后获得〖荣誉宝石〗x2',4,1,1000,1,1,1),(495,'〖荣誉宝石包〗（15个）','打开后获得〖荣誉宝石〗x5',4,1,1000,1,1,1),(496,'〖荣誉宝石包〗（15个）','打开后获得〖荣誉宝石〗x5',4,1,1000,1,1,1),(497,'〖荣誉宝石包〗（40个）','打开后获得〖荣誉宝石〗x40',4,1,1000,1,1,1),(498,'〖荣誉宝石包〗（100个）','打开后获得〖荣誉宝石〗x100',4,1,1000,1,1,1),(499,'〖冲榜助力包〗','打开后获得〖钻魂〗x100，外加赠送大幸运草一根',4,20,1000,1,1,1),(500,'【才子印记】','【才子印记】暑期假日清凉一夏获得',6,20,1000,1,1,0),(501,'【才子印记】（碎片）','【才子印记】（碎片）凑足二十个可换【才子印记】',6,20,1000,1,1,0),(502,'【单彩贝壳】','【单彩贝壳】活动获得可随机开出以外惊喜哦（必得学分）',6,20,1000,1,1,0),(503,'【三彩贝壳】','【三彩贝壳】活动获得可随机开出以外惊喜哦（必得学分）',6,20,1000,1,1,0),(504,'【五彩贝壳】','【五彩贝壳】活动获得可随机开出以外惊喜哦（必得学分）',6,20,1000,1,1,0),(505,'【七彩贝壳】','【七彩贝壳】活动获得可随机开出以外惊喜哦（必得学分）',6,20,1000,1,1,0),(506,'【比翼图纸】','【比翼图纸】可以打造【比翼双飞の婚戒】（典藏版）或者【比翼双飞の婚链】（典藏版）',6,20,1000,1,1,0),(507,'〖武文双全〗','使用后可以永久增加HP50000，攻击35000，防御35000，魔攻35000',4,10,1000,1,1,1),(508,'〖文状元〗','使用后可以永久增加HP40000，攻击25000，防御25000，魔攻25000',4,10,1000,1,1,1),(509,'〖三好学生〗','使用后可以永久增加HP30000，攻击10000，防御10000，魔攻10000',4,10,1000,1,1,1),(510,'〖金符碎片〗','〖金符碎片〗+〖金魂〗+银两可在朱雀大街符咒大师处锻造成为成品（但并非一定成功哦）',2,10,1000,1,1,1),(511,'〖钻符碎片〗','〖钻符碎片〗+〖钻魂〗+银两可在朱雀大街符咒大师处锻造成为成品（但并非一定成功哦）',2,10,1000,1,1,1),(512,'〖陨符碎片〗','〖陨符碎片〗+〖陨魂〗+银两可在朱雀大街符咒大师处锻造成为成品（但并非一定成功哦）',2,10,1000,1,1,1),(513,'〖银符碎片〗','〖银符碎片〗+〖银魂〗+银两可在朱雀大街符咒大师处锻造成为成品（但并非一定成功哦）',2,10,1000,1,1,1),(514,'〖黄金贵族宝箱〗','〖黄金贵族宝箱〗开通黄金贵族的玩家每日领取获得',8,10,1000,1,1,1),(515,'〖铂金贵族宝箱〗','〖铂金贵族宝箱〗开通铂金贵族的玩家每日领取获得',8,10,1000,1,1,1),(516,'〖钻石皇族宝箱〗','〖钻石皇族宝箱〗开通钻石皇族的玩家每日领取获得',8,10,1000,1,1,1),(517,'〖至尊皇族宝箱〗','〖至尊皇族宝箱〗开通至尊皇族的玩家每日领取获得',8,10,1000,1,1,1),(518,'〖黄金贵族卡〗','使用后可获得黄金贵族的尊贵身份并且领取30次对应福利（每日1次），具体奖励看福利页面',4,10,1000,1,1,1),(519,'〖铂金贵族卡〗','使用后可获得黄铂金族的尊贵身份并且领取30次对应福利（每日1次），具体奖励看福利页面',4,10,1000,1,1,1),(520,'〖钻石皇族卡〗','使用后可获得钻石皇族的尊贵身份并且领取30次对应福利（每日1次），具体奖励看福利页面',4,10,1000,1,1,1),(521,'〖至尊皇族卡〗','使用后可获得尊皇族的尊贵身份并且领取30次对应福利（每日1次），具体奖励看福利页面',4,10,1000,1,1,1),(522,'【保命丸】','使用可恢复50万体力!',5,2,1000,1,1,0),(523,'【小保命丸】','使用可恢复100万体力!',5,2,1000,1,1,0),(524,'【中保命丸】','使用可恢复200万体力!',5,2,1000,1,1,0),(525,'【大保命丸】','使用可恢复500万体力!',5,2,1000,1,1,0),(526,'【超保命丸】','使用可恢复800万体力!',5,2,1000,1,1,0),(527,'【极品保命丸】','使用可恢复1500万体力!',5,2,1000,1,1,0),(528,'【灵品保命丸】','使用可恢复3000万体力!',5,2,1000,1,1,0),(529,'【仙品保命丸】','使用可恢复5000万体力!',5,2,1000,1,1,0),(530,'【神品保命丸】','使用可恢复7000万体力!',5,2,1000,1,1,0),(531,'【圣品保命丸】','使用可恢复1亿体力!',5,2,1000,1,1,0),(532,'〖冰晶丹〗','使用永久增加攻击120点！最多可使用100颗！',5,2,1000,1,1,1),(533,'〖花果丹〗','使用永久增加魔攻120点！最多可使用100颗！',5,2,1000,1,1,1),(534,'〖瑶池丹〗','使用永久增加防御200点！最多可使用100颗！',5,2,1000,1,1,1),(535,'〖老君丹〗','使用永久增加血量500点！最多可使用100颗！',5,2,1000,1,1,1),(536,'〖金刚经〗','使用永久增加攻击300点！最多可使用100颗！',5,2,1000,1,1,1),(537,'〖法华经〗','使用永久增加魔攻300点！最多可使用100颗！',5,2,1000,1,1,1),(538,'〖地藏经〗','使用永久增加防御500点！最多可使用100颗！',5,2,1000,1,1,1),(539,'〖严华经〗','使用永久增加血量1000点！最多可使用100颗！',5,2,1000,1,1,1),(540,'〖莲花金丹〗','使用永久增加攻击500点！最多可使用100颗！',5,2,1000,1,1,1),(541,'〖黑龙金丹〗','使用永久增加魔攻500点！最多可使用100颗！',5,2,1000,1,1,1),(542,'〖修炼攻击仙丹〗','使用永久增加攻击600点！最多可使用100颗！',5,2,1000,1,1,1),(543,'〖修炼魔攻仙丹〗','使用永久增加魔攻600点！最多可使用100颗！',5,2,1000,1,1,1),(544,'〖修炼防御仙丹〗','使用永久增加防御600点！最多可使用100颗！',5,2,1000,1,1,1),(545,'〖修炼生命仙丹〗','使用永久增加血量1000点！最多可使用100颗！',5,2,1000,1,1,1),(546,'〖攻之龙丹〗','使用永久增加攻击1000点！最多可使用100颗！',5,2,1000,1,1,1),(547,'〖魔之龙丹〗','使用永久增加魔攻1000点！最多可使用100颗！',5,2,1000,1,1,1),(548,'〖防之龙丹〗','使用永久增加防御1000点！最多可使用100颗！',5,2,1000,1,1,1),(549,'〖血之龙丹〗','使用永久增加血量3000点！最多可使用100颗！',5,2,1000,1,1,1),(550,'〖装备图纸〗（宠物）','升级宠物装备的必备图纸，无法直接使用请在宠物装备栏升级消耗',2,2,1000,1,1,1),(551,'〖女神之恋〗','使用后可以永久增加HP50000，攻击50000，防御50000，魔攻50000',4,2,1000,1,1,1),(552,'〖全服公敌〗','使用后可以永久增加HP100000，攻击100000，防御100000，魔攻100000',4,2,1000,1,1,1),(553,'〖至尊天圣〗','使用后可以永久增加HP60000，攻击60000，防御60000，魔攻60000',4,2,1000,1,1,1),(554,'〖一掷千金〗','使用后可以永久增加HP100000，攻击100000，防御100000，魔攻100000',4,2,1000,1,1,1),(555,'〖至尊红颜〗','使用后可以永久增加HP88888，攻击88888，防御88888，魔攻88888',4,2,1000,1,1,1),(556,'〖望门贵族〗','使用后可以永久增加HP66666，攻击66666，防御66666，魔攻66666',4,2,1000,1,1,1),(557,'〖倾城伊人〗','使用后可以永久增加HP50000，攻击50000，防御50000，魔攻50000',4,2,1000,1,1,1),(558,'【清】','【清】2018暑期活动获得，凑齐四字可在玄武大街找三藏兑换【清凉宝箱】哦',6,2,1000,1,1,0),(559,'【凉】','【凉】2018暑期活动获得，凑齐四字可在玄武大街找三藏兑换【清凉宝箱】哦',6,2,1000,1,1,0),(560,'【一】','【一】2018暑期活动获得，凑齐四字可在玄武大街找三藏兑换【清凉宝箱】哦',6,2,1000,1,1,0),(561,'【夏】','【夏】2018暑期活动获得，凑齐四字可在玄武大街找三藏兑换【清凉宝箱】哦',6,2,1000,1,1,0),(562,'【清凉宝箱】','【清凉宝箱】可随机获得1万西游声望卷或者1万法宝经验卷',8,2,1000,1,1,0),(563,'〖万能字〗','〖万能字〗可在玄武大街找三藏兑换任意字体哦哦',6,2,1000,1,1,1),(564,'【1万西游声望卷轴】','使用后可获得1万西声望',1,10,1000,1,1,0),(565,'【1万法宝经验卷轴】','使用后可获得1万法宝经验',1,2,1000,40,1,0),(566,'〖冠军宝石包〗（1个）','打开后获得〖冠军宝石〗x1',4,1,1000,1,1,1),(567,'〖冠军宝石包〗（3个）','打开后获得〖冠军宝石〗x3',4,1,1000,1,1,1),(568,'〖冠军宝石包〗（8个）','打开后获得〖冠军宝石〗x8',4,1,1000,1,1,1),(569,'〖冠军宝石包〗（30个）','打开后获得〖冠军宝石〗x30',4,1,1000,1,1,1),(570,'〖齐天大圣〗（宠物蛋）','通天塔20层齐天大圣掉落或者凑齐〖大圣精魄〗兑换',4,1,1000,1,1,1),(571,'〖大圣精魄〗','传说凑齐大圣精魄能够复活〖齐天大圣〗',4,1,1000,1,1,1),(572,'〖百年魔珠〗（小袋）','打开后可获得〖百年魔珠〗x1000',2,1,1000,1,1,1),(573,'〖百年魔珠〗（中袋）','打开后可获得〖百年魔珠〗x5000',2,1,1000,1,1,1),(574,'〖百年魔珠〗（大袋）','打开后可获得〖百年魔珠〗x10000',2,1,1000,1,1,1),(575,'【恶魔符文】','可在恶魔广场兑换恶魔声望',2,1,1000,1,1,0),(576,'【恶魔入场卷】','可在恶魔广场兑换恶魔声望',1,1,1000,1,1,0),(577,'〖圣灵锻造图纸〗','锻造圣灵装备的图纸',2,10,1000,1,1,1),(578,'【昊天神丹】','使用后可解封159等级',6,1,1000,159,1,0),(579,'〖探险符〗','〖探险符〗金银山探险获得可以兑换超值的物品哦',2,1,1000,1,1,1),(580,'〖天下至尊〗','使用后可以永久增加HP200000，攻击200000，防御200000，魔攻200000',4,2,1000,1,1,1),(581,'〖蓬莱至尊〗','使用后可以永久增加HP150000，攻击150000，防御150000，魔攻150000',4,2,1000,1,1,1),(582,'〖昆仑至尊〗','使用后可以永久增加HP100000，攻击100000，防御100000，魔攻100000',4,2,1000,1,1,1),(583,'〖名动天下〗','使用后可以永久增加HP150000，攻击150000，防御150000，魔攻150000',4,2,1000,1,1,1),(584,'〖万法不侵〗','使用后可以永久增加HP100000，攻击100000，防御100000，魔攻100000',4,2,1000,1,1,1),(585,'〖乾坤唯仙〗','使用后可以永久增加HP100000，攻击100000，防御100000，魔攻100000',4,2,1000,1,1,1),(586,'〖舞星仙姬〗','使用后可以永久增加HP100000，攻击100000，防御100000，魔攻100000',4,2,1000,1,1,1),(587,'〖王者宝石包〗（1个）','打开后获得〖王者宝石〗x1',4,1,1000,1,1,1),(588,'〖王者宝石包〗（3个）','打开后获得〖王者宝石〗x3',4,1,1000,1,1,1),(589,'〖王者宝石包〗（8个）','打开后获得〖王者宝石〗x8',4,1,1000,1,1,1),(590,'〖王者宝石包〗（30个）','打开后获得〖王者宝石〗x30',4,1,1000,1,1,1),(591,'【喜鹊蛋】','活动产出【喜鹊蛋】可在牛郎出孵化小喜鹊',6,1,1000,1,1,0),(592,'【小喜鹊】','每只【小喜鹊】都代表着牛郎与织女浓浓的爱情故事！！',6,1,1000,1,1,0),(593,'〖诛仙令〗','拥有此诛仙令可随机开出诛仙任意位置装备包一件',4,1000,1000,159,1,1),(594,'〖诛仙武器令〗','能够开出对应职业的诛仙武器一件',4,1000,1000,159,1,1),(595,'〖诛仙盔甲令〗','能够开出诛仙盔甲一件',4,1000,1000,159,1,1),(596,'〖诛仙头盔令〗','能够开出诛仙头盔一件',4,1000,1000,159,1,1),(597,'〖诛仙鞋子令〗','能够开出诛仙鞋子一件',4,1000,1000,159,1,1),(598,'〖诛仙项链令〗','能够开出诛仙项链一件',4,1000,1000,159,1,1),(599,'〖诛仙手镯令〗','能够开出诛仙手镯一件',4,1000,1000,159,1,1),(600,'【喜鹊令】','受到牛郎与织女的祝福（可将159典藏升级到179典藏）',4,1000,1000,159,1,0),(601,'〖玄天残叶〗','〖玄天残叶〗升级139坐骑仙兽必备材料',2,20,1000,1,1,1),(602,'〖神兽仙魄〗','〖神兽仙魄〗升级139坐骑必备材料',2,20,1000,1,1,1),(603,'〖祥云残片〗','〖祥云残片〗升级159坐骑仙兽必备材料',2,20,1000,1,1,1),(604,'〖大圣仙魄〗','〖大圣仙魄〗升级159坐骑仙兽必备材料',2,20,1000,1,1,1),(605,'〖灵匣宝盒〗','〖灵匣宝盒〗能开出许多意外的惊喜哟',8,20,1000,1,1,1),(606,'〖神匣宝盒〗','〖神匣宝盒〗能开出许多意外的惊喜哟',8,20,1000,1,1,1),(607,'〖月光宝盒〗','〖月光宝盒〗穿梭未来和过去，受到紫霞仙子的青睐后方才可开启',8,20,1000,1,1,1),(608,'〖宝盒钥匙〗','〖宝盒钥匙〗可以用来开启〖灵匣盒子〗和〖神匣盒子〗的钥匙',4,20,1000,1,1,1),(609,'〖金甲圣衣〗','〖金甲圣衣〗可帮助紫霞仙找到至尊宝',6,20,1000,1,1,1),(610,'〖七彩祥云〗','〖七彩祥云〗可帮助紫霞仙找到至尊宝',6,20,1000,1,1,1),(611,'〖紫霞眼泪〗','〖紫霞眼泪〗可帮助紫霞仙找到至尊宝',6,20,1000,1,1,1),(612,'〖紧箍咒〗','〖紧箍咒〗可帮助紫霞仙找到至尊宝',6,20,1000,1,1,1),(613,'〖至尊宝密令〗','〖至尊宝密令〗可用于开启〖月光宝盒〗',4,20,1000,1,1,1),(614,'〖麒麟圣祖〗（宠物蛋）','〖麒麟圣祖〗绝版宠物（至尊宝紫霞仙子活动充值获得）',4,1,1000,1,1,1),(615,'〖麒麟圣祖〗（宠物蛋-万里挑一）','被小轩GM调教好了的宠物，必出五级变异圣品〖麒麟圣祖〗绝版宠物（至尊宝紫霞仙子活动充值获得）',4,1,1000,1,1,1),(616,'〖齐天大圣〗（宠物蛋-万里挑一）','被小轩GM调教好了的宠物，必出五级变异圣品〖齐天大圣〗绝版宠物（至尊宝紫霞仙子活动充值获得）',4,1,1000,1,1,1),(617,'〖练星符〗（白）','宠物1至20星升星材料',4,1,1000,1,1,1),(618,'〖练星符〗（绿）','宠物21至40星升星材料',4,1,1000,1,1,1),(619,'〖练星符〗（蓝）','宠物41至60星升星材料',4,1,1000,1,1,1),(620,'〖练星符〗（紫）','宠物61至80星升星材料',4,1,1000,1,1,1),(621,'〖练星符〗（完美の紫）','宠物81至100星升星材料',4,1,1000,1,1,1),(622,'〖练星符〗（橙）','宠物101至120星升星材料',4,1,1000,1,1,1),(623,'〖练星符〗（完美の橙）','宠物121至150星升星材料',4,1,1000,1,1,1),(624,'〖许愿符〗','每次许愿后必得用于许愿落空后兑换',4,1,1000,1,1,1),(625,'〖1亿修炼经验丹〗','使用后获得一亿修炼经验',5,1,1000,160,1,1),(626,'〖5亿修炼经验丹〗','使用后获得五亿修炼经验',5,1,1000,160,1,1),(627,'〖10亿修炼经验丹〗','使用后获得十亿修炼经验',5,1,1000,160,1,1),(628,'〖金宝箱〗','打开箱子可随机获得物品（需要万能钥匙开启）',8,2,1000,1,1,1),(629,'〖七夕宝箱〗','七夕节日获得可开出大量宝贝',8,2,1000,1,1,1),(630,'【甜】','传说集齐甜蜜七夕四字可获取七夕宝箱',6,2,1000,1,1,0),(631,'【蜜】','传说集齐甜蜜七夕四字可获取七夕宝箱',6,2,1000,1,1,0),(632,'【七】','传说集齐甜蜜七夕四字可获取七夕宝箱',6,2,1000,1,1,0),(633,'【夕】','传说集齐甜蜜七夕四字可获取七夕宝箱',6,2,1000,1,1,0),(634,'〖鸳鸯帕〗','〖鸳鸯帕〗可用于兑换典藏婚饰品',6,2,1000,1,1,1),(635,'〖姻缘草〗','〖姻缘草〗可用于兑换典藏婚饰品',6,2,1000,1,1,1),(636,'〖银心铃〗','〖姻缘草〗可用于兑换典藏婚饰品',6,2,1000,1,1,1),(637,'〖噬魂锻造图纸〗','用于打造噬魂装备的图纸',2,2,1000,1,1,1),(638,'【七夕令】','用于179典藏升级到199典藏',4,2,1000,1,1,0),(639,'〖情圣〗','使用后可以永久增加HP50000，攻击50000，防御50000，魔攻50000',4,2,1000,1,1,1),(640,'〖万人迷〗','使用后可以永久增加HP50000，攻击50000，防御50000，魔攻50000',4,2,1000,1,1,1),(641,'〖天作之合〗','使用后可以永久增加HP80000，攻击80000，防御80000，魔攻80000',4,2,1000,1,1,1),(642,'〖爱你一万年〗','使用后可以永久增加HP100000，攻击100000，防御100000，魔攻100000',4,2,1000,1,1,1),(643,'〖真爱无敌〗','使用后可以永久增加HP100000，攻击100000，防御100000，魔攻100000',4,2,1000,1,1,1),(644,'〖绝世情圣〗','使用后可以永久增加HP100000，攻击100000，防御100000，魔攻100000',4,2,1000,1,1,1),(645,'〖天下最倾城〗','使用后可以永久增加HP110000，攻击110000，防御110000，魔攻110000',4,2,1000,1,1,1),(646,'〖天下最风流〗','使用后可以永久增加HP110000，攻击110000，防御110000，魔攻110000',4,2,1000,1,1,1),(647,'〖鹊桥仙子〗','使用后可以永久增加HP66666，攻击66666，防御66666，魔攻66666',4,2,1000,1,1,1),(648,'〖谦谦公子〗','使用后可以永久增加HP66666，攻击66666，防御66666，魔攻66666',4,2,1000,1,1,1),(649,'〖娇美宠儿〗','使用后可以永久增加HP77777，攻击77777，防御77777，魔攻77777',4,2,1000,1,1,1),(650,'〖柔情郎君〗','使用后可以永久增加HP77777，攻击77777，防御77777，魔攻77777',4,2,1000,1,1,1),(651,'〖传世战神〗','使用后可以永久增加HP150000，攻击150000，防御150000，魔攻150000',4,2,1000,1,1,1),(652,'〖天下第一〗','使用后可以永久增加HP160000，攻击160000，防御160000，魔攻160000',4,2,1000,1,1,1),(653,'〖灿若星斗〗','使用后可以永久增加HP160000，攻击160000，防御160000，魔攻160000',4,2,1000,1,1,1),(654,'〖富甲天下〗','使用后可以永久增加HP180000，攻击180000，防御180000，魔攻180000',4,2,1000,1,1,1),(655,'〖登峰造极〗','使用后可以永久增加HP200000，攻击200000，防御200000，魔攻200000',4,2,1000,1,1,1),(656,'【鹊翎】','【鹊翎】每日七夕天衣阁学徒苏语迟获取凑齐十个可兑换称号一个',6,2,1000,1,1,0),(657,'〖七夕万能字〗','〖七夕万能字〗用于兑换各种七夕字体',6,2,1000,1,1,1),(658,'〖超级七夕宝箱〗','能够开出〖七夕宝箱〗所得之物的10倍',8,2,1000,1,1,1),(659,'〖碎银块〗','价值连城的碎银块（可兑换1亿银两）',4,2,1000,1,1,1),(660,'〖银块〗','价值连城的银块（可兑换5亿银两）',4,2,1000,1,1,1),(661,'〖银锭〗','价值连城的银锭（可兑换10亿银两）',4,2,1000,1,1,1),(662,'〖金块〗','价值连城的金块（可兑换50亿银两）',4,2,1000,1,1,1),(663,'〖金锭〗','价值连城的金锭（可兑换100亿银两）',4,2,1000,1,1,1),(664,'【善果】','将【善果】交给天牢牢头可以助你减轻的罪孽（天牢牢头购买获得）',6,2,1000,1,1,0),(665,'〖免罪金牌〗','将〖免罪金牌〗交给天牢牢头可以助你减轻的罪孽（天牢牢头购买获得）',6,2,1000,1,1,1),(666,'〖西游新秀〗','使用后可以永久增加HP50000，攻击50000，防御50000，魔攻50000',4,2,1000,1,1,1),(667,'〖西游漫记〗','使用后可以永久增加HP50000，攻击50000，防御50000，魔攻50000',4,2,1000,1,1,1),(668,'〖玫瑰情人〗','使用后可以永久增加HP50000，攻击50000，防御50000，魔攻50000',4,2,1000,1,1,1),(669,'【科举答题】','使用后可以永久增加HP60000，攻击60000，防御60000，魔攻60000',4,2,1000,1,1,0),(670,'【举人】','使用后可以永久增加HP70000，攻击50000，防御50000，魔攻50000',4,2,1000,1,1,0),(671,'【榜眼】','使用后可以永久增加HP70000，攻击50000，防御50000，魔攻50000',4,2,1000,1,1,0),(672,'〖领跑西游〗','使用后可以永久增加HP70000，攻击70000，防御70000，魔攻70000',4,2,1000,1,1,1),(673,'〖超凡入圣〗','使用后可以永久增加HP150000，攻击100000，防御100000，魔攻100000',4,2,1000,1,1,1),(674,'〖震古烁今〗','使用后可以永久增加HP200000，攻击120000，防御120000，魔攻120000',4,2,1000,1,1,1),(675,'〖炉火纯青〗','使用后可以永久增加HP250000，攻击120000，防御120000，魔攻120000',4,2,1000,1,1,1),(676,'〖名扬四海〗','使用后可以永久增加HP300000，攻击150000，防御150000，魔攻150000',4,2,1000,1,1,1),(677,'〖进击の一骑绝尘〗','使用后可以永久增加HP300000，攻击180000，防御180000，魔攻180000',4,2,1000,1,1,1),(678,'〖进击の冠绝天下〗','使用后可以永久增加HP350000，攻击200000，防御200000，魔攻200000',4,2,1000,1,1,1),(679,'〖进击の笑傲苍穹〗','使用后可以永久增加HP500000，攻击300000，防御300000，魔攻300000',4,2,1000,1,1,1),(680,'【铅球】','体育老师的【铅球】开学活动获得',6,2,1000,1,1,0),(681,'【奖状】','〖活动〗脑筋急转弯老师开学活动获得',6,2,1000,1,1,0),(682,'〖开学礼包〗','〖开学礼包〗有小概率的范围开出称号〖西游漫记〗〖玫瑰情人〗〖领跑西游〗',8,2,1000,1,1,0),(683,'〖开学大礼包〗','〖开学大礼包〗有较高概率的范围开出称号〖西游漫记〗〖玫瑰情人〗〖领跑西游〗',8,2,1000,1,1,0),(684,'【粉笔】','开学活动获得（用于兑换各类物品）',6,2,1000,1,1,0),(685,'【橡皮擦】','开学活动获得（用于兑换各类物品）',6,2,1000,1,1,0),(686,'【铅笔】','开学活动获得（用于兑换各类物品）',6,2,1000,1,1,0),(687,'【墨水】','开学活动获得（用于兑换各类物品）',6,2,1000,1,1,0),(688,'〖女神同桌〗','开学活动获得（用于兑换各类物品）',6,2,1000,1,1,1),(689,'〖课本〗','开学活动获得（可交给找校长获取学分）',6,2,1000,1,1,1),(690,'〖帝王之心〗','王者风范帝王专属（打造帝王套装材料）',2,2,1000,1,1,1),(691,'〖帝王之血〗','王者风范帝王专属（打造帝王套装材料）',2,2,1000,1,1,1),(692,'〖帝王之魂〗','王者风范帝王专属（打造帝王套装材料）',2,2,1000,1,1,1),(693,'【九转仙丹】','服用后可解封199等级',6,2,1000,1,1,0),(694,'〖神仙果〗','通天层飞仙层或者堕魔层掉落（可在天蓬元帅处兑换金豆）',4,20,1000,1,1,1),(695,'〖BOSS如意令〗','凑齐相对应的〖BOSS如意令〗可兑换称号',4,20,1000,1,1,1),(696,'〖BOSS杀手〗','使用后可以永久增加HP50000，攻击50000，防御50000，魔攻50000',4,20,1000,1,1,1),(697,'〖猎魔之王〗','使用后可以永久增加HP100000，攻击100000，防御100000，魔攻100000',4,20,1000,1,1,1),(698,'〖不差钱〗','使用后可以永久增加HP100000，攻击100000，防御100000，魔攻100000',4,20,1000,1,1,1),(699,'〖我是大姐〗','使用后可以永久增加HP120000，攻击120000，防御120000，魔攻120000',4,20,1000,1,1,1),(700,'〖我是二哥〗','使用后可以永久增加HP120000，攻击120000，防御120000，魔攻120000',4,20,1000,1,1,1),(701,'〖十大富豪〗','使用后可以永久增加HP100000，攻击100000，防御100000，魔攻100000',4,20,1000,1,1,1),(702,'〖威力无边〗','使用后可以永久增加HP110000，攻击110000，防御110000，魔攻110000',4,20,1000,1,1,1),(703,'〖装备榜第一〗','使用后可以永久增加HP200000，攻击200000，防御200000，魔攻200000',4,20,1000,1,1,1),(704,'〖等级榜第一〗','使用后可以永久增加HP200000，攻击200000，防御200000，魔攻200000',4,20,1000,1,1,1),(705,'〖三界战神〗','使用后可以永久增加HP180000，攻击180000，防御180000，魔攻180000',4,20,1000,1,1,1),(706,'〖BOSS终结者〗','使用后可以永久增加HP200000，攻击200000，防御200000，魔攻200000',4,20,1000,1,1,1),(707,'〖一骑当先〗','使用后可以永久增加HP300000，攻击300000，防御300000，魔攻300000',4,20,1000,1,1,1),(708,'〖新妖之王〗','使用后可以永久增加HP400000，攻击400000，防御400000，魔攻400000',4,20,1000,1,1,1),(709,'〖豪无人性〗','使用后可以永久增加HP120000，攻击120000，防御120000，魔攻120000',4,20,1000,1,1,1),(711,'〖封神英雄〗','使用后可以永久增加HP130000，攻击130000，防御130000，魔攻130000',4,20,1000,1,1,1),(712,'〖天外飞仙征服者〗','使用后可以永久增加HP150000，攻击150000，防御150000，魔攻150000',4,20,1000,1,1,1),(713,'〖打遍天下无敌手〗','使用后可以永久增加HP200000，攻击200000，防御200000，魔攻200000',4,20,1000,1,1,1),(714,'〖土豪就是任性〗','使用后可以永久增加HP400000，攻击400000，防御400000，魔攻400000',4,20,1000,1,1,1),(715,'〖十大神翼〗','使用后可以永久增加HP180000，攻击180000，防御180000，魔攻180000',4,20,1000,1,1,1),(716,'〖不屈白银〗','使用后可以永久增加HP80000，攻击80000，防御80000，魔攻80000',4,20,1000,1,1,1),(717,'【坚毅之星】','放入星盘大阵后HP提升200000',4,20,1000,1,1,0),(718,'【守护之星】','放入星盘大阵后防御提升100000',4,20,1000,1,1,0),(719,'【盛怒之星】','放入星盘大阵后攻击提升100000',4,20,1000,1,1,0),(720,'【镇静之星】','放入星盘大阵后魔攻提升100000',4,20,1000,1,1,0),(721,'【复苏之星】','放入星盘大阵后HP提升300000',4,20,1000,1,1,0),(722,'【潮汐之星】','放入星盘大阵后防御提升200000',4,20,1000,1,1,0),(723,'【寂灭之星】','放入星盘大阵后攻击提升200000',4,20,1000,1,1,0),(724,'【风暴之星】','放入星盘大阵后魔攻提升200000',4,20,1000,1,1,0),(725,'【神星の永生】','放入星盘大阵后HP提升500000',4,20,1000,1,1,0),(726,'【神星の混沌】','放入星盘大阵后防御提升400000',4,20,1000,1,1,0),(727,'【神星の秩序】','放入星盘大阵后攻击提升400000',4,20,1000,1,1,0),(728,'【神星の圣恩】','放入星盘大阵后魔攻提升400000',4,20,1000,1,1,0),(729,'【小宇宙】','凑齐足够的可用于各类占星兑换',4,20,1000,1,1,0),(730,'【占星秘典】','可用于〖高级占星〗〖极品占星〗消耗',4,20,1000,1,1,0),(731,'【智慧之星】（攻）','放入星盘大阵后冰火雷攻+5',4,20,1000,1,1,0),(732,'【智慧之星】（防）','放入星盘大阵后冰火雷防+5',4,20,1000,1,1,0),(733,'【元素之星】（攻）','放入星盘大阵后冰火雷攻+10',4,20,1000,1,1,0),(734,'【元素之星】（防）','放入星盘大阵后冰火雷防+10',4,20,1000,1,1,0),(735,'【神星の元素之王】（攻）','放入星盘大阵后冰火雷攻+20',4,20,1000,1,1,0),(736,'【神星の元素之王】（防）','放入星盘大阵后冰火雷防+20',4,20,1000,1,1,0),(737,'【秘宝钥匙】','用于开启秘宝宝箱的钥匙',4,20,1000,1,1,0),(738,'【秘宝碎片】','用于合成秘宝宝箱或者钥匙的碎片',4,20,1000,1,1,0),(739,'【秘宝宝箱】','开启秘宝宝箱需要【秘宝钥匙】',8,20,1000,1,1,1),(740,'【桂花糕】','中秋节获得获取',6,20,1000,1,1,0),(741,'【糯米粉】','中秋节活动掉落',6,20,1000,1,1,0),(742,'〖香甜桂花〗','中秋节活动掉落',6,20,1000,1,1,1),(743,'〖玉兔蜜糖〗','中秋节活动掉落',6,20,1000,1,1,1),(744,'【金秋的思念】','中秋节活动各类礼盒开出（用于时装兑换）',6,20,1000,1,1,0),(745,'〖凤梨月饼〗','使用后永久增加HP1000（中秋节活动获得）',5,20,1000,1,1,1),(746,'〖玫瑰月饼〗','使用后永久增加HP1200（中秋节活动获得）',5,20,1000,1,1,1),(747,'〖莲蓉月饼〗','使用后永久增加HP1400（中秋节活动获得）',5,20,1000,1,1,1),(748,'〖椰蓉月饼〗','使用后永久增加HP1500（中秋节活动获得）',5,20,1000,1,1,1),(749,'〖蓝莓月饼〗','使用后永久增加HP1600（中秋节活动获得）',5,20,1000,1,1,1),(750,'〖桂花月饼〗','使用后永久增加HP1800（中秋节活动获得）',5,20,1000,1,1,1),(751,'〖葡萄月饼〗','使用后永久增加HP2000（中秋节活动获得）',5,20,1000,1,1,1),(752,'〖五仁月饼〗','使用后永久增加攻击500（中秋节活动获得）',5,20,1000,1,1,1),(753,'〖双黄月饼〗','使用后永久增加攻击700（中秋节活动获得）',5,20,1000,1,1,1),(754,'〖冰皮月饼〗','使用后永久增加攻击900（中秋节活动获得）',5,20,1000,1,1,1),(755,'〖水果月饼〗','使用后永久增加攻击1100（中秋节活动获得）',5,20,1000,1,1,1),(756,'〖红豆沙月饼〗','使用后永久增加攻击1500（中秋节活动获得）',5,20,1000,1,1,1),(757,'〖黄金月饼〗','使用后永久增加魔攻500（中秋节活动获得）',5,20,1000,1,1,1),(758,'〖云腿月饼〗','使用后永久增加魔攻700（中秋节活动获得）',5,20,1000,1,1,1),(759,'〖水蜜桃月饼〗','使用后永久增加魔攻900（中秋节活动获得）',5,20,1000,1,1,1),(760,'〖哈密瓜月饼〗','使用后永久增加魔攻1100（中秋节活动获得）',5,20,1000,1,1,1),(761,'〖草莓月饼〗','使用后永久增加魔攻1500（中秋节活动获得）',5,20,1000,1,1,1),(762,'〖鲜花月饼〗','使用后永久增加防御500（中秋节活动获得）',5,20,1000,1,1,1),(763,'〖七彩月饼〗','使用后永久增加防御700（中秋节活动获得）',5,20,1000,1,1,1),(764,'〖榄仁烧鸡月饼〗','使用后永久增加防御900（中秋节活动获得）',5,20,1000,1,1,1),(765,'〖奶油椰丝月饼〗','使用后永久增加防御1100（中秋节活动获得）',5,20,1000,1,1,1),(766,'〖叉烧腊肠月饼〗','使用后永久增加防御1500（中秋节活动获得）',5,20,1000,1,1,1),(767,'〖嫦娥月饼〗（血）','使用后永久增加HP6000（中秋节活动获得）',5,20,1000,1,1,1),(768,'〖嫦娥月饼〗（攻）','使用后永久增加攻击4000（中秋节活动获得）',5,20,1000,1,1,1),(769,'〖嫦娥月饼〗（魔）','使用后永久增加魔攻4000（中秋节活动获得）',5,20,1000,1,1,1),(770,'〖嫦娥月饼〗（防）','使用后永久增加防御3000（中秋节活动获得）',5,20,1000,1,1,1),(771,'〖玉兔月饼〗','将此月饼赠送给嫦娥将获得中秋积分（中秋节抢榜特供）',6,20,1000,1,1,1),(772,'〖风花月饼礼盒〗','能开出各种好吃的月饼',8,20,1000,1,1,1),(773,'〖雪月月饼礼盒〗','能开出各种好吃的月饼',8,20,1000,1,1,1),(774,'〖金秋月饼礼盒〗','能开出各种好吃的月饼',8,20,1000,1,1,1),(775,'〖鸿福月饼礼盒〗','能开出各种好吃的月饼',8,20,1000,1,1,1),(776,'〖嫦娥月饼礼盒〗','能开出各种好吃的月饼',8,20,1000,1,1,1),(777,'【10元充值卡】','使用后可获得10元现金充值1:10的金豆和对等的vip积分（使用此充值卡不参与充值排名）',4,20,1000,1,1,0),(778,'【20元充值卡】','使用后可获得20元现金充值1:10的金豆和对等的vip积分（使用此充值卡不参与充值排名）',4,20,1000,1,1,0),(779,'【50元充值卡】','使用后可获得50元现金充值1:10的金豆和对等的vip积分（使用此充值卡不参与充值排名）',4,20,1000,1,1,0),(780,'【100元充值卡】','使用后可获得100元现金充值1:10的金豆和对等的vip积分（使用此充值卡不参与充值排名）',4,20,1000,1,1,0),(781,'【200元充值卡】','使用后可获得200元现金充值1:10的金豆和对等的vip积分（使用此充值卡不参与充值排名）',4,20,1000,1,1,0),(782,'【500元充值卡】','使用后可获得500元现金充值1:10的金豆和对等的vip积分（使用此充值卡不参与充值排名）',4,20,1000,1,1,0),(783,'【1000元充值卡】','使用后可获得1000元现金充值1:10的金豆和对等的vip积分（使用此充值卡不参与充值排名）',4,20,1000,1,1,0),(784,'【2000元充值卡】','使用后可获得2000元现金充值1:10的金豆和对等的vip积分（使用此充值卡不参与充值排名）',4,20,1000,1,1,0),(785,'【150级升级卡】','使用后可获将等级变更为150级（注意请勿大于150等级使用否则也会变为150级）',4,20,1000,1,1,0),(786,'【1亿修炼经验丹】','使用后获得一亿修炼经验',5,1,1000,1,1,0),(787,'【5亿修炼经验丹】','使用后获得五亿修炼经验',5,1,1000,1,1,0),(788,'【10亿修炼经验丹】','使用后获得十亿修炼经验',5,1,1000,1,1,0),(789,'【二区花果山助力包】','打开后可获得【200充值卡】x1【诛仙套装】【150级升级卡】x1，【vip练级卷】x20，【10亿修炼经验丹】x10，【万能果】x100，【1万西游声望卷轴】x100，【1万法宝经验卷轴】x100，',4,1,1000,1,1,0),(790,'【三区水帘洞助力包】','打开后可获得【幻想套装】【vip练级卷】x20，【10亿修炼经验丹】x10，【万能果】x100，【1万西游声望卷轴】x100，【1万法宝经验卷轴】x100，〖瞌睡虫〗（典藏版）x5（全服赠送）',4,1,1000,1,1,0),(791,'〖圣贤宝石包〗（1个）','打开后获得〖圣贤宝石〗x1',4,1,1000,1,1,1),(792,'〖圣贤宝石包〗（3个）','打开后获得〖圣贤宝石〗x3',4,1,1000,1,1,1),(793,'〖圣贤宝石包〗（8个）','打开后获得〖圣贤宝石〗x8',4,1,1000,1,1,1),(794,'〖圣贤宝石包〗（30个）','打开后获得〖圣贤宝石〗x30',4,1,1000,1,1,1),(795,'〖极品7位ID号（11111111）靓号卡〗','使用后ID变更为11111111，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(796,'〖极品7位ID号（2222222）靓号卡〗','使用后ID变更为2222222，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(797,'〖极品7位ID号（3333333）靓号卡〗','使用后ID变更为3333333，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(798,'〖极品7位ID号（4444444）靓号卡〗','使用后ID变更为4444444，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(799,'〖极品7位ID号（5555555）靓号卡〗','使用后ID变更为5555555，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(800,'〖极品7位ID号（6666666）靓号卡〗','使用后ID变更为6666666，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(801,'〖极品7位ID号（7777777）靓号卡〗','使用后ID变更为7777777，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(802,'〖极品7位ID号（8888888）靓号卡〗','使用后ID变更为8888888，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(803,'〖极品7位ID号（9999999）靓号卡〗','使用后ID变更为9999999，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(804,'〖极品7位ID号（1234567）靓号卡〗','使用后ID变更为1234567，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(805,'〖极品7位ID号（1314520）靓号卡〗','使用后ID变更为1314520，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(806,'〖极品7位ID号（5201314）靓号卡〗','使用后ID变更为5201314，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(807,'〖极品7位ID号（5203344）靓号卡〗','使用后ID变更为5203344，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(808,'〖皇者宝石包〗（1个）','打开后获得〖皇者宝石〗x1',4,1,1000,1,1,1),(809,'〖皇者宝石包〗（3个）','打开后获得〖皇者宝石〗x3',4,1,1000,1,1,1),(810,'〖皇者宝石包〗（8个）','打开后获得〖皇者宝石〗x8',4,1,1000,1,1,1),(811,'〖皇者宝石包〗（30个）','打开后获得〖皇者宝石〗x30',4,1,1000,1,1,1),(812,'〖铁魂材料包〗','打开后获得〖铁魂〗x100',4,1,1000,1,1,1),(813,'〖铜魂材料包〗','打开后获得〖铜魂〗x100',4,2,1000,1,1,1),(814,'〖银魂材料包〗','打开后获得〖银魂〗x100',4,5,1000,1,1,1),(815,'〖金魂材料包〗','打开后获得〖金魂〗x100',4,10,1000,1,1,1),(816,'〖钻魂材料包〗','打开后获得〖钻魂〗x100',4,15,1000,1,1,1),(817,'〖陨魂材料包〗','打开后获得〖陨魂〗x100',4,20,1000,1,1,1),(818,'〖时装碎片〗','〖时装碎片〗制作时装必备材料',2,20,1000,1,1,1),(819,'〖时装契约〗','〖时装契约〗制作时装必备材料',2,20,1000,1,1,1),(820,'〖时装凭证〗','〖时装凭证〗制作时装的证书',4,20,1000,1,1,1),(821,'〖云梯石〗','〖云梯石〗可用于娱乐爬楼的宝贝',4,10,1000,1,1,1),(822,'〖如意の称号宝箱〗','〖如意の称号宝箱〗各类称号屌丝的逆袭，王者的荣耀（同等的几率开出各类称号）',8,10,1000,1,1,1),(823,'〖仙の陨魂〗','〖仙の陨魂〗能提升仙陨以上装备星级材料',2,10,1000,1,1,1),(824,'〖仙の陨升星符〗','〖仙の陨升星符〗百分之百将仙陨以上装备星级提升成功',4,1000,1000,1,1,1),(825,'【圣星の永生】','放入星盘大阵后HP提升700000',4,20,1000,1,1,0),(826,'【圣星の混沌】','放入星盘大阵后防御提升600000',4,20,1000,1,1,0),(827,'【圣星の秩序】','放入星盘大阵后攻击提升600000',4,20,1000,1,1,0),(828,'【圣星の圣恩】','放入星盘大阵后魔攻提升600000',4,20,1000,1,1,0),(829,'【圣星の元素之王】（攻）','放入星盘大阵后冰火雷攻+30',4,20,1000,1,1,0),(830,'【圣星の元素之王】（防）','放入星盘大阵后冰火雷防+30',4,20,1000,1,1,0),(831,'【五星红旗】','可在爱国富商处进行升旗用（每日领取一次）',6,20,1000,1,1,0),(832,'【欢】','凑齐一定数量欢度国庆可兑换【国庆宝箱】',6,20,1000,1,1,0),(833,'【度】','凑齐一定数量欢度国庆可兑换【国庆宝箱】',6,20,1000,1,1,0),(834,'【国】','凑齐一定数量欢度国庆可兑换【国庆宝箱】',6,20,1000,1,1,0),(835,'【庆】','凑齐一定数量欢度国庆可兑换【国庆宝箱】',6,20,1000,1,1,0),(836,'〖国庆万能字〗','可在国庆期间使用转换任意字',6,20,1000,1,1,1),(837,'【国庆金铲】','可用于国庆挖宝',6,20,1000,1,1,0),(838,'【金铲】','可用于国庆挖宝',6,20,1000,1,1,0),(839,'【至尊铲】','可用于国庆挖宝',6,20,1000,1,1,0),(840,'〖国庆藏宝图〗（银图）','配合对应的铲子进行挖宝',6,20,1000,1,1,1),(841,'〖国庆藏宝图〗（金图）','配合对应的铲子进行挖宝',6,20,1000,1,1,1),(842,'〖国庆藏宝图〗（至尊图）','配合对应的铲子进行挖宝',6,20,1000,1,1,1),(843,'【国庆金锤】','可用于国庆敲金蛋活动',6,20,1000,1,1,0),(844,'〖国庆宝箱〗','可开出价值不菲的宝藏',8,20,1000,1,1,1),(845,'〖国庆愉快卡〗','可在国庆大使处提交用于国庆活动期间抢榜',6,20,1000,1,1,0),(846,'〖凤凰圣祖〗（宠物蛋）','〖凤凰圣祖〗绝版宠物，威力十分惊人',4,1,1000,1,1,1),(847,'〖凤凰圣祖〗（宠物蛋-万里挑一）','被小轩GM调教好了的宠物，必出五级变异圣品〖凤凰圣祖〗绝版宠物，威力十分惊人',4,1,1000,1,1,1),(848,'〖国庆充值10元消费礼宝箱〗','在2018.10.1-2018.10.7回馈充值赠送宝箱',8,1,1000,1,1,1),(849,'〖国庆充值20元消费礼宝箱〗','在2018.10.1-2018.10.7回馈充值赠送宝箱',8,1,1000,1,1,1),(850,'〖国庆充值50元消费礼宝箱〗','在2018.10.1-2018.10.7回馈充值赠送宝箱',8,1,1000,1,1,1),(851,'〖国庆充值100元消费礼宝箱〗','在2018.10.1-2018.10.7回馈充值赠送宝箱',8,1,1000,1,1,1),(852,'〖国庆充值200元消费礼宝箱〗','在2018.10.1-2018.10.7回馈充值赠送宝箱',8,1,1000,1,1,1),(853,'〖国庆充值500元消费礼宝箱〗','在2018.10.1-2018.10.7回馈充值赠送宝箱',8,1,1000,1,1,1),(854,'〖国庆充值1000元消费礼宝箱〗','在2018.10.1-2018.10.7回馈充值赠送宝箱',8,1,1000,1,1,1),(855,'〖国庆充值2000元消费礼宝箱〗','在2018.10.1-2018.10.7回馈充值赠送宝箱',8,1,1000,1,1,1),(856,'〖至尊宝石包〗（1个）','打开后获得〖至尊宝石〗x1',4,1,1000,1,1,1),(857,'〖挂售扩容卷〗','使用后可增加背包容量500',4,5,1000,1,1,1),(858,'〖尊享VIP〗（月卡）','使用后实力可大幅度提升从此走向人生巅峰，30天月卡',4,5,1000,1,1,1),(859,'〖尊享VIP〗（季卡）','使用后实力可大幅度提升从此走向人生巅峰，90天季卡',4,5,1000,1,1,1),(860,'〖尊享VIP〗（半年卡）','使用后实力可大幅度提升从此走向人生巅峰，180天半年卡',4,5,1000,1,1,1),(861,'〖尊享VIP〗（至尊年卡）','使用后实力可大幅度提升从此走向人生巅峰，366天年卡',4,5,1000,1,1,1),(862,'【尊享VIP】（月卡）','使用后实力可大幅度提升从此走向人生巅峰，30天月卡',4,5,1000,1,1,0),(863,'〖采花花魁〗','每日采花大盗排名奖励获取可用于兑换【尊享VIP】（月卡）',4,5,1000,1,1,1),(864,'〖尊享VIP〗（天卡）','使用后实力可大幅度提升从此走向人生巅峰，1天卡',4,5,1000,1,1,1),(865,'【尊享VIP】（1天）','使用后实力可大幅度提升从此走向人生巅峰，1天卡',4,5,1000,1,1,0),(866,'【尊享VIP】（3天）','使用后实力可大幅度提升从此走向人生巅峰，3天卡',4,5,1000,1,1,0),(867,'【尊享VIP】（7天）','使用后实力可大幅度提升从此走向人生巅峰，7天卡',4,5,1000,1,1,0),(868,'〖鲜果蛋糕〗','食用后可永久提升500hp',5,5,1000,1,1,1),(869,'〖奶油蛋糕〗','食用后可永久提升700hp',5,5,1000,1,1,1),(870,'〖草莓蛋糕〗','食用后可永久提升900hp',5,5,1000,1,1,1),(871,'〖焦糖蛋糕〗','食用后可永久提升1200hp',5,5,1000,1,1,1),(872,'〖香椰子蛋糕〗','食用后可永久提升1500hp',5,5,1000,1,1,1),(873,'〖曲奇饼干〗','食用后可永久提升500攻击',5,5,1000,1,1,1),(874,'〖蛋卷饼干〗','食用后可永久提升700攻击',5,5,1000,1,1,1),(875,'〖夹心饼干〗','食用后可永久提升900攻击',5,5,1000,1,1,1),(876,'〖芝麻饼干〗','食用后可永久提升1200攻击',5,5,1000,1,1,1),(877,'〖杏仁饼干〗','食用后可永久提升1500攻击',5,5,1000,1,1,1),(878,'〖奶油面包〗','食用后可永久提升500魔攻',5,5,1000,1,1,1),(879,'〖奶香面包〗','食用后可永久提升700魔攻',5,5,1000,1,1,1),(880,'〖抹茶面包〗','食用后可永久提升900魔攻',5,5,1000,1,1,1),(881,'〖椰蓉面包〗','食用后可永久提升1200魔攻',5,5,1000,1,1,1),(882,'〖毛毛虫面包〗','食用后可永久提升1500魔攻',5,5,1000,1,1,1),(883,'〖酥圈巧克力〗','食用后可永久提升500防御',5,5,1000,1,1,1),(884,'〖浓夫巧克力〗','食用后可永久提升700防御',5,5,1000,1,1,1),(885,'〖米雪巧克力〗','食用后可永久提升900防御',5,5,1000,1,1,1),(886,'〖乐荷巧克力〗','食用后可永久提升1200防御',5,5,1000,1,1,1),(887,'〖香雪巧克力〗','食用后可永久提升1500防御',5,5,1000,1,1,1),(888,'〖麦乐堡蛋糕〗（血）','食用后可永久提升5000hp',5,5,1000,1,1,1),(889,'〖麦乐堡蛋糕〗（攻）','食用后可永久提升5000攻击',5,5,1000,1,1,1),(890,'〖麦乐堡蛋糕〗（魔）','食用后可永久提升5000魔攻',5,5,1000,1,1,1),(891,'〖麦乐堡蛋糕〗（防）','食用后可永久提升5000防御',5,5,1000,1,1,1),(892,'〖麦乐堡甜品箱〗','能开出各类蛋糕，饼干，面包，巧克力，【尊享VIP】（1-7天）（必得麦乐堡蛋糕）',8,5,1000,1,1,1),(893,'〖西游蛋糕〗','不能吃的哦，但是可用于积分抢榜',6,5,1000,1,1,1),(894,'〖鸟蛋〗','制作糕点的原材料',6,5,1000,1,1,1),(895,'〖奶油〗','制作糕点的原材料',6,5,1000,1,1,1),(896,'〖白糖〗','制作糕点的原材料',6,5,1000,1,1,1),(897,'〖牛奶〗','制作糕点的原材料',6,5,1000,1,1,1),(898,'〖面粉〗','制作糕点的原材料',6,5,1000,1,1,1),(899,'〖黄油〗','制作糕点的原材料',6,5,1000,1,1,1),(900,'〖小麦粉〗','制作糕点的原材料',6,5,1000,1,1,1),(901,'〖巧克力酱〗','制作糕点的原材料',6,5,1000,1,1,1),(902,'〖可可粉〗','制作糕点的原材料',6,5,1000,1,1,1),(903,'〖力娇酒〗','制作糕点的原材料',6,5,1000,1,1,1),(904,'〖原料购物票〗','可使用〖原料购物票〗购买你需要的原材料',6,5,1000,1,1,1),(905,'〖生日甜品礼盒〗','可使用半，周，年，庆，典，四字兑换',8,5,1000,1,1,1),(906,'〖半周岁10元消费礼宝箱〗','在2018.10.10-2018.10.16回馈充值赠送宝箱',8,1,1000,1,1,1),(907,'〖半周岁20元消费礼宝箱〗','在2018.10.10-2018.10.16回馈充值赠送宝箱',8,1,1000,1,1,1),(908,'〖半周岁50元消费礼宝箱〗','在2018.10.10-2018.10.16回馈充值赠送宝箱',8,1,1000,1,1,1),(909,'〖半周岁100元消费礼宝箱〗','在2018.10.10-2018.10.16回馈充值赠送宝箱',8,1,1000,1,1,1),(910,'〖半周岁200元消费礼宝箱〗','在2018.10.10-2018.10.16回馈充值赠送宝箱',8,1,1000,1,1,1),(911,'〖半周岁500元消费礼宝箱〗','在2018.10.10-2018.10.16回馈充值赠送宝箱',8,1,1000,1,1,1),(912,'〖半周岁1000元消费礼宝箱〗','在2018.10.10-2018.10.16回馈充值赠送宝箱',8,1,1000,1,1,1),(913,'〖半周岁2000元消费礼宝箱〗','在2018.10.10-2018.10.16回馈充值赠送宝箱',8,1,1000,1,1,1),(914,'〖绝世盟主〗（纪念版）','〖绝世盟主〗（纪念版）在2018.10.10-2018.10.16周年庆典获得,使用后可以永久增加HP1000000，攻击1000000，防御1000000，魔攻1000000',4,1,1000,1,1,1),(915,'〖绝世仙盟〗（纪念版）','〖绝世仙盟〗（纪念版）在2018.10.10-2018.10.16周年庆典获得,使用后可以永久增加HP800000，攻击800000，防御800000，魔攻800000',4,1,1000,1,1,1),(916,'〖君临王城の至尊王城〗（纪念版）','〖君临王城の至尊王城〗（纪念版）在2018.10.10-2018.10.16周年庆典获得,使用后可以永久增加HP500000，攻击500000，防御500000，魔攻500000',4,1,1000,1,1,1),(917,'〖八荒雷动の傲视群雄〗（纪念版）','〖八荒雷动の傲视群雄〗（纪念版）在2018.10.10-2018.10.16周年庆典获得,使用后可以永久增加HP500000，攻击500000，防御500000，魔攻500000',4,1,1000,1,1,1),(918,'〖天下无双の群雄霸主〗（纪念版）','〖天下无双の群雄霸主〗（纪念版）在2018.10.10-2018.10.16周年庆典获得,使用后可以永久增加HP400000，攻击400000，防御400000，魔攻400000',4,1,1000,1,1,1),(919,'〖火树银花の名士风流〗（纪念版）','〖火树银花の名士风流〗（纪念版）在2018.10.10-2018.10.16周年庆典获得,使用后可以永久增加HP300000，攻击300000，防御300000，魔攻300000',4,1,1000,1,1,1),(920,'〖万花迎春の国色天香〗（纪念版）','〖万花迎春の国色天香〗（纪念版）在2018.10.10-2018.10.16周年庆典获得,使用后可以永久增加HP200000，攻击200000，防御200000，魔攻200000',4,1,1000,1,1,1),(921,'〖勇者之王〗（纪念版）','〖勇者之王〗（纪念版）在2018.10.10-2018.10.16周年庆典获得,使用后可以永久增加HP500000，攻击200000，防御200000，魔攻200000',4,1,1000,1,1,1),(922,'〖半〗','〖半〗凑齐半周年庆典兑换生日甜品礼盒',6,1,1000,1,1,1),(923,'〖周〗','〖周〗凑齐半周年庆典兑换生日甜品礼盒',6,1,1000,1,1,1),(924,'〖年〗','〖年〗凑齐半周年庆典兑换生日甜品礼盒',6,1,1000,1,1,1),(925,'〖庆〗','〖庆〗凑齐半周年庆典兑换生日甜品礼盒',6,1,1000,1,1,1),(926,'〖典〗','〖典〗凑齐半周年庆典兑换生日甜品礼盒',6,1,1000,1,1,1),(927,'〖极品3位ID号（111）靓号卡〗','使用后ID变更为111，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(928,'〖极品3位ID号（222）靓号卡〗','使用后ID变更为222，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(929,'〖极品3位ID号（333）靓号卡〗','使用后ID变更为333，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(930,'〖极品3位ID号（444）靓号卡〗','使用后ID变更为444，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(931,'〖极品3位ID号（555）靓号卡〗','使用后ID变更为555，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(932,'〖极品3位ID号（666）靓号卡〗','使用后ID变更为666，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(933,'〖极品3位ID号（777）靓号卡〗','使用后ID变更为777，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(934,'〖极品3位ID号（888）靓号卡〗','使用后ID变更为888，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(935,'〖极品3位ID号（999）靓号卡〗','使用后ID变更为999，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(936,'〖极品3位ID号（123）靓号卡〗','使用后ID变更为123，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(937,'〖极品1位ID号（1）靓号卡〗','使用后ID变更为1，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(938,'【伏羲阵图】','【伏羲阵图】用于伏羲大阵消耗使用',1,10,1000,1,1,0),(939,'〖帝王石〗','用于合成帝王宝石的宝贵材料',2,10,1000,1,1,1),(940,'〖帝王宝石包〗（1个）','打开后获得〖帝王宝石〗x1',4,1,1000,1,1,1),(941,'〖护身符〗','〖护身符〗用于伏羲大阵跳阵使用',4,1,1000,1,1,1),(942,'【黑沃土】','【黑沃土】重阳节活动产物用于施肥',6,1,1000,1,1,0),(943,'【仙玉露】','【仙玉露】重阳节活动产物用于施肥',6,1,1000,1,1,0),(944,'〖紫星币〗','〖紫星币〗比金豆还要珍贵的物品',4,1,1000,1,1,1),(945,'〖小公主の激素〗','〖小公主の激素〗用于催生植物的产品（提升1小时收获时间）',4,1,1000,1,1,1),(946,'【面粉】','【面粉】重阳节活动用于制作【重阳糕】',6,1,1000,1,1,0),(947,'【红枣】','【红枣】重阳节活动用于制作【重阳糕】',6,1,1000,1,1,0),(948,'【栗子】','【栗子】重阳节活动用于制作【重阳糕】',6,1,1000,1,1,0),(949,'【杏仁】','【杏仁】重阳节活动用于制作【重阳糕】',6,1,1000,1,1,0),(950,'〖小公主の材料票〗','〖小公主の材料票〗用于购买【杏仁】【栗子】【红枣】【面粉】【黑沃土】【仙玉露】',6,1,1000,1,1,1),(951,'〖小公主の仙竹〗','〖小公主の仙竹〗用于活动抢夺积分榜',6,1,1000,1,1,1),(952,'【重阳糕】','【重阳糕】用于兑换称号和〖小公主の激素〗',6,1,1000,1,1,0),(953,'〖小公主の仙竹〗','〖小公主の仙竹〗用于活动抢夺积分榜',6,1,1000,1,1,1),(954,'〖绝代芳华〗','〖绝代芳华〗使用后hp增加30万，攻击魔攻防御各20万',4,1,1000,1,1,1),(955,'〖君临天下の武道至尊〗','〖君临天下の武道至尊〗使用后hp增加150万，攻击魔攻防御各100万',4,1,1000,1,1,1),(956,'〖倾城佳人の艳冠天下〗','〖倾城佳人の艳冠天下〗使用后hp增加120万，攻击魔攻防御各80万',4,1,1000,1,1,1),(957,'〖风流倜傥の百战无双〗','〖风流倜傥の百战无双〗使用后hp增加100万，攻击魔攻防御各70万',4,1,1000,1,1,1),(958,'〖天下无双の群雄霸主〗','〖天下无双の群雄霸主〗使用后hp增加80万，攻击魔攻防御各50万',4,1,1000,1,1,1),(959,'〖君临王城の至尊皇者〗','〖君临王城の至尊皇者〗使用后hp增加100万，攻击魔攻防御各70万',4,1,1000,1,1,1),(960,'〖至尊无敌〗','〖至尊无敌〗使用后hp增加80万，攻击魔攻防御各50万',4,1,1000,1,1,1),(961,'〖妖火天尊〗','〖妖火天尊〗使用后hp增加50万，攻击魔攻防御各30万',4,1,1000,1,1,1),(962,'〖神乎其技〗','〖神乎其技〗使用后hp增加30万，攻击魔攻防御各15万',4,1,1000,1,1,1),(963,'〖灵机百变〗','〖灵机百变〗使用后hp增加30万，攻击魔攻防御各15万',4,1,1000,1,1,1),(964,'〖姐是白富美〗','〖姐是白富美〗使用后hp增加30万，攻击魔攻防御各15万',4,1,1000,1,1,1),(965,'〖圣灵白板套装〗','〖圣灵白板套装〗打开后获得圣灵白板一套',4,1,1000,1,1,1),(966,'〖圣灵1级套装〗','〖圣灵1级套装〗打开后获得圣灵1级套装一套',4,1,1000,1,1,1),(967,'〖圣灵2级套装〗','〖圣灵2级套装〗打开后获得圣灵2级套装一套',4,1,1000,1,1,1),(968,'〖圣灵3级套装〗','〖圣灵3级套装〗打开后获得圣灵3级套装一套',4,1,1000,1,1,1),(969,'〖圣灵☯天元套装〗','〖圣灵☯天元套装〗打开后获得圣灵☯天元套装一套',4,1,1000,1,1,1),(970,'〖噬魂套装〗','〖噬魂套装〗打开后获得噬魂套装一套',4,1,1000,1,1,1),(971,'〖帝王套装〗','〖帝王套装〗打开后获得帝王套装一套',4,1,1000,1,1,1),(972,'〖比翼双飞〗（典藏套装）','〖比翼双飞〗打开后获得比翼双飞婚饰一套',4,1,1000,1,1,1),(973,'【伏羲仙丹】','使用后可解封仙20等级',6,1,1000,220,1,0),(974,'〖仙佑石〗','〖仙佑石〗升级人物200级装备材料',2,1,1000,1,1,1),(975,'〖仙晶砂〗','〖仙晶砂〗升级人物200级装备材料',2,1,1000,1,1,1),(976,'〖仙器魂〗','〖仙器魂〗升级人物200级装备材料',2,1,1000,1,1,1),(977,'〖神佑石〗','〖神佑石〗升级人物仙20级装备材料',2,1,1000,1,1,1),(978,'〖神晶砂〗','〖神晶砂〗升级人物仙20级装备材料',2,1,1000,1,1,1),(979,'〖神器魂〗','〖神器魂〗升级人物仙20级装备材料',2,1,1000,1,1,1),(980,'〖圣佑石〗','〖圣佑石〗升级人物仙30级装备材料',2,1,1000,1,1,1),(981,'〖圣晶砂〗','〖圣晶砂〗升级人物仙30级装备材料',2,1,1000,1,1,1),(982,'〖圣器魂〗','〖圣器魂〗升级人物仙30级装备材料',2,1,1000,1,1,1),(983,'〖混沌天佑石〗','〖混沌天佑石〗升级人物仙40级装备材料',2,1,1000,1,1,1),(984,'〖混沌天晶砂〗','〖混沌天晶砂〗升级人物仙40级装备材料',2,1,1000,1,1,1),(985,'〖混沌天器魂〗','〖混沌天器魂〗升级人物仙40级装备材料',2,1,1000,1,1,1),(986,'〖混沌神佑石〗','〖混沌神佑石〗升级人物仙50级装备材料',2,1,1000,1,1,1),(987,'〖混沌神晶砂〗','〖混沌神晶砂〗升级人物仙50级装备材料',2,1,1000,1,1,1),(988,'〖混沌神器魂〗','〖混沌神器魂〗升级人物仙50级装备材料',2,1,1000,1,1,1),(989,'〖混沌圣佑石〗','〖混沌圣佑石〗升级人物仙60级装备材料',2,1,1000,1,1,1),(990,'〖混沌圣晶砂〗','〖混沌圣晶砂〗升级人物仙60级装备材料',2,1,1000,1,1,1),(991,'〖混沌圣器魂〗','〖混沌圣器魂〗升级人物仙60级装备材料',2,1,1000,1,1,1),(992,'〖鸿蒙天佑石〗','〖鸿蒙天佑石〗升级人物仙70级装备材料',2,1,1000,1,1,1),(993,'〖鸿蒙天晶砂〗','〖鸿蒙天晶砂〗升级人物仙70级装备材料',2,1,1000,1,1,1),(994,'〖鸿蒙天器魂〗','〖鸿蒙天器魂〗升级人物仙70级装备材料',2,1,1000,1,1,1),(995,'〖鸿蒙神佑石〗','〖鸿蒙神佑石〗升级人物仙80级装备材料',2,1,1000,1,1,1),(996,'〖鸿蒙神晶砂〗','〖鸿蒙神晶砂〗升级人物仙80级装备材料',2,1,1000,1,1,1),(997,'〖鸿蒙神器魂〗','〖鸿蒙神器魂〗升级人物仙80级装备材料',2,1,1000,1,1,1),(998,'〖鸿蒙圣佑石〗','〖鸿蒙圣佑石〗升级人物仙90级装备材料',2,1,1000,1,1,1),(999,'〖鸿蒙圣晶砂〗','〖鸿蒙圣晶砂〗升级人物仙90级装备材料',2,1,1000,1,1,1),(1000,'〖鸿蒙圣器魂〗','〖鸿蒙圣器魂〗升级人物仙90级装备材料',2,1,1000,1,1,1),(1001,'〖鸿蒙天圣石〗','〖鸿蒙圣佑石〗升级人物仙90级装备材料',2,1,1000,1,1,1),(1002,'〖鸿蒙天圣砂〗','〖鸿蒙天圣砂〗升级人物仙90级装备材料',2,1,1000,1,1,1),(1003,'〖鸿蒙天圣魂〗','〖鸿蒙天圣魂〗升级人物仙90级装备材料',2,1,1000,1,1,1),(1004,'【万】','【万】万圣节节日多动字体',6,1,1000,1,1,0),(1005,'【圣】','【圣】万圣节节日多动字体',6,1,1000,1,1,0),(1006,'【节】','【节】万圣节节日多动字体',6,1,1000,1,1,0),(1007,'【快】','【快】万圣节节日多动字体',6,1,1000,1,1,0),(1008,'【乐】','【乐】万圣节节日多动字体',6,1,1000,1,1,0),(1009,'〖万圣节万能字〗','〖万圣节万能字〗任意兑换活动字体',6,1,1000,1,1,1),(1010,'〖神の陨魂〗','仙陨的装备升星材料！',2,9999,1000,1,1,1),(1011,'〖神の陨升星符〗','拥有这强大的力量的符咒，可将百分之百将仙陨的装备升星成功！',4,9999,1000,1,1,1),(1012,'〖棒棒糖〗','使用后HP上限增加500！',5,9999,1000,1,1,1),(1013,'〖杏仁糖〗','使用后HP上限增加800！',5,9999,1000,1,1,1),(1014,'〖米花糖〗','使用后HP上限增加1000！',5,9999,1000,1,1,1),(1015,'〖水果糖〗','使用后HP上限增加1300！',5,9999,1000,1,1,1),(1016,'〖棉花糖〗','使用后攻击增加500！',5,9999,1000,1,1,1),(1017,'〖牛皮糖〗','使用后攻击增加700！',5,9999,1000,1,1,1),(1018,'〖咖啡糖〗','使用后攻击增加900！',5,9999,1000,1,1,1),(1019,'〖可乐糖〗','使用后攻击增加1200！',5,9999,1000,1,1,1),(1020,'〖太妃糖〗','使用后魔攻增加500！',5,9999,1000,1,1,1),(1021,'〖胡桃糖〗','使用后魔攻增加700！',5,9999,1000,1,1,1),(1022,'〖南瓜糖〗','使用后魔攻增加900！',5,9999,1000,1,1,1),(1023,'〖榴莲糖〗','使用后魔攻增加1200！',5,9999,1000,1,1,1),(1024,'〖狮子糖〗','使用后防御增加500！',5,9999,1000,1,1,1),(1025,'〖绵羊糖〗','使用后防御增加700！',5,9999,1000,1,1,1),(1026,'〖大象糖〗','使用后防御增加900！',5,9999,1000,1,1,1),(1027,'〖老虎塘〗','使用后防御增加1200！',5,9999,1000,1,1,1),(1028,'〖甜蜜梅心棒〗','使用后HP增加5000！',5,9999,1000,1,1,1),(1029,'〖云朵棉花糖〗','使用后攻击增加5000！',5,9999,1000,1,1,1),(1030,'〖浪漫酒心糖〗','使用后魔攻增加5000！',5,9999,1000,1,1,1),(1031,'〖大白兔奶糖〗','使用后防御增加5000！',5,9999,1000,1,1,1),(1032,'〖万圣节精品糖果箱〗','能够开出万圣节各种活动糖果！',8,9999,1000,1,1,1),(1033,'〖万圣节极品糖果箱〗','能够开出万圣节各种活动糖果+限定糖果！',8,9999,1000,1,1,1),(1034,'〖千秋万载〗','使用后可提升属性HP+200万，攻击+200万，魔攻+200万，防御+200万！',4,9999,1000,1,1,1),(1035,'〖纵横三界づ王者风云〗','使用后可提升属性HP+140万，攻击+140万，魔攻+140万，防御+140万！',4,9999,1000,1,1,1),(1036,'〖天下第一盟〗','使用后可提升属性HP+100万，攻击+100万，魔攻+100万，防御+100万！',4,9999,1000,1,1,1),(1037,'〖天下第一盟主〗','使用后可提升属性HP+80万，攻击+80万，魔攻+80万，防御+80万！',4,9999,1000,1,1,1),(1038,'〖富甲一方〗','使用后可提升属性HP+80万，攻击+80万，魔攻+80万，防御+80万！',4,9999,1000,1,1,1),(1039,'〖至高无上〗','使用后可提升属性HP+50万，攻击+50万，魔攻+50万，防御+50万！',4,9999,1000,1,1,1),(1040,'〖哥是高富帅〗','使用后可提升属性HP+30万，攻击+30万，魔攻+30万，防御+30万！',4,9999,1000,1,1,1),(1041,'〖探宝之神〗','使用后可提升属性HP+30万，攻击+30万，魔攻+30万，防御+30万！',4,9999,1000,1,1,1),(1042,'〖仙境状元〗','使用后可提升属性HP+20万，攻击+20万，魔攻+20万，防御+20万！',4,9999,1000,1,1,1),(1043,'〖制胜斗者〗','使用后可提升属性HP+15万，攻击+15万，魔攻+15万，防御+15万！',4,9999,1000,1,1,1),(1044,'〖诛魔大神〗','使用后可提升属性HP+10万，攻击+10万，魔攻+10万，防御+10万！',4,9999,1000,1,1,1),(1045,'〖珠光宝气〗','使用后可提升属性HP+50万，攻击+50万，魔攻+50万，防御+50万！',4,9999,1000,1,1,1),(1046,'【万圣节捣蛋劵】','用于万圣节称号兑换',6,9999,1000,1,1,0),(1047,'〖南瓜宝箱〗','〖南瓜宝箱〗能开出价值不菲的物品',8,1,1000,1,1,1),(1048,'【177级升级卡】','使用后可获将等级变更为177级（注意请勿大于177等级使用否则也会变为177级）',4,20,1000,1,1,0),(1049,'【155级升级卡】','使用后可获将等级变更为155级（注意请勿大于155等级使用否则也会变为155级）',4,20,1000,1,1,0),(1050,'【160级升级卡】','使用后可获将等级变更为160级（注意请勿大于160等级使用否则也会变为160级）',4,20,1000,1,1,0),(1051,'【165级升级卡】','使用后可获将等级变更为165级（注意请勿大于165等级使用否则也会变为165级）',4,20,1000,1,1,0),(1052,'【170级升级卡】','使用后可获将等级变更为170级（注意请勿大于170等级使用否则也会变为170级）',4,20,1000,1,1,0),(1053,'【175级升级卡】','使用后可获将等级变更为175级（注意请勿大于175等级使用否则也会变为175级）',4,20,1000,1,1,0),(1054,'【180级升级卡】','使用后可获将等级变更为180级（注意请勿大于180等级使用否则也会变为180级）',4,20,1000,1,1,0),(1055,'【185级升级卡】','使用后可获将等级变更为185级（注意请勿大于185等级使用否则也会变为185级）',4,20,1000,1,1,0),(1056,'【190级升级卡】','使用后可获将等级变更为190级（注意请勿大于190等级使用否则也会变为190级）',4,20,1000,1,1,0),(1057,'【195级升级卡】','使用后可获将等级变更为195级（注意请勿大于195等级使用否则也会变为195级）',4,20,1000,1,1,0),(1058,'【199级升级卡】','使用后可获将等级变更为199级（注意请勿大于199等级使用否则也会变为199级）',4,20,1000,1,1,0),(1059,'【烤火鸡】','感恩节活动掉落【烤火鸡】',6,20,1000,1,1,0),(1060,'【南瓜饼】','感恩节活动掉落【南瓜饼】',6,20,1000,1,1,0),(1061,'【红莓酱】','感恩节活动掉落【红莓酱】',6,20,1000,1,1,0),(1062,'【甜山芋】','感恩节活动掉落【甜山芋】',6,20,1000,1,1,0),(1063,'【玉蜀黎】','感恩节活动掉落【玉蜀黎】',6,20,1000,1,1,0),(1064,'〖感恩票〗','〖感恩票〗兑换任意感恩节活动材料',6,20,1000,1,1,1),(1065,'〖良品烤火鸡〗（血）','使用后HP上限增加500！',5,9999,1000,1,1,1),(1066,'〖上品烤火鸡〗（血）','使用后HP上限增加800！',5,9999,1000,1,1,1),(1067,'〖精品烤火鸡〗（血）','使用后HP上限增加1000！',5,9999,1000,1,1,1),(1068,'〖极品烤火鸡〗（血）','使用后HP上限增加1300！',5,9999,1000,1,1,1),(1069,'〖良品烤火鸡〗（攻）','使用后攻击增加500！',5,9999,1000,1,1,1),(1070,'〖上品烤火鸡〗（攻）','使用后攻击增加800！',5,9999,1000,1,1,1),(1071,'〖精品烤火鸡〗（攻）','使用后攻击增加1000！',5,9999,1000,1,1,1),(1072,'〖极品烤火鸡〗（攻）','使用后攻击增加1300！',5,9999,1000,1,1,1),(1073,'〖良品烤火鸡〗（魔）','使用后魔攻增加500！',5,9999,1000,1,1,1),(1074,'〖上品烤火鸡〗（魔）','使用后魔攻增加800！',5,9999,1000,1,1,1),(1075,'〖精品烤火鸡〗（魔）','使用后魔攻增加1000！',5,9999,1000,1,1,1),(1076,'〖极品烤火鸡〗（魔）','使用后魔攻增加1300！',5,9999,1000,1,1,1),(1077,'〖良品烤火鸡〗（防）','使用后御增增加500！',5,9999,1000,1,1,1),(1078,'〖上品烤火鸡〗（防）','使用后御增增加800！',5,9999,1000,1,1,1),(1079,'〖精品烤火鸡〗（防）','使用后御增增加1000！',5,9999,1000,1,1,1),(1080,'〖极品烤火鸡〗（防）','使用后防御增加1300！',5,9999,1000,1,1,1),(1081,'〖极品烤全羊〗（血）','使用后hp上限增加10000！',5,9999,1000,1,1,1),(1082,'〖极品烤全羊〗（攻）','使用后攻击增加8888！',5,9999,1000,1,1,1),(1083,'〖极品烤全羊〗（魔）','使用后魔攻增加8888！',5,9999,1000,1,1,1),(1084,'〖极品烤全羊〗（防）','使用后防御增加8888！',5,9999,1000,1,1,1),(1085,'〖感恩小羊礼包〗','打开后可烤火鸡和烤全羊！！美味~~',8,9999,1000,1,1,1),(1086,'〖感恩火鸡礼包〗','打开后可烤火鸡！！美味~~',8,9999,1000,1,1,1),(1087,'〖10至500元现金红包〗','打开可随机得到10元至500元不等的现金红包',4,9999,1000,1,1,1),(1088,'〖10至200元现金红包〗','打开可随机得到10元至200元不等的现金红包',4,9999,1000,1,1,1),(1089,'〖10至50元现金红包〗','打开可随机得到10元至50元不等的现金红包',4,9999,1000,1,1,1),(1090,'〖10元红包〗','赠送给游戏ID为10000001的小轩GM兑换现金',4,9999,1000,1,1,1),(1091,'〖20元红包〗','赠送给游戏ID为10000001的小轩GM兑换现金',4,9999,1000,1,1,1),(1092,'〖50元红包〗','赠送给游戏ID为10000001的小轩GM兑换现金',4,9999,1000,1,1,1),(1093,'〖100元红包〗','赠送给游戏ID为10000001的小轩GM兑换现金',4,9999,1000,1,1,1),(1094,'〖200元红包〗','赠送给游戏ID为10000001的小轩GM兑换现金',4,9999,1000,1,1,1),(1095,'〖300元红包〗','赠送给游戏ID为10000001的小轩GM兑换现金',4,9999,1000,1,1,1),(1096,'〖400元红包〗','赠送给游戏ID为10000001的小轩GM兑换现金',4,9999,1000,1,1,1),(1097,'〖500元红包〗','赠送给游戏ID为10000001的小轩GM兑换现金',4,9999,1000,1,1,1),(1098,'〖点石成金劵〗','〖点石成金劵〗可在玄武大街点石成金员传送进入矿山，遇到各路神仙能够获得更多的金矿石',4,9999,1000,1,1,1),(1099,'〖金矿石〗','〖金矿石〗可在玄武大街点石成金员换购金劵',4,9999,1000,1,1,1),(1101,'〖1金矿券〗','〖1金矿券〗可用于换取对应金额充值卡',4,1,1000,1,1,1),(1102,'〖5金矿券〗','〖5金矿券〗可用于换取对应金额充值卡',4,1,1000,1,1,1),(1103,'〖10金矿券〗','〖10金矿券〗可用于换取对应金额充值卡',4,1,1000,1,1,1),(1104,'〖20金矿券〗','〖20金矿券〗可用于换取对应金额充值卡',4,1,1000,1,1,1),(1105,'〖50金矿券〗','〖50金矿券〗可用于换取对应金额充值卡',4,1,1000,1,1,1),(1106,'〖100金矿券〗','〖100金矿券〗可用于换取对应金额充值卡',4,1,1000,1,1,1),(1107,'无名仙法','酒剑侠留下的功法秘籍',1,2,1000,1,1,1),(1108,'秦家霸王枪','将军府专用功法秘籍',1,2,1000,1,1,1),(1109,'金刚砂','升级炼妖壶神器所需物品',2,0,1000,1,1,1),(1110,'黄铁矿石','升级神器炼妖壶所需物品',2,0,1000,1,1,1),(1111,'剑柄碎片','升级神器轩辕剑所需物品',2,0,1000,1,1,1),(1112,'玄铁矿石','升级神器轩辕剑所需物品',2,0,1000,1,1,1),(1113,'昆仑神木','升级昆仑镜神器所需物品',2,0,1000,1,1,1),(1114,'神秘矿石','升级昆仑镜神器所需物品',2,0,1000,1,1,1),(1115,'【精炼的玄铁】','神器升星阶时所需的通用物品',2,100,1000,1,1,0),(1116,'〖伏魔币〗','兑换伏魔塔物品的货币',4,1,1000,1,1,0),(1117,'堕落的魔心','兑换伏魔塔装备套装的重要物品',2,1,1000,1,1,0),(1118,'@css01@【龙吟苍穹の套装】@css@','开启就能获得属性超强的套装神装！',4,1,1000,1,1,0),(1119,'【筑基金丹】','突破筑基期必需要的物品',2,1,1000,1,1,0),(1120,'【金丹金丹】','突破金丹期必需要的物品',2,1,1000,1,1,0),(1121,'【元婴金丹】','突破元婴期必需要的物品',2,1,1000,1,1,0),(1122,'【化神金丹】','突破化神期必需要的物品',2,1,1000,1,1,0),(1123,'【炼虚金丹】','突破炼虚期必需要的物品',2,1,1000,1,1,0),(1124,'【合体金丹】','突破合体期必需要的物品',2,1,1000,1,1,0),(1125,'【大乘金丹】','突破大乘期必需要的物品',2,1,1000,1,1,0),(1126,'【真仙仙丹】','突破真仙期必需要的物品',2,1,1000,1,1,0),(1127,'【金仙仙丹】','突破金仙期必需要的物品',2,1,1000,1,1,0),(1128,'【太乙仙丹】','突破太乙期必需要的物品',2,1,1000,1,1,0),(1129,'【大罗仙丹】','突破大罗期必需要的物品',2,1,1000,1,1,0),(1130,'【道祖仙丹】','突破道祖期必需要的物品',2,1,1000,1,1,0),(1131,'【虚神仙丹】','突破虚神期必需要的物品',2,1,1000,1,1,0),(1132,'【真神仙丹】','突破真神期必需要的物品',2,1,1000,1,1,0),(1133,'【神王仙丹】','突破神王期必需要的物品',2,1,1000,1,1,0),(1134,'【祖神仙丹】','突破神神期必需要的物品',2,1,1000,1,1,0),(1135,'〖龙吟圣佑石〗','升级龙吟苍穹装备时需要的物品',2,2,1000,1,1,1),(1136,'〖龙吟圣晶砂〗','升级龙吟苍穹装备时需要的物品',2,2,1000,1,1,1),(1137,'〖龙吟圣器魂〗','升级龙吟苍穹装备时需要的物品',2,2,1000,1,1,1),(1138,'〖幸运转盘币〗','幸运大转盘中启动转盘时所需物品',4,1,1000,1,1,1),(1139,'〖神威圣佑石〗','升级霸气神威装备时需要的物品',2,2,1000,1,1,1),(1140,'〖神威圣晶砂〗','升级霸气神威装备时需要的物品',2,2,1000,1,1,1),(1141,'〖神威圣器魂〗','升级霸气神威装备时需要的物品',2,2,1000,1,1,1),(1142,'〖神威材料包〗','能开出升级霸气神威装备时需要的材料',4,2,1000,1,1,1),(1143,'〖龙吟材料包〗','能开出升级龙吟苍穹时需要的材料',4,2,1000,1,1,1),(1144,'〖首饰披风材料包〗','能开出升级首饰与披风时需要的材料',4,2,1000,1,1,1),(1145,'〖情义之圣晶〗','升级婚戒与婚链装备时需要的物品',2,2,1000,1,1,1),(1146,'〖威武之披风〗','升级披风装备时需要的物品',2,2,1000,1,1,1),(1147,'九彩铃兰','提炼丹药时需要的物品材料',2,2,1000,1,1,1),(1148,'冰葵','提炼丹药时需要的物品材料',2,2,1000,1,1,1),(1149,'魂婴果','提炼丹药时需要的物品材料',2,2,1000,1,1,1),(1150,'蚀心菇','提炼丹药时需要的物品材料',2,2,1000,1,1,1),(1151,'地脉龙晶','提炼丹药时需要的物品材料',2,2,1000,1,1,1);
/*!40000 ALTER TABLE `wpxx` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `xl`
--

DROP TABLE IF EXISTS `xl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `xl` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '编号id',
  `wjid` int(10) unsigned NOT NULL DEFAULT '0',
  `xlid` int(11) NOT NULL DEFAULT '0' COMMENT '修炼id',
  `xldj` int(11) NOT NULL DEFAULT '0' COMMENT '修炼等级',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `xl`
--

LOCK TABLES `xl` WRITE;
/*!40000 ALTER TABLE `xl` DISABLE KEYS */;
/*!40000 ALTER TABLE `xl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `xp`
--

DROP TABLE IF EXISTS `xp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `xp` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '编号id',
  `wjid` int(10) unsigned NOT NULL DEFAULT '0',
  `seq` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '星盘顺序编号',
  `xpid` int(11) NOT NULL DEFAULT '0' COMMENT '星盘id',
  `xpkq` int(11) NOT NULL DEFAULT '0' COMMENT '星盘开启',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `xp`
--

LOCK TABLES `xp` WRITE;
/*!40000 ALTER TABLE `xp` DISABLE KEYS */;
/*!40000 ALTER TABLE `xp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `xtbl`
--

DROP TABLE IF EXISTS `xtbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `xtbl` (
  `id` int(11) NOT NULL,
  `bl1` int(11) NOT NULL,
  `bl2` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `xtbl`
--

LOCK TABLES `xtbl` WRITE;
/*!40000 ALTER TABLE `xtbl` DISABLE KEYS */;
/*!40000 ALTER TABLE `xtbl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `yxrw`
--

DROP TABLE IF EXISTS `yxrw`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `yxrw` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '编号ID',
  `wjid` int(10) unsigned NOT NULL DEFAULT '0',
  `rwid` int(11) NOT NULL DEFAULT '0' COMMENT '任务ID',
  `rwbl` int(11) NOT NULL DEFAULT '0' COMMENT '任务变量',
  `rwmz` text NOT NULL COMMENT '任务名字',
  `yisg` int(11) NOT NULL DEFAULT '0' COMMENT '已杀怪',
  `ysg` int(11) NOT NULL DEFAULT '0' COMMENT '要杀怪',
  `rwfl` int(11) NOT NULL DEFAULT '0' COMMENT '任务分类',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `yxrw`
--

LOCK TABLES `yxrw` WRITE;
/*!40000 ALTER TABLE `yxrw` DISABLE KEYS */;
/*!40000 ALTER TABLE `yxrw` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `zb`
--

DROP TABLE IF EXISTS `zb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `zb` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '编号ID',
  `wjid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '玩家ID',
  `zbid` int(11) NOT NULL DEFAULT '0' COMMENT '装备ID',
  `zbxj` int(11) NOT NULL DEFAULT '0' COMMENT '装备星级',
  `zbk1` int(11) NOT NULL DEFAULT '0' COMMENT '装备孔1',
  `zbxq1` int(11) NOT NULL DEFAULT '0' COMMENT '镶嵌1',
  `zbk2` int(11) NOT NULL DEFAULT '0' COMMENT '装备孔2',
  `zbxq2` int(11) NOT NULL DEFAULT '0' COMMENT '镶嵌2',
  `zbk3` int(11) NOT NULL DEFAULT '0' COMMENT '装备孔3',
  `zbxq3` int(11) NOT NULL DEFAULT '0' COMMENT '镶嵌3',
  `zbk4` int(11) NOT NULL DEFAULT '0' COMMENT '装备孔4',
  `zbxq4` int(11) NOT NULL DEFAULT '0' COMMENT '镶嵌4',
  `zbk5` int(11) NOT NULL DEFAULT '0' COMMENT '装备孔5',
  `zbxq5` int(11) NOT NULL DEFAULT '0' COMMENT '镶嵌5',
  `zbpd` int(11) NOT NULL DEFAULT '0' COMMENT '装备佩戴',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='装备';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `zb`
--

LOCK TABLES `zb` WRITE;
/*!40000 ALTER TABLE `zb` DISABLE KEYS */;
/*!40000 ALTER TABLE `zb` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `zbb`
--

DROP TABLE IF EXISTS `zbb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `zbb` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '编号ID',
  `wjid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '玩家ID',
  `zbid` int(11) NOT NULL DEFAULT '0' COMMENT '装备ID',
  `zbxj` int(11) NOT NULL DEFAULT '0' COMMENT '装备星级',
  `zbk1` int(11) NOT NULL DEFAULT '0' COMMENT '装备孔1',
  `zbxq1` int(11) NOT NULL DEFAULT '0' COMMENT '镶嵌1',
  `zbk2` int(11) NOT NULL DEFAULT '0' COMMENT '装备孔2',
  `zbxq2` int(11) NOT NULL DEFAULT '0' COMMENT '镶嵌2',
  `zbk3` int(11) NOT NULL DEFAULT '0' COMMENT '装备孔3',
  `zbxq3` int(11) NOT NULL DEFAULT '0' COMMENT '镶嵌3',
  `zbk4` int(11) NOT NULL DEFAULT '0' COMMENT '装备孔4',
  `zbxq4` int(11) NOT NULL DEFAULT '0' COMMENT '镶嵌4',
  `zbk5` int(11) NOT NULL DEFAULT '0' COMMENT '装备孔5',
  `zbxq5` int(11) NOT NULL DEFAULT '0' COMMENT '镶嵌5',
  `zbfl` int(11) NOT NULL DEFAULT '0' COMMENT '装备分类',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `zbb`
--

LOCK TABLES `zbb` WRITE;
/*!40000 ALTER TABLE `zbb` DISABLE KEYS */;
/*!40000 ALTER TABLE `zbb` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `zbxx`
--

DROP TABLE IF EXISTS `zbxx`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `zbxx` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '装备编号',
  `mz` varchar(100) NOT NULL DEFAULT '' COMMENT '名字',
  `ms` varchar(100) NOT NULL DEFAULT '' COMMENT '描述',
  `hp` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '血量',
  `gj` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '攻击',
  `mg` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '魔攻',
  `fy` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '防御',
  `bg` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '冰攻',
  `hg` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '火攻',
  `lg` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '雷攻',
  `bf` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '冰防',
  `hf` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '火防',
  `lf` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '雷防',
  `dj` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '等级',
  `zl` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '重量',
  `bd` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '是否绑定',
  `jd` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '金豆价格',
  `jg` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '价格',
  `pd` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '佩戴',
  `mp` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '门派',
  `fl` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '分类',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=834 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `zbxx`
--

LOCK TABLES `zbxx` WRITE;
/*!40000 ALTER TABLE `zbxx` DISABLE KEYS */;
/*!40000 ALTER TABLE `zbxx` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `zem`
--

DROP TABLE IF EXISTS `zem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `zem` (
  `id` int(11) NOT NULL,
  `zem` text NOT NULL,
  `sy` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `zem`
--

LOCK TABLES `zem` WRITE;
/*!40000 ALTER TABLE `zem` DISABLE KEYS */;
/*!40000 ALTER TABLE `zem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `zf`
--

DROP TABLE IF EXISTS `zf`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `zf` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `wjid` int(10) unsigned NOT NULL DEFAULT '0',
  `wpid` int(11) NOT NULL DEFAULT '0' COMMENT '祝福id',
  `n` int(11) NOT NULL DEFAULT '0' COMMENT '年',
  `y` int(11) NOT NULL DEFAULT '0' COMMENT '月',
  `r` int(11) NOT NULL DEFAULT '0' COMMENT '日',
  `s` int(11) NOT NULL DEFAULT '0' COMMENT '时',
  `f` int(11) NOT NULL DEFAULT '0' COMMENT '分',
  `m` int(11) NOT NULL DEFAULT '0' COMMENT '秒',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `zf`
--

LOCK TABLES `zf` WRITE;
/*!40000 ALTER TABLE `zf` DISABLE KEYS */;
/*!40000 ALTER TABLE `zf` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `zgvip`
--

DROP TABLE IF EXISTS `zgvip`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `zgvip` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '编号ID',
  `wjid` int(10) unsigned NOT NULL DEFAULT '0',
  `zgvipid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '尊贵VIP编号',
  `zgviptime` datetime NOT NULL COMMENT '尊贵vip时间',
  `xs` int(11) NOT NULL DEFAULT '0' COMMENT '显示',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `zgvip`
--

LOCK TABLES `zgvip` WRITE;
/*!40000 ALTER TABLE `zgvip` DISABLE KEYS */;
/*!40000 ALTER TABLE `zgvip` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `zz`
--

DROP TABLE IF EXISTS `zz`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `zz` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `wjid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '玩家ID',
  `zzdj` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '种植等级',
  `zzwpmz` varchar(32) NOT NULL DEFAULT '' COMMENT '种植物品名字',
  `zzwpid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '种植物品ID',
  `zzwpsl` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '种植物品数量',
  `zztime` timestamp NULL DEFAULT NULL COMMENT '种植时间',
  `sftime` timestamp NULL DEFAULT NULL COMMENT '施肥时间',
  `shtime` timestamp NULL DEFAULT NULL COMMENT '收获时间',
  PRIMARY KEY (`id`),
  KEY `zz_wjid_IDX` (`wjid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `zz`
--

LOCK TABLES `zz` WRITE;
/*!40000 ALTER TABLE `zz` DISABLE KEYS */;
/*!40000 ALTER TABLE `zz` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `zzck`
--

DROP TABLE IF EXISTS `zzck`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `zzck` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '编号ID',
  `wjid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '玩家ID',
  `wpid` int(11) NOT NULL DEFAULT '0' COMMENT '物品ID',
  `wpsl` int(11) NOT NULL DEFAULT '0' COMMENT '物品数量',
  `wpfl` int(11) NOT NULL DEFAULT '0' COMMENT '物品分类',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='增值仓库';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `zzck`
--

LOCK TABLES `zzck` WRITE;
/*!40000 ALTER TABLE `zzck` DISABLE KEYS */;
/*!40000 ALTER TABLE `zzck` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-03-13 23:37:15
