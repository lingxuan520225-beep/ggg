-- MySQL dump 10.13  Distrib 5.7.26, for Win64 (x86_64)
--
-- Host: localhost    Database: xye
-- ------------------------------------------------------
-- Server version	5.7.26

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `all_boss`
--

DROP TABLE IF EXISTS `all_boss`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `all_boss` (
  `bossid` int(11) NOT NULL,
  `bossmz` text NOT NULL,
  `bosstime` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `all_boss`
--

LOCK TABLES `all_boss` WRITE;
/*!40000 ALTER TABLE `all_boss` DISABLE KEYS */;
/*!40000 ALTER TABLE `all_boss` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `all_bp`
--

DROP TABLE IF EXISTS `all_bp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `all_bp` (
  `bpid` int(11) NOT NULL,
  `bpdj` int(11) NOT NULL,
  `bpmz` text NOT NULL,
  `cbpmz` text NOT NULL,
  `cwjid` int(11) NOT NULL,
  `xbpmz` text NOT NULL,
  `xwjid` int(11) NOT NULL,
  `ccmz01` text NOT NULL,
  `ccid01` int(11) NOT NULL,
  `ccmz02` text NOT NULL,
  `ccid02` int(11) NOT NULL,
  `ccmz03` text NOT NULL,
  `ccid03` int(11) NOT NULL,
  `ccmz04` int(11) NOT NULL,
  `ccid04` int(11) NOT NULL,
  `ccmz05` text NOT NULL,
  `ccid05` int(11) NOT NULL,
  `ccmz06` text NOT NULL,
  `ccid06` int(11) NOT NULL,
  `bprsmax` int(11) NOT NULL,
  `bpjymax` int(11) NOT NULL,
  `bpyl` int(11) NOT NULL,
  `bpsw` int(11) NOT NULL,
  `bpjy` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '帮派经验',
  `bprs` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '帮派人数'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `all_bp`
--

LOCK TABLES `all_bp` WRITE;
/*!40000 ALTER TABLE `all_bp` DISABLE KEYS */;
/*!40000 ALTER TABLE `all_bp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `all_cz`
--

DROP TABLE IF EXISTS `all_cz`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `all_cz` (
  `id` int(11) NOT NULL COMMENT '排序',
  `czid` int(11) NOT NULL COMMENT '充值id',
  `czje` int(11) NOT NULL COMMENT '充值金额',
  `cztime` datetime NOT NULL COMMENT '充值时间',
  `czfl` int(11) NOT NULL COMMENT '充值方式'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `all_cz`
--

LOCK TABLES `all_cz` WRITE;
/*!40000 ALTER TABLE `all_cz` DISABLE KEYS */;
/*!40000 ALTER TABLE `all_cz` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `all_gzhoures`
--

DROP TABLE IF EXISTS `all_gzhoures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `all_gzhoures` (
  `id` int(11) NOT NULL,
  `wjid` int(11) NOT NULL,
  `fzid` int(11) NOT NULL,
  `wjmz` text NOT NULL,
  `fzmz` text NOT NULL,
  `fzfl` int(11) NOT NULL,
  `fzgm` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `all_gzhoures`
--

LOCK TABLES `all_gzhoures` WRITE;
/*!40000 ALTER TABLE `all_gzhoures` DISABLE KEYS */;
/*!40000 ALTER TABLE `all_gzhoures` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `all_hbmoney`
--

DROP TABLE IF EXISTS `all_hbmoney`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `all_hbmoney` (
  `wjid` int(11) NOT NULL,
  `wjmz` text NOT NULL,
  `money` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `all_hbmoney`
--

LOCK TABLES `all_hbmoney` WRITE;
/*!40000 ALTER TABLE `all_hbmoney` DISABLE KEYS */;
/*!40000 ALTER TABLE `all_hbmoney` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `all_hbmoneyjc`
--

DROP TABLE IF EXISTS `all_hbmoneyjc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `all_hbmoneyjc` (
  `id` int(11) NOT NULL,
  `money` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `all_hbmoneyjc`
--

LOCK TABLES `all_hbmoneyjc` WRITE;
/*!40000 ALTER TABLE `all_hbmoneyjc` DISABLE KEYS */;
/*!40000 ALTER TABLE `all_hbmoneyjc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `all_hdph01`
--

DROP TABLE IF EXISTS `all_hdph01`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `all_hdph01` (
  `id` int(11) NOT NULL,
  `wjid` int(11) NOT NULL,
  `wjmz` text NOT NULL,
  `vip` int(11) NOT NULL,
  `ds01` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `all_hdph01`
--

LOCK TABLES `all_hdph01` WRITE;
/*!40000 ALTER TABLE `all_hdph01` DISABLE KEYS */;
/*!40000 ALTER TABLE `all_hdph01` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `all_hdph02`
--

DROP TABLE IF EXISTS `all_hdph02`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `all_hdph02` (
  `id` int(11) NOT NULL,
  `wjid` int(11) NOT NULL,
  `wjmz` text NOT NULL,
  `vip` int(11) NOT NULL,
  `ds01` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `all_hdph02`
--

LOCK TABLES `all_hdph02` WRITE;
/*!40000 ALTER TABLE `all_hdph02` DISABLE KEYS */;
/*!40000 ALTER TABLE `all_hdph02` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `all_hdph03`
--

DROP TABLE IF EXISTS `all_hdph03`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `all_hdph03` (
  `id` int(11) NOT NULL,
  `wjid` int(11) NOT NULL,
  `wjmz` text NOT NULL,
  `vip` int(11) NOT NULL,
  `ds01` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `all_hdph03`
--

LOCK TABLES `all_hdph03` WRITE;
/*!40000 ALTER TABLE `all_hdph03` DISABLE KEYS */;
/*!40000 ALTER TABLE `all_hdph03` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `all_houres`
--

DROP TABLE IF EXISTS `all_houres`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `all_houres` (
  `id` int(11) NOT NULL,
  `wjid` int(11) NOT NULL,
  `fzid` int(11) NOT NULL,
  `wjmz` text NOT NULL,
  `fzmz` text NOT NULL,
  `fzfl` int(11) NOT NULL,
  `fzgm` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `all_houres`
--

LOCK TABLES `all_houres` WRITE;
/*!40000 ALTER TABLE `all_houres` DISABLE KEYS */;
/*!40000 ALTER TABLE `all_houres` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `all_ip`
--

DROP TABLE IF EXISTS `all_ip`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `all_ip` (
  `ip` text NOT NULL,
  `iptime` int(11) NOT NULL,
  `wjid` int(11) NOT NULL,
  `wjname` text NOT NULL,
  `ipcs` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `all_ip`
--

LOCK TABLES `all_ip` WRITE;
/*!40000 ALTER TABLE `all_ip` DISABLE KEYS */;
/*!40000 ALTER TABLE `all_ip` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `all_jc`
--

DROP TABLE IF EXISTS `all_jc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `all_jc` (
  `id` int(11) NOT NULL,
  `xlid` int(11) NOT NULL,
  `jc` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `all_jc`
--

LOCK TABLES `all_jc` WRITE;
/*!40000 ALTER TABLE `all_jc` DISABLE KEYS */;
/*!40000 ALTER TABLE `all_jc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `all_jdjc`
--

DROP TABLE IF EXISTS `all_jdjc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `all_jdjc` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `wjid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '玩家ID',
  `vip` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '玩家VIP',
  `wjmz` varchar(32) NOT NULL DEFAULT '' COMMENT '玩家名字',
  `jcjg` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '竞猜价格',
  `cq` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '出拳',
  `timex` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `all_jdjc`
--

LOCK TABLES `all_jdjc` WRITE;
/*!40000 ALTER TABLE `all_jdjc` DISABLE KEYS */;
/*!40000 ALTER TABLE `all_jdjc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `all_ltbw`
--

DROP TABLE IF EXISTS `all_ltbw`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `all_ltbw` (
  `id` int(11) NOT NULL DEFAULT '0' COMMENT '编号id',
  `wjid` int(11) NOT NULL DEFAULT '0' COMMENT '玩家id',
  `wjmz` text NOT NULL COMMENT '玩家名字',
  `zltime` datetime NOT NULL COMMENT '占领时间',
  `zlmb` int(11) NOT NULL DEFAULT '0' COMMENT '占领膜拜',
  `lthp` text NOT NULL COMMENT '擂台hp',
  `ltgj` text NOT NULL COMMENT '擂台攻击',
  `ltmg` text NOT NULL COMMENT '擂台魔攻',
  `ltfy` text NOT NULL COMMENT '擂台防御',
  `ltmp` text NOT NULL COMMENT '擂台门派'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `all_ltbw`
--

LOCK TABLES `all_ltbw` WRITE;
/*!40000 ALTER TABLE `all_ltbw` DISABLE KEYS */;
/*!40000 ALTER TABLE `all_ltbw` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `all_money`
--

DROP TABLE IF EXISTS `all_money`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `all_money` (
  `wjid` int(11) NOT NULL,
  `wjmz` text NOT NULL,
  `money` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `all_money`
--

LOCK TABLES `all_money` WRITE;
/*!40000 ALTER TABLE `all_money` DISABLE KEYS */;
/*!40000 ALTER TABLE `all_money` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `all_moneyjc`
--

DROP TABLE IF EXISTS `all_moneyjc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `all_moneyjc` (
  `id` int(11) NOT NULL,
  `money` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `all_moneyjc`
--

LOCK TABLES `all_moneyjc` WRITE;
/*!40000 ALTER TABLE `all_moneyjc` DISABLE KEYS */;
/*!40000 ALTER TABLE `all_moneyjc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `all_pay`
--

DROP TABLE IF EXISTS `all_pay`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `all_pay` (
  `id` int(11) NOT NULL,
  `payid` text NOT NULL,
  `paywjid` int(11) NOT NULL,
  `price` text NOT NULL,
  `payzf` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `all_pay`
--

LOCK TABLES `all_pay` WRITE;
/*!40000 ALTER TABLE `all_pay` DISABLE KEYS */;
/*!40000 ALTER TABLE `all_pay` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `all_phb`
--

DROP TABLE IF EXISTS `all_phb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `all_phb` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '标识',
  `wjid` int(11) NOT NULL COMMENT '玩家id',
  `wjmz` varchar(16) NOT NULL COMMENT '玩家名字',
  `vip` int(11) NOT NULL,
  `phb1` bigint(250) unsigned NOT NULL COMMENT '气血榜',
  `phb2` bigint(250) unsigned NOT NULL COMMENT '攻击榜',
  `phb3` bigint(250) unsigned NOT NULL COMMENT '魔攻榜',
  `phb4` bigint(250) unsigned NOT NULL COMMENT '防御榜',
  `phb5` bigint(250) unsigned NOT NULL COMMENT '等级榜',
  `phb6` bigint(250) unsigned NOT NULL COMMENT '战力榜',
  `phb7` bigint(250) unsigned NOT NULL COMMENT '金豆榜',
  `phb8` bigint(250) unsigned NOT NULL COMMENT '充值榜',
  `php9` bigint(250) unsigned NOT NULL COMMENT '战力榜',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `all_phb`
--

LOCK TABLES `all_phb` WRITE;
/*!40000 ALTER TABLE `all_phb` DISABLE KEYS */;
/*!40000 ALTER TABLE `all_phb` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `all_pk`
--

DROP TABLE IF EXISTS `all_pk`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `all_pk` (
  `pk_id` int(11) NOT NULL DEFAULT '0',
  `pk_wjid` int(11) NOT NULL DEFAULT '0',
  `pk_name` varchar(11) NOT NULL DEFAULT '0',
  `pk_max_hp` int(50) NOT NULL DEFAULT '0',
  `pk_max_mp` int(50) NOT NULL DEFAULT '0',
  `pk_gj` int(50) NOT NULL DEFAULT '0',
  `pk_fy` int(50) NOT NULL DEFAULT '0',
  `pk_mg` int(50) NOT NULL DEFAULT '0',
  `pk_bg` int(50) NOT NULL DEFAULT '0',
  `pk_hg` int(50) NOT NULL DEFAULT '0',
  `pk_lg` int(50) NOT NULL DEFAULT '0',
  `pk_bf` int(50) NOT NULL DEFAULT '0',
  `pk_hf` int(50) NOT NULL DEFAULT '0',
  `pk_lf` int(50) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `all_pk`
--

LOCK TABLES `all_pk` WRITE;
/*!40000 ALTER TABLE `all_pk` DISABLE KEYS */;
/*!40000 ALTER TABLE `all_pk` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `all_pm`
--

DROP TABLE IF EXISTS `all_pm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `all_pm` (
  `id` int(11) NOT NULL DEFAULT '0' COMMENT '标识',
  `wjid` int(11) NOT NULL DEFAULT '0' COMMENT '玩家id',
  `wjmz` text NOT NULL COMMENT '玩家名字',
  `pmtime` datetime NOT NULL COMMENT '拍卖时间',
  `pmwpid` int(11) NOT NULL DEFAULT '0' COMMENT '拍卖物品id',
  `pmwpmz` text NOT NULL COMMENT '拍卖物品名字',
  `pmwpsl` int(11) NOT NULL DEFAULT '0' COMMENT '拍卖物品数量',
  `pmwpjg` text NOT NULL COMMENT '拍卖物品价格',
  `pmsjc` int(11) NOT NULL DEFAULT '0' COMMENT '拍卖时间搓',
  `pmwpfl` int(11) NOT NULL DEFAULT '0' COMMENT '拍卖物品分类'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `all_pm`
--

LOCK TABLES `all_pm` WRITE;
/*!40000 ALTER TABLE `all_pm` DISABLE KEYS */;
/*!40000 ALTER TABLE `all_pm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `all_qd`
--

DROP TABLE IF EXISTS `all_qd`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `all_qd` (
  `id` int(11) NOT NULL,
  `wjid` int(11) NOT NULL COMMENT '玩家id',
  `qdsj` datetime NOT NULL COMMENT '签到时间',
  `qdcs` int(11) NOT NULL COMMENT '签到次数',
  `qdy` int(11) NOT NULL COMMENT '签到月份',
  `qd1` int(11) NOT NULL COMMENT '签到1',
  `qd2` int(11) NOT NULL COMMENT '签到2',
  `qd3` int(11) NOT NULL COMMENT '签到3',
  `qd4` int(11) NOT NULL COMMENT '签到4',
  `qd5` int(11) NOT NULL COMMENT '签到5'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `all_qd`
--

LOCK TABLES `all_qd` WRITE;
/*!40000 ALTER TABLE `all_qd` DISABLE KEYS */;
/*!40000 ALTER TABLE `all_qd` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `all_qggz`
--

DROP TABLE IF EXISTS `all_qggz`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `all_qggz` (
  `id` int(11) NOT NULL,
  `qgxx` text NOT NULL,
  `qgmz` text NOT NULL,
  `wjid` int(11) NOT NULL,
  `qgjg` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `all_qggz`
--

LOCK TABLES `all_qggz` WRITE;
/*!40000 ALTER TABLE `all_qggz` DISABLE KEYS */;
/*!40000 ALTER TABLE `all_qggz` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `all_qtjc`
--

DROP TABLE IF EXISTS `all_qtjc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `all_qtjc` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '编号id',
  `wjid` int(11) NOT NULL DEFAULT '0' COMMENT '玩家id',
  `vip` int(11) NOT NULL DEFAULT '0' COMMENT 'vip等级',
  `wjmz` varchar(32) NOT NULL COMMENT '玩家名字',
  `jcjg` varchar(255) NOT NULL COMMENT '竞猜价格',
  `cq` int(11) NOT NULL DEFAULT '0' COMMENT '出拳',
  `timex` varchar(32) NOT NULL COMMENT '竞猜时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `all_qtjc`
--

LOCK TABLES `all_qtjc` WRITE;
/*!40000 ALTER TABLE `all_qtjc` DISABLE KEYS */;
/*!40000 ALTER TABLE `all_qtjc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `all_sdk`
--

DROP TABLE IF EXISTS `all_sdk`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `all_sdk` (
  `sdkid` int(11) NOT NULL,
  `sdk` text NOT NULL,
  `sdktime` datetime NOT NULL,
  `sdkfl` int(11) NOT NULL,
  `sdksy` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `all_sdk`
--

LOCK TABLES `all_sdk` WRITE;
/*!40000 ALTER TABLE `all_sdk` DISABLE KEYS */;
/*!40000 ALTER TABLE `all_sdk` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `all_sq`
--

DROP TABLE IF EXISTS `all_sq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `all_sq` (
  `wjid` int(11) NOT NULL DEFAULT '0' COMMENT '玩家ID',
  `sqpj1` int(11) unsigned zerofill NOT NULL DEFAULT '00000000000' COMMENT '神器等级',
  `sqpj2` int(11) unsigned zerofill NOT NULL DEFAULT '00000000000' COMMENT '神器等级',
  `sqpj3` int(11) unsigned zerofill NOT NULL DEFAULT '00000000000' COMMENT '神器等级',
  PRIMARY KEY (`wjid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `all_sq`
--

LOCK TABLES `all_sq` WRITE;
/*!40000 ALTER TABLE `all_sq` DISABLE KEYS */;
/*!40000 ALTER TABLE `all_sq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `all_sxd`
--

DROP TABLE IF EXISTS `all_sxd`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `all_sxd` (
  `wjid` int(11) NOT NULL,
  `sxd` int(11) NOT NULL,
  `sx_hp` int(11) NOT NULL,
  `sx_mp` int(11) NOT NULL,
  `sx_gj` int(11) NOT NULL,
  `sx_fy` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `all_sxd`
--

LOCK TABLES `all_sxd` WRITE;
/*!40000 ALTER TABLE `all_sxd` DISABLE KEYS */;
/*!40000 ALTER TABLE `all_sxd` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `all_sz`
--

DROP TABLE IF EXISTS `all_sz`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `all_sz` (
  `wjid` int(11) NOT NULL,
  `sz_lvl` int(11) NOT NULL,
  `sz_cs` int(11) NOT NULL,
  `sz_sx` int(250) NOT NULL,
  `mtcs` int(11) NOT NULL,
  `tzcs_1` int(11) NOT NULL,
  `tzcs_2` int(11) NOT NULL,
  `tzcs_3` int(11) NOT NULL,
  `tzcs_4` int(11) NOT NULL,
  `tzcs_5` int(11) NOT NULL,
  `tzcs_6` int(11) NOT NULL,
  `tzcs_7` int(11) NOT NULL,
  `tzcs_8` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `all_sz`
--

LOCK TABLES `all_sz` WRITE;
/*!40000 ALTER TABLE `all_sz` DISABLE KEYS */;
/*!40000 ALTER TABLE `all_sz` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `all_user`
--

DROP TABLE IF EXISTS `all_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `all_user` (
  `wjid` int(11) NOT NULL,
  `id` int(11) NOT NULL,
  `wjname` text NOT NULL,
  `wjtime` datetime NOT NULL,
  `utime` int(11) NOT NULL,
  `fl` int(11) NOT NULL,
  `yj` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `all_user`
--

LOCK TABLES `all_user` WRITE;
/*!40000 ALTER TABLE `all_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `all_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `all_xjhb`
--

DROP TABLE IF EXISTS `all_xjhb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `all_xjhb` (
  `id` int(11) NOT NULL,
  `wjid` int(11) NOT NULL,
  `wjmz` text NOT NULL,
  `wjje` int(11) NOT NULL,
  `zh1` text NOT NULL,
  `zh2` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `all_xjhb`
--

LOCK TABLES `all_xjhb` WRITE;
/*!40000 ALTER TABLE `all_xjhb` DISABLE KEYS */;
/*!40000 ALTER TABLE `all_xjhb` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `all_yd01`
--

DROP TABLE IF EXISTS `all_yd01`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `all_yd01` (
  `id` int(11) NOT NULL,
  `wjid` int(11) NOT NULL,
  `wjmz` text NOT NULL,
  `vip` int(11) NOT NULL,
  `ds01` int(11) NOT NULL,
  `ds02` int(11) NOT NULL,
  `dy01_time` datetime NOT NULL,
  `yd01` int(11) NOT NULL COMMENT '免费',
  `yd02` int(11) NOT NULL COMMENT '收费'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `all_yd01`
--

LOCK TABLES `all_yd01` WRITE;
/*!40000 ALTER TABLE `all_yd01` DISABLE KEYS */;
/*!40000 ALTER TABLE `all_yd01` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `all_yd02`
--

DROP TABLE IF EXISTS `all_yd02`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `all_yd02` (
  `id` int(11) NOT NULL,
  `wjid` int(11) NOT NULL,
  `wjmz` text NOT NULL,
  `vip` int(11) NOT NULL,
  `ds01` int(11) NOT NULL,
  `ds02` int(11) NOT NULL,
  `dy01_time` datetime NOT NULL,
  `yd01` int(11) NOT NULL COMMENT '免费',
  `yd02` int(11) NOT NULL COMMENT '收费'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `all_yd02`
--

LOCK TABLES `all_yd02` WRITE;
/*!40000 ALTER TABLE `all_yd02` DISABLE KEYS */;
/*!40000 ALTER TABLE `all_yd02` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `all_yd03`
--

DROP TABLE IF EXISTS `all_yd03`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `all_yd03` (
  `id` int(11) NOT NULL,
  `wjid` int(11) NOT NULL,
  `wjmz` text NOT NULL,
  `vip` int(11) NOT NULL,
  `ds01` int(11) NOT NULL,
  `ds02` int(11) NOT NULL,
  `dy01_time` datetime NOT NULL,
  `yd01` int(11) NOT NULL COMMENT '免费',
  `yd02` int(11) NOT NULL COMMENT '收费'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `all_yd03`
--

LOCK TABLES `all_yd03` WRITE;
/*!40000 ALTER TABLE `all_yd03` DISABLE KEYS */;
/*!40000 ALTER TABLE `all_yd03` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `all_yd04`
--

DROP TABLE IF EXISTS `all_yd04`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `all_yd04` (
  `id` int(11) NOT NULL,
  `wjid` int(11) NOT NULL,
  `wjmz` text NOT NULL,
  `vip` int(11) NOT NULL,
  `ds01` int(11) NOT NULL,
  `ds02` int(11) NOT NULL,
  `dy01_time` datetime NOT NULL,
  `yd01` int(11) NOT NULL COMMENT '免费',
  `yd02` int(11) NOT NULL COMMENT '收费'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `all_yd04`
--

LOCK TABLES `all_yd04` WRITE;
/*!40000 ALTER TABLE `all_yd04` DISABLE KEYS */;
/*!40000 ALTER TABLE `all_yd04` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `all_yl`
--

DROP TABLE IF EXISTS `all_yl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `all_yl` (
  `wjid` int(11) NOT NULL COMMENT '玩家id',
  `bbyl` text NOT NULL COMMENT '背包银两',
  `ckyl` text NOT NULL COMMENT '仓库银两'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `all_yl`
--

LOCK TABLES `all_yl` WRITE;
/*!40000 ALTER TABLE `all_yl` DISABLE KEYS */;
/*!40000 ALTER TABLE `all_yl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `all_ylck`
--

DROP TABLE IF EXISTS `all_ylck`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `all_ylck` (
  `wjid` int(11) NOT NULL DEFAULT '0' COMMENT '玩家id',
  `yl01` text NOT NULL COMMENT '银两',
  `yl02` text NOT NULL COMMENT '金豆',
  `yl03` text NOT NULL COMMENT '金带'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `all_ylck`
--

LOCK TABLES `all_ylck` WRITE;
/*!40000 ALTER TABLE `all_ylck` DISABLE KEYS */;
/*!40000 ALTER TABLE `all_ylck` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `all_zq`
--

DROP TABLE IF EXISTS `all_zq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `all_zq` (
  `wjid` int(11) NOT NULL,
  `zq_mz` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `zq_id` int(11) NOT NULL,
  `zq_lvl` int(11) NOT NULL,
  `zq_zj` int(11) NOT NULL,
  `zq_pj` int(11) NOT NULL,
  `zq_xj` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `all_zq`
--

LOCK TABLES `all_zq` WRITE;
/*!40000 ALTER TABLE `all_zq` DISABLE KEYS */;
/*!40000 ALTER TABLE `all_zq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `all_zt`
--

DROP TABLE IF EXISTS `all_zt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `all_zt` (
  `wjid` int(11) NOT NULL COMMENT '玩家id',
  `username` varchar(16) NOT NULL COMMENT '玩家名字',
  `sex` int(11) NOT NULL COMMENT '玩家性别',
  `tx` varchar(64) NOT NULL COMMENT '玩家头衔',
  `peiou` varchar(32) NOT NULL COMMENT '配偶名字',
  `peiouid` int(11) NOT NULL COMMENT '配偶ID',
  `zzmz` varchar(32) NOT NULL COMMENT '住宅名字',
  `zzid` int(11) NOT NULL COMMENT '住宅ID',
  `zzfl` int(11) NOT NULL COMMENT '住宅分类',
  `zcxx` int(11) NOT NULL,
  `dj` int(11) NOT NULL COMMENT '玩家等级',
  `mpp` int(11) NOT NULL COMMENT '门派',
  `bpmz` varchar(32) NOT NULL COMMENT '帮派名字',
  `bpid` int(11) NOT NULL COMMENT '帮派ID',
  `vip` int(11) NOT NULL COMMENT 'VIP等级',
  `vipjy` int(11) NOT NULL COMMENT 'VIP经验',
  `gsrl` int(11) NOT NULL COMMENT '挂售容量',
  `bbrl` int(11) NOT NULL COMMENT '背包容量',
  `ckrl` int(11) NOT NULL COMMENT '仓库容量',
  `emz` int(11) NOT NULL COMMENT '恶名值',
  `lh` int(11) NOT NULL COMMENT '靓号',
  `sqpj_1` int(11) NOT NULL DEFAULT '1',
  `sqpj_2` int(11) NOT NULL DEFAULT '1',
  `sqpj_3` int(11) NOT NULL DEFAULT '1',
  `sqxj_1` int(11) NOT NULL DEFAULT '1',
  `sqxj_2` int(11) NOT NULL DEFAULT '1',
  `sqxj_3` int(11) NOT NULL DEFAULT '1',
  `u_fmtcs` int(11) NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `all_zt`
--

LOCK TABLES `all_zt` WRITE;
/*!40000 ALTER TABLE `all_zt` DISABLE KEYS */;
INSERT INTO `all_zt` VALUES (10000001,'',0,'','',0,'',0,0,0,0,0,'',0,0,0,0,0,0,0,0,1,1,1,1,1,1,1);
/*!40000 ALTER TABLE `all_zt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bl`
--

DROP TABLE IF EXISTS `bl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bl` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fqid` int(10) unsigned NOT NULL DEFAULT '0',
  `bll1` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bl`
--

LOCK TABLES `bl` WRITE;
/*!40000 ALTER TABLE `bl` DISABLE KEYS */;
/*!40000 ALTER TABLE `bl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bp`
--

DROP TABLE IF EXISTS `bp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bp` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `bpid` int(10) unsigned NOT NULL DEFAULT '0',
  `usermz` varchar(100) NOT NULL DEFAULT '',
  `userid` int(10) unsigned NOT NULL DEFAULT '0',
  `gx` int(10) unsigned NOT NULL DEFAULT '0',
  `bpswcs` int(10) unsigned NOT NULL DEFAULT '0',
  `bpjf` int(10) unsigned NOT NULL DEFAULT '0',
  `lsgx` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bp`
--

LOCK TABLES `bp` WRITE;
/*!40000 ALTER TABLE `bp` DISABLE KEYS */;
/*!40000 ALTER TABLE `bp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ckqt`
--

DROP TABLE IF EXISTS `ckqt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ckqt` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `wjid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '玩家ID',
  `wpid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '物品ID',
  `wpsl` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '物品数量',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='仓库其他物品';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ckqt`
--

LOCK TABLES `ckqt` WRITE;
/*!40000 ALTER TABLE `ckqt` DISABLE KEYS */;
/*!40000 ALTER TABLE `ckqt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ckwp`
--

DROP TABLE IF EXISTS `ckwp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ckwp` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '编号ID',
  `wjid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '玩家ID',
  `wpid` int(11) NOT NULL DEFAULT '0' COMMENT '仓库物品ID',
  `wpsl` int(11) NOT NULL DEFAULT '0' COMMENT '仓库物品数量',
  `wpfl` int(11) NOT NULL DEFAULT '0' COMMENT '仓库物品分类',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='仓库物品';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ckwp`
--

LOCK TABLES `ckwp` WRITE;
/*!40000 ALTER TABLE `ckwp` DISABLE KEYS */;
/*!40000 ALTER TABLE `ckwp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ckzb`
--

DROP TABLE IF EXISTS `ckzb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ckzb` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '编号ID',
  `wjid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '玩家ID',
  `zbid` int(11) NOT NULL DEFAULT '0' COMMENT '仓库装备ID',
  `zbxj` int(11) NOT NULL DEFAULT '0' COMMENT '仓库装备星级',
  `zbk1` int(11) NOT NULL DEFAULT '0' COMMENT '仓库装备孔1',
  `zbxq1` int(11) NOT NULL DEFAULT '0' COMMENT '仓库镶嵌1',
  `zbk2` int(11) NOT NULL DEFAULT '0' COMMENT '仓库装备孔2',
  `zbxq2` int(11) NOT NULL DEFAULT '0' COMMENT '仓库镶嵌2',
  `zbk3` int(11) NOT NULL DEFAULT '0' COMMENT '仓库装备孔3',
  `zbxq3` int(11) NOT NULL DEFAULT '0' COMMENT '仓库镶嵌3',
  `zbk4` int(11) NOT NULL DEFAULT '0' COMMENT '仓库装备孔4',
  `zbxq4` int(11) NOT NULL DEFAULT '0' COMMENT '仓库镶嵌4',
  `zbk5` int(11) NOT NULL DEFAULT '0' COMMENT '仓库装备孔5',
  `zbxq5` int(11) NOT NULL DEFAULT '0' COMMENT '仓库镶嵌5',
  `zbpd` int(11) NOT NULL DEFAULT '0' COMMENT '仓库装备佩戴',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='仓库装备';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ckzb`
--

LOCK TABLES `ckzb` WRITE;
/*!40000 ALTER TABLE `ckzb` DISABLE KEYS */;
/*!40000 ALTER TABLE `ckzb` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cw`
--

DROP TABLE IF EXISTS `cw`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cw` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '编号ID',
  `wjid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '玩家ID',
  `cwid` int(11) NOT NULL DEFAULT '0' COMMENT '宠物id',
  `cwmz` text NOT NULL COMMENT '宠物名字',
  `cwdj` int(11) NOT NULL DEFAULT '0' COMMENT '宠物等级',
  `cwxj` int(11) NOT NULL DEFAULT '0' COMMENT '宠物星级',
  `cwby` int(11) NOT NULL DEFAULT '0' COMMENT '宠物变异',
  `cwxb` int(11) NOT NULL DEFAULT '0' COMMENT '宠物品质',
  `cwcz` int(11) NOT NULL DEFAULT '0' COMMENT '宠物出战',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='宠物';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cw`
--

LOCK TABLES `cw` WRITE;
/*!40000 ALTER TABLE `cw` DISABLE KEYS */;
/*!40000 ALTER TABLE `cw` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cwzbb`
--

DROP TABLE IF EXISTS `cwzbb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cwzbb` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '编号ID',
  `wjid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '玩家ID',
  `zbid` int(11) NOT NULL DEFAULT '0' COMMENT '装备ID',
  `zbxj` int(11) NOT NULL DEFAULT '0' COMMENT '装备星级',
  `zbsj` int(11) DEFAULT '0',
  `zbk1` int(11) NOT NULL DEFAULT '0' COMMENT '装备孔1',
  `zbxq1` int(11) NOT NULL DEFAULT '0' COMMENT '镶嵌1',
  `zbk2` int(11) NOT NULL DEFAULT '0' COMMENT '装备孔2',
  `zbxq2` int(11) NOT NULL DEFAULT '0' COMMENT '镶嵌2',
  `zbk3` int(11) NOT NULL DEFAULT '0' COMMENT '装备孔3',
  `zbxq3` int(11) NOT NULL DEFAULT '0' COMMENT '镶嵌3',
  `zbk4` int(11) NOT NULL DEFAULT '0' COMMENT '装备孔4',
  `zbxq4` int(11) NOT NULL DEFAULT '0' COMMENT '镶嵌4',
  `zbk5` int(11) NOT NULL DEFAULT '0' COMMENT '装备孔5',
  `zbxq5` int(11) NOT NULL DEFAULT '0' COMMENT '镶嵌5',
  `zbfl` int(11) NOT NULL DEFAULT '0' COMMENT '装备分类',
  `cwid` text NOT NULL COMMENT '宠物ID',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cwzbb`
--

LOCK TABLES `cwzbb` WRITE;
/*!40000 ALTER TABLE `cwzbb` DISABLE KEYS */;
/*!40000 ALTER TABLE `cwzbb` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dyxx`
--

DROP TABLE IF EXISTS `dyxx`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dyxx` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `wjid` int(10) unsigned NOT NULL DEFAULT '0',
  `wpid` int(11) NOT NULL DEFAULT '0' COMMENT '丹药ID',
  `sycs` int(11) NOT NULL DEFAULT '0' COMMENT '丹药使用次数',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dyxx`
--

LOCK TABLES `dyxx` WRITE;
/*!40000 ALTER TABLE `dyxx` DISABLE KEYS */;
/*!40000 ALTER TABLE `dyxx` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fb`
--

DROP TABLE IF EXISTS `fb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fb` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `wjid` int(10) unsigned NOT NULL DEFAULT '0',
  `fbid` int(11) NOT NULL DEFAULT '0' COMMENT '编号ID',
  `fb` datetime NOT NULL COMMENT '副本时间',
  `wc` int(11) NOT NULL DEFAULT '0' COMMENT '副本完成',
  `cs` int(11) NOT NULL DEFAULT '0' COMMENT '副本次数',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fb`
--

LOCK TABLES `fb` WRITE;
/*!40000 ALTER TABLE `fb` DISABLE KEYS */;
/*!40000 ALTER TABLE `fb` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fstcz`
--

DROP TABLE IF EXISTS `fstcz`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fstcz` (
  `wjid` int(11) NOT NULL,
  `hdid` int(11) NOT NULL,
  `hdtime` int(11) NOT NULL,
  `hdcs` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fstcz`
--

LOCK TABLES `fstcz` WRITE;
/*!40000 ALTER TABLE `fstcz` DISABLE KEYS */;
/*!40000 ALTER TABLE `fstcz` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gccz`
--

DROP TABLE IF EXISTS `gccz`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gccz` (
  `wjid` int(11) NOT NULL,
  `hdid` int(11) NOT NULL,
  `hdtime` int(11) NOT NULL,
  `hdcs` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gccz`
--

LOCK TABLES `gccz` WRITE;
/*!40000 ALTER TABLE `gccz` DISABLE KEYS */;
/*!40000 ALTER TABLE `gccz` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gmuser`
--

DROP TABLE IF EXISTS `gmuser`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gmuser` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) NOT NULL,
  `username` varchar(25) NOT NULL,
  `password` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gmuser`
--

LOCK TABLES `gmuser` WRITE;
/*!40000 ALTER TABLE `gmuser` DISABLE KEYS */;
/*!40000 ALTER TABLE `gmuser` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gsqt`
--

DROP TABLE IF EXISTS `gsqt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gsqt` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '编号ID',
  `wjid` int(10) unsigned NOT NULL DEFAULT '0',
  `wpid` int(11) NOT NULL DEFAULT '0' COMMENT '挂售其他id',
  `wpsl` int(11) NOT NULL DEFAULT '0' COMMENT '挂售其他数量',
  `gsjg` text NOT NULL COMMENT '挂售价格',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gsqt`
--

LOCK TABLES `gsqt` WRITE;
/*!40000 ALTER TABLE `gsqt` DISABLE KEYS */;
/*!40000 ALTER TABLE `gsqt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gswp`
--

DROP TABLE IF EXISTS `gswp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gswp` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '编号ID',
  `wjid` int(10) unsigned NOT NULL DEFAULT '0',
  `wpid` int(11) NOT NULL DEFAULT '0' COMMENT '挂售物品id',
  `wpsl` int(11) NOT NULL DEFAULT '0' COMMENT '挂售物品数量',
  `gsjg` text NOT NULL COMMENT '挂售价格',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gswp`
--

LOCK TABLES `gswp` WRITE;
/*!40000 ALTER TABLE `gswp` DISABLE KEYS */;
/*!40000 ALTER TABLE `gswp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gszb`
--

DROP TABLE IF EXISTS `gszb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gszb` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '编号ID',
  `wjid` int(10) unsigned NOT NULL DEFAULT '0',
  `zbid` int(11) NOT NULL DEFAULT '0' COMMENT '挂售装备ID',
  `zbxj` int(11) NOT NULL DEFAULT '0' COMMENT '挂售装备星级',
  `zbk1` int(11) NOT NULL DEFAULT '0' COMMENT '挂售装备孔1',
  `zbxq1` int(11) NOT NULL DEFAULT '0' COMMENT '挂售镶嵌1',
  `zbk2` int(11) NOT NULL DEFAULT '0' COMMENT '挂售装备孔2',
  `zbxq2` int(11) NOT NULL DEFAULT '0' COMMENT '挂售镶嵌2',
  `zbk3` int(11) NOT NULL DEFAULT '0' COMMENT '挂售装备孔3',
  `zbxq3` int(11) NOT NULL DEFAULT '0' COMMENT '挂售镶嵌3',
  `zbk4` int(11) NOT NULL DEFAULT '0' COMMENT '挂售装备孔4',
  `zbxq4` int(11) NOT NULL DEFAULT '0' COMMENT '挂售镶嵌4',
  `zbk5` int(11) NOT NULL DEFAULT '0' COMMENT '挂售装备孔5',
  `zbxq5` int(11) NOT NULL DEFAULT '0' COMMENT '挂售镶嵌5',
  `zbpd` int(11) NOT NULL DEFAULT '0' COMMENT '挂售装备佩戴',
  `gsjg` text NOT NULL COMMENT '挂售价格',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gszb`
--

LOCK TABLES `gszb` WRITE;
/*!40000 ALTER TABLE `gszb` DISABLE KEYS */;
/*!40000 ALTER TABLE `gszb` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gz01`
--

DROP TABLE IF EXISTS `gz01`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gz01` (
  `zcid` int(11) NOT NULL,
  `zlgj` text NOT NULL,
  `zlgjid` int(11) NOT NULL,
  `gjjz` text NOT NULL,
  `gjjzid` int(11) NOT NULL,
  `czz` text NOT NULL,
  `czzid` int(11) NOT NULL,
  `zlsj` char(8) NOT NULL DEFAULT '' COMMENT '占领时间',
  `czwz` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '夺杖后重置位置'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gz01`
--

LOCK TABLES `gz01` WRITE;
/*!40000 ALTER TABLE `gz01` DISABLE KEYS */;
/*!40000 ALTER TABLE `gz01` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gz03`
--

DROP TABLE IF EXISTS `gz03`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gz03` (
  `id` int(11) NOT NULL,
  `gjmz` varchar(16) NOT NULL DEFAULT '',
  `gjid` int(11) NOT NULL DEFAULT '0',
  `jzmz` varchar(16) NOT NULL DEFAULT '',
  `jzid` int(11) NOT NULL DEFAULT '0',
  `zjf` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '周积分',
  `rjf` int(11) NOT NULL DEFAULT '0' COMMENT '日积分',
  `cjsj` char(8) NOT NULL DEFAULT '' COMMENT '参加时间',
  `zlq` int(11) NOT NULL DEFAULT '0',
  `rlq` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '日领取'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gz03`
--

LOCK TABLES `gz03` WRITE;
/*!40000 ALTER TABLE `gz03` DISABLE KEYS */;
/*!40000 ALTER TABLE `gz03` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gz04`
--

DROP TABLE IF EXISTS `gz04`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gz04` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `wjid` int(11) NOT NULL DEFAULT '0',
  `wjmz` varchar(16) NOT NULL,
  `zjf` int(11) NOT NULL DEFAULT '0' COMMENT '周积分',
  `rjf` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '日积分',
  `swcs` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '死亡次数',
  `swsj` timestamp NULL DEFAULT NULL COMMENT '死亡时间',
  `cjsj` char(8) NOT NULL DEFAULT '' COMMENT '参加时间',
  `zlq` int(11) NOT NULL DEFAULT '0' COMMENT '周领取',
  `rlq` int(11) NOT NULL DEFAULT '0' COMMENT '日领取',
  `czwz` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '夺杖后重置战场位置',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gz04`
--

LOCK TABLES `gz04` WRITE;
/*!40000 ALTER TABLE `gz04` DISABLE KEYS */;
/*!40000 ALTER TABLE `gz04` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gz05`
--

DROP TABLE IF EXISTS `gz05`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gz05` (
  `id` int(11) NOT NULL,
  `gztime` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gz05`
--

LOCK TABLES `gz05` WRITE;
/*!40000 ALTER TABLE `gz05` DISABLE KEYS */;
/*!40000 ALTER TABLE `gz05` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gz06`
--

DROP TABLE IF EXISTS `gz06`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gz06` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fsgjid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '防守国家id',
  `fsgj` varchar(16) NOT NULL DEFAULT '' COMMENT '防守国家',
  `fssj` timestamp NULL DEFAULT NULL COMMENT '防守时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gz06`
--

LOCK TABLES `gz06` WRITE;
/*!40000 ALTER TABLE `gz06` DISABLE KEYS */;
/*!40000 ALTER TABLE `gz06` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hd`
--

DROP TABLE IF EXISTS `hd`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hd` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `wjid` int(10) unsigned NOT NULL DEFAULT '0',
  `hdid` int(11) NOT NULL DEFAULT '0' COMMENT '编号ID',
  `hdtime` datetime NOT NULL COMMENT '活动时间',
  `hdcs` int(11) NOT NULL DEFAULT '0' COMMENT '活动次数',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hd`
--

LOCK TABLES `hd` WRITE;
/*!40000 ALTER TABLE `hd` DISABLE KEYS */;
/*!40000 ALTER TABLE `hd` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hddl`
--

DROP TABLE IF EXISTS `hddl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hddl` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `mz` varchar(32) NOT NULL DEFAULT '' COMMENT '活动名字',
  `kq` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '是否开启',
  `kssj` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '开始时间',
  `jssj` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '结束时间',
  `kqfs` int(10) unsigned NOT NULL DEFAULT '1' COMMENT '开启方式，1手动，2按时间自动开启',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hddl`
--

LOCK TABLES `hddl` WRITE;
/*!40000 ALTER TABLE `hddl` DISABLE KEYS */;
/*!40000 ALTER TABLE `hddl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hy`
--

DROP TABLE IF EXISTS `hy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hy` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '编号ID',
  `wjid` int(10) unsigned NOT NULL DEFAULT '0',
  `hyid` int(11) NOT NULL DEFAULT '0' COMMENT '好友id',
  `hymz` text NOT NULL COMMENT '好友名字',
  `hyfl` int(11) NOT NULL DEFAULT '0' COMMENT '好友分类',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hy`
--

LOCK TABLES `hy` WRITE;
/*!40000 ALTER TABLE `hy` DISABLE KEYS */;
/*!40000 ALTER TABLE `hy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jfdj`
--

DROP TABLE IF EXISTS `jfdj`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jfdj` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '编号id',
  `wjid` int(10) unsigned NOT NULL DEFAULT '0',
  `jfid` int(10) unsigned NOT NULL DEFAULT '0',
  `jfdj` int(11) NOT NULL DEFAULT '0' COMMENT '解封等级',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jfdj`
--

LOCK TABLES `jfdj` WRITE;
/*!40000 ALTER TABLE `jfdj` DISABLE KEYS */;
/*!40000 ALTER TABLE `jfdj` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jj`
--

DROP TABLE IF EXISTS `jj`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jj` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '编号ID',
  `wjid` int(10) unsigned NOT NULL DEFAULT '0',
  `jjid` int(11) NOT NULL DEFAULT '0' COMMENT '家具ID',
  `jjdj` int(11) NOT NULL DEFAULT '0' COMMENT '家具等级',
  `jjbf` int(11) NOT NULL DEFAULT '0' COMMENT '家具摆放',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jj`
--

LOCK TABLES `jj` WRITE;
/*!40000 ALTER TABLE `jj` DISABLE KEYS */;
/*!40000 ALTER TABLE `jj` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jnn`
--

DROP TABLE IF EXISTS `jnn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jnn` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '编号ID',
  `wjid` int(10) unsigned NOT NULL DEFAULT '0',
  `jnid` int(11) NOT NULL DEFAULT '0' COMMENT '技能id',
  `jndj` int(11) NOT NULL DEFAULT '0' COMMENT '技能等级',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jnn`
--

LOCK TABLES `jnn` WRITE;
/*!40000 ALTER TABLE `jnn` DISABLE KEYS */;
/*!40000 ALTER TABLE `jnn` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `map`
--

DROP TABLE IF EXISTS `map`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `map` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `mz` varchar(32) NOT NULL DEFAULT '',
  `ms` varchar(100) NOT NULL DEFAULT '',
  `dtx` int(10) unsigned NOT NULL DEFAULT '0',
  `dty` int(10) unsigned NOT NULL DEFAULT '0',
  `dtxy` varchar(100) NOT NULL DEFAULT '',
  `up` varchar(100) NOT NULL DEFAULT '',
  `down` varchar(100) NOT NULL DEFAULT '',
  `left` varchar(100) NOT NULL DEFAULT '',
  `right` varchar(100) NOT NULL DEFAULT '',
  `up_jump` varchar(100) NOT NULL DEFAULT '',
  `down_jump` varchar(100) NOT NULL DEFAULT '',
  `left_jump` varchar(100) NOT NULL DEFAULT '',
  `right_jump` varchar(100) NOT NULL DEFAULT '',
  `up_distance` int(10) unsigned NOT NULL DEFAULT '0',
  `down_distance` int(10) unsigned NOT NULL DEFAULT '0',
  `left_distance` int(10) unsigned NOT NULL DEFAULT '0',
  `right_distance` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `map_dtxy_IDX` (`dtxy`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `map`
--

LOCK TABLES `map` WRITE;
/*!40000 ALTER TABLE `map` DISABLE KEYS */;
/*!40000 ALTER TABLE `map` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mtcz`
--

DROP TABLE IF EXISTS `mtcz`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mtcz` (
  `wjid` int(11) NOT NULL,
  `hdid` int(11) NOT NULL,
  `hdtime` int(11) NOT NULL,
  `hdcs` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mtcz`
--

LOCK TABLES `mtcz` WRITE;
/*!40000 ALTER TABLE `mtcz` DISABLE KEYS */;
/*!40000 ALTER TABLE `mtcz` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `o_user_list`
--

DROP TABLE IF EXISTS `o_user_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `o_user_list` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `sqid` text NOT NULL,
  `m_id` varchar(5) NOT NULL,
  `password` varchar(64) NOT NULL,
  `n` int(11) NOT NULL DEFAULT '0' COMMENT '年',
  `y` int(11) NOT NULL DEFAULT '0' COMMENT '月',
  `r` int(11) NOT NULL DEFAULT '0' COMMENT '日',
  `s` int(11) NOT NULL DEFAULT '0' COMMENT '时',
  `f` int(11) NOT NULL DEFAULT '0' COMMENT '分',
  `m` int(11) NOT NULL DEFAULT '0' COMMENT '秒',
  PRIMARY KEY (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `o_user_list`
--

LOCK TABLES `o_user_list` WRITE;
/*!40000 ALTER TABLE `o_user_list` DISABLE KEYS */;
/*!40000 ALTER TABLE `o_user_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `qt`
--

DROP TABLE IF EXISTS `qt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qt` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `wjid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '玩家ID',
  `wpid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '物品ID',
  `wpsl` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '物品数量',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='其他物品';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `qt`
--

LOCK TABLES `qt` WRITE;
/*!40000 ALTER TABLE `qt` DISABLE KEYS */;
/*!40000 ALTER TABLE `qt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sw`
--

DROP TABLE IF EXISTS `sw`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sw` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `wjid` int(10) unsigned NOT NULL DEFAULT '0',
  `swid` int(11) NOT NULL DEFAULT '0' COMMENT '声望ID',
  `swzz` int(11) NOT NULL DEFAULT '0' COMMENT '声望值',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sw`
--

LOCK TABLES `sw` WRITE;
/*!40000 ALTER TABLE `sw` DISABLE KEYS */;
/*!40000 ALTER TABLE `sw` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx`
--

DROP TABLE IF EXISTS `tx`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `wjid` int(10) unsigned NOT NULL DEFAULT '0',
  `txid` int(11) NOT NULL DEFAULT '0' COMMENT '头衔ID',
  `txxs` int(11) NOT NULL DEFAULT '0' COMMENT '头衔显示',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx`
--

LOCK TABLES `tx` WRITE;
/*!40000 ALTER TABLE `tx` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `wjid` int(10) unsigned NOT NULL DEFAULT '0',
  `yxm` varchar(64) NOT NULL DEFAULT '' COMMENT '游戏码',
  `cmid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '游戏页面',
  `npc` varchar(100) NOT NULL DEFAULT '' COMMENT '参数',
  `xcmid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最小命令数值',
  `dcmid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最大命令数值',
  `ycmid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上一个页面值',
  `ynpc` varchar(100) NOT NULL DEFAULT '' COMMENT '上一个参数值',
  `x` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '地图区域编号',
  `y` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '地图编号',
  `cwmz` varchar(32) NOT NULL DEFAULT '' COMMENT '宠物名字',
  `ckid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '对象编号',
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '时间',
  `cmds` varchar(10000) NOT NULL DEFAULT '' COMMENT '链接数组',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wj_jj`
--

DROP TABLE IF EXISTS `wj_jj`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wj_jj` (
  `wjid` int(11) NOT NULL,
  `wj_jj` int(11) NOT NULL DEFAULT '1',
  `jj_cs` int(11) NOT NULL DEFAULT '1',
  `jj_sx` int(255) NOT NULL DEFAULT '100',
  `jj_jsgw` int(11) NOT NULL DEFAULT '0',
  `fst_cs` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wj_jj`
--

LOCK TABLES `wj_jj` WRITE;
/*!40000 ALTER TABLE `wj_jj` DISABLE KEYS */;
/*!40000 ALTER TABLE `wj_jj` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wj_tf`
--

DROP TABLE IF EXISTS `wj_tf`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wj_tf` (
  `wjid` int(11) NOT NULL,
  `tf_lvl` int(11) NOT NULL,
  `tf_exp` int(11) NOT NULL,
  `tf_pj` int(11) NOT NULL DEFAULT '0',
  `tf_time` int(11) NOT NULL,
  `tf_sj` int(11) NOT NULL,
  `tz_zt` int(11) NOT NULL,
  `fs_lvl` int(11) NOT NULL,
  `fs_dj` int(11) NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wj_tf`
--

LOCK TABLES `wj_tf` WRITE;
/*!40000 ALTER TABLE `wj_tf` DISABLE KEYS */;
/*!40000 ALTER TABLE `wj_tf` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp`
--

DROP TABLE IF EXISTS `wp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '编号ID',
  `wjid` int(10) unsigned NOT NULL DEFAULT '0',
  `wpid` int(11) NOT NULL DEFAULT '0' COMMENT '物品ID',
  `wpsl` int(11) NOT NULL DEFAULT '0' COMMENT '物品数量',
  `wpfl` int(11) NOT NULL DEFAULT '0' COMMENT '物品分类',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp`
--

LOCK TABLES `wp` WRITE;
/*!40000 ALTER TABLE `wp` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wpp`
--

DROP TABLE IF EXISTS `wpp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wpp` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `wjid` int(10) unsigned NOT NULL DEFAULT '0',
  `wpid` int(11) NOT NULL DEFAULT '0' COMMENT '物品ID',
  `wpcs` int(11) NOT NULL DEFAULT '0' COMMENT '物品使用次数',
  `n` int(11) NOT NULL DEFAULT '0' COMMENT '年',
  `y` int(11) NOT NULL DEFAULT '0' COMMENT '月',
  `r` int(11) NOT NULL DEFAULT '0' COMMENT '日',
  `s` int(11) NOT NULL DEFAULT '0' COMMENT '时',
  `f` int(11) NOT NULL DEFAULT '0' COMMENT '分',
  `m` int(11) NOT NULL DEFAULT '0' COMMENT '秒',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wpp`
--

LOCK TABLES `wpp` WRITE;
/*!40000 ALTER TABLE `wpp` DISABLE KEYS */;
/*!40000 ALTER TABLE `wpp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wpxx`
--

DROP TABLE IF EXISTS `wpxx`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wpxx` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '物品编号',
  `mz` varchar(32) NOT NULL DEFAULT '' COMMENT '物品名字',
  `ms` varchar(100) NOT NULL DEFAULT '' COMMENT '描述',
  `fl` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '分类',
  `jd` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '金豆价格',
  `jg` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '价格',
  `dj` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '等级',
  `zl` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '重量',
  `bd` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '是否绑定',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1217 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wpxx`
--

LOCK TABLES `wpxx` WRITE;
/*!40000 ALTER TABLE `wpxx` DISABLE KEYS */;
INSERT INTO `wpxx` VALUES (1,'回城卷','使用可回到长安十字街头',1,2,1000,1,1,1),(2,'打猎心得','上面记载着打猎的秘籍',1,2,1000,1,1,1),(3,'宠物指南','使用学会技能捕捉术！',1,2,1000,1,1,1),(4,'门派秘籍','使用可学习对应门派的技能',1,2,1000,1,1,1),(5,'【VIP练级卷】','使用可获得30分钟VIP练级祝福时间，拥有VIP练级祝福时间就可以进入刷级通道了！',1,2,1000,1,1,0),(8,'腾云符','使用此符可飞到你想去的地方简直是飞机中的战斗机！',1,2,1000,1,1,1),(9,'〖1千傲来国声望卷〗','使用可获得1000傲来国声望！',1,2,1000,60,1,1),(10,'〖1千宝象国声望卷〗','使用可获得1000宝象国声望！',1,2,1000,60,1,1),(11,'〖1千将军府声望卷〗','使用可获得1000将军府声望！',1,2,1000,60,1,1),(12,'〖1千普陀山声望卷〗','使用可获得1000普陀山声望！',1,2,1000,60,1,1),(13,'〖1千龙宫声望卷〗','使用可获得1000龙宫声望！',1,2,1000,60,1,1),(14,'〖1千月宫声望卷〗','使用可获得1000月宫声望！',1,2,1000,60,1,1),(15,'〖1千方寸山声望卷〗','使用可获得1000方寸山声望！',1,2,1000,60,1,1),(16,'〖1千天宫声望卷〗','使用可获得1000天宫声望！',1,2,1000,60,1,1),(17,'〖1千地府声望卷〗','使用可获得1000地府声望！',1,2,1000,60,1,1),(18,'〖1千西游声望卷〗','使用可获得1000西游声望！',1,2,1000,60,1,1),(19,'〖1千乌鸡国声望卷〗','使用可获得1000乌鸡国声望！',1,2,1000,60,1,1),(20,'〖1千恶魔广场声望卷〗','使用可获得1000恶魔声望！',1,2,1000,60,1,1),(21,'〖1千夫妻声望卷〗','使用可获得1000夫妻声望！',1,1,1000,60,1,1),(22,'红宝石一','稀少难得的红宝石一，升级装备的必须品！',2,2,1000,1,1,1),(23,'红水晶一','稀少难得的红水晶一，升级装备的必须品！',2,2,1000,1,1,1),(24,'蓝宝石一','稀少难得的蓝宝石一，升级装备的必须品！',2,2,1000,1,1,1),(25,'蓝水晶一','稀少难得的蓝水晶一，升级装备的必须品！',2,2,1000,1,1,1),(26,'黄宝石一','稀少难得的黄宝石一，升级装备的必须品！',2,2,1000,1,1,1),(27,'黄水晶一','稀少难得的黄水晶一，升级装备的必须品！',2,2,1000,1,1,1),(28,'金刚石一','稀少难得的金刚石一，升级装备的必须品！',2,2,1000,1,1,1),(29,'佛印石一','稀少难得的佛印石一，升级装备的必须品！',2,2,1000,1,1,1),(30,'玄武石一','稀少难得的玄武石一，升级装备的必须品！',2,2,1000,1,1,1),(31,'红宝石二','稀少难得的红宝石二，升级装备的必须品！',2,2,1000,1,1,1),(32,'红水晶二','稀少难得的红水晶二，升级装备的必须品！',2,2,1000,1,1,1),(33,'蓝宝石二','稀少难得的蓝宝石二，升级装备的必须品！',2,2,1000,1,1,1),(34,'蓝水晶二','稀少难得的蓝水晶二，升级装备的必须品！',2,2,1000,1,1,1),(35,'黄宝石二','稀少难得的黄宝石二，升级装备的必须品！',2,2,1000,1,1,1),(36,'黄水晶二','稀少难得的黄水晶二，升级装备的必须品！',2,2,1000,1,1,1),(37,'金刚石二','稀少难得的金刚石二，升级装备的必须品！',2,2,1000,1,1,1),(38,'佛印石二','稀少难得的佛印石二，升级装备的必须品！',2,2,1000,1,1,1),(39,'玄武石二','稀少难得的玄武石二，升级装备的必须品！',2,2,1000,1,1,1),(40,'红宝石三','稀少难得的红宝石三，升级装备的必须品！',2,2,1000,1,1,1),(41,'红水晶三','稀少难得的红水晶三，升级装备的必须品！',2,2,1000,1,1,1),(42,'蓝宝石三','稀少难得的蓝宝石三，升级装备的必须品！',2,2,1000,1,1,1),(43,'蓝水晶三','稀少难得的蓝水晶三，升级装备的必须品！',2,2,1000,1,1,1),(44,'黄宝石三','稀少难得的黄宝石三，升级装备的必须品！',2,2,1000,1,1,1),(45,'黄水晶三','稀少难得的黄水晶三，升级装备的必须品！',2,2,1000,1,1,1),(46,'金刚石三','稀少难得的金刚石三，升级装备的必须品！',2,2,1000,1,1,1),(47,'佛印石三','稀少难得的佛印石三，升级装备的必须品！',2,2,1000,1,1,1),(48,'玄武石三','稀少难得的玄武石三，升级装备的必须品！',2,2,1000,1,1,1),(49,'红宝石四','稀少难得的红宝石四，升级装备的必须品！',2,2,1000,1,1,1),(50,'红水晶四','稀少难得的红水晶四，升级装备的必须品！',2,2,1000,1,1,1),(51,'蓝宝石四','稀少难得的蓝宝石四，升级装备的必须品！',2,2,1000,1,1,1),(52,'蓝水晶四','稀少难得的蓝水晶四，升级装备的必须品！',2,2,1000,1,1,1),(53,'黄宝石四','稀少难得的黄宝石四，升级装备的必须品！',2,2,1000,1,1,1),(54,'黄水晶四','稀少难得的黄水晶四，升级装备的必须品！',2,2,1000,1,1,1),(55,'金刚石四','稀少难得的金刚石四，升级装备的必须品！',2,2,1000,1,1,1),(56,'佛印石四','稀少难得的佛印石四，升级装备的必须品！',2,2,1000,1,1,1),(57,'玄武石四','稀少难得的玄武石四，升级装备的必须品！',2,2,1000,1,1,1),(58,'红宝石五','稀少难得的红宝石五，升级装备的必须品！',2,2,1000,1,1,1),(59,'红水晶五','稀少难得的红水晶五，升级装备的必须品！',2,2,1000,1,1,1),(60,'蓝宝石五','稀少难得的蓝宝石五，升级装备的必须品！',2,2,1000,1,1,1),(61,'蓝水晶五','稀少难得的蓝水晶五，升级装备的必须品！',2,2,1000,1,1,1),(62,'黄宝石五','稀少难得的黄宝石五，升级装备的必须品！',2,2,1000,1,1,1),(63,'黄水晶五','稀少难得的黄水晶五，升级装备的必须品！',2,2,1000,1,1,1),(64,'金刚石五','稀少难得的金刚石五，升级装备的必须品！',2,2,1000,1,1,1),(65,'佛印石五','稀少难得的佛印石五，升级装备的必须品！',2,2,1000,1,1,1),(66,'玄武石五','稀少难得的玄武石五，升级装备的必须品！',2,2,1000,1,1,1),(67,'红宝石六','稀少难得的红宝石六，升级装备的必须品！',2,2,1000,1,1,1),(68,'红水晶六','稀少难得的红水晶六，升级装备的必须品！',2,2,1000,1,1,1),(69,'蓝宝石六','稀少难得的蓝宝石六，升级装备的必须品！',2,2,1000,1,1,1),(70,'蓝水晶六','稀少难得的蓝水晶六，升级装备的必须品！',2,2,1000,1,1,1),(71,'黄宝石六','稀少难得的黄宝石六，升级装备的必须品！',2,2,1000,1,1,1),(72,'黄水晶六','稀少难得的黄水晶六，升级装备的必须品！',2,2,1000,1,1,1),(73,'金刚石六','稀少难得的金刚石六，升级装备的必须品！',2,2,1000,1,1,1),(74,'佛印石六','稀少难得的佛印石六，升级装备的必须品！',2,2,1000,1,1,1),(75,'玄武石六','稀少难得的玄武石六，升级装备的必须品！',2,2,1000,1,1,1),(76,'【冰晶】','稀少难得的【冰晶】，升级装备的必须品！',2,2,1000,1,1,0),(77,'【雷晶】','稀少难得的【雷晶】，升级装备的必须品！',2,2,1000,1,1,0),(78,'【白骨靴】','稀少难得的【白骨靴】，升级装备的必须品！',2,2,1000,1,1,0),(79,'【食尸鬼之皮】','稀少难得的【食尸鬼之皮】，升级装备的必须品！',2,2,1000,1,1,0),(80,'【祭祀之帽】','稀少难得的【祭祀之帽】，升级装备的必须品！',2,2,1000,1,1,0),(81,'【剥皮鬼之皮】','稀少难得的【剥皮鬼之皮】，升级装备的必须品！',2,2,1000,1,1,0),(82,'【白骨项链】','稀少难得的【白骨项链】，升级装备的必须品！',2,2,1000,1,1,0),(83,'【炼尸宝石】','稀少难得的【炼尸宝石】，升级装备的必须品！',2,2,1000,1,1,0),(84,'【黄袍武器】','稀少难得的【黄袍武器】，升级装备的必须品！',2,2,1000,1,1,0),(85,'【锻造图】','稀少难得的【锻造图】，升级装备的必须品！',2,2,1000,1,1,0),(86,'【黑熊宝石】','稀少难得的【黑熊宝石】，升级装备的必须品！',2,2,1000,1,1,0),(87,'【鹿角手镯】','稀少难得的【鹿角手镯】，升级装备的必须品！',2,2,1000,1,1,0),(88,'【妖将合金】','稀少难得的【妖将合金】，升级装备的必须品！',2,2,1000,1,1,0),(89,'【野熊铠甲】','稀少难得的【野熊铠甲】，升级装备的必须品！',2,2,1000,1,1,0),(90,'【火红毛皮】','稀少难得的【火红毛皮】，升级装备的必须品！',2,2,1000,1,1,0),(91,'【玉衣片】','稀少难得的【玉衣片】，升级装备的必须品！',2,2,1000,1,1,0),(92,'【淡黄狐尾】','稀少难得的【淡黄狐尾】，升级装备的必须品！',2,2,1000,1,1,0),(93,'【猩红石】','稀少难得的【猩红石】，升级装备的必须品！',2,2,1000,1,1,0),(94,'【拔地鼠筋】','稀少难得的【拔地鼠筋】，升级装备的必须品！',2,2,1000,1,1,0),(95,'【天香碧玉竹】','稀少难得的【天香碧玉竹】，升级装备的必须品！',2,2,1000,1,1,0),(96,'【骷髅头】','稀少难得的【骷髅头】，升级装备的必须品！',2,2,1000,1,1,0),(97,'【银犀角】','稀少难得的【银犀角】，升级装备的必须品！',2,2,1000,1,1,0),(98,'【玄铁手镯】','稀少难得的【玄铁手镯】，升级装备的必须品！',2,2,1000,1,1,0),(99,'【黑晶】','稀少难得的【黑晶】，升级装备的必须品！',2,2,1000,1,1,0),(100,'【金精】','稀少难得的【金精】，升级装备的必须品！',2,2,1000,1,1,0),(101,'【金犀角】','稀少难得的【金犀角】，升级装备的必须品！',2,2,1000,1,1,0),(102,'【烈焰火羽】','稀少难得的【烈焰火羽】，升级装备的必须品！',2,2,1000,1,1,0),(103,'【冰凌石】','稀少难得的【冰凌石】，升级装备的必须品！',2,2,1000,1,1,0),(104,'【逆鳞】','稀少难得的【逆鳞】，升级装备的必须品！',2,2,1000,1,1,0),(105,'【紫金】','稀少难得的【紫金】，升级装备的必须品！',2,2,1000,1,1,0),(106,'【琉璃】','稀少难得的【琉璃】，升级装备的必须品！',2,2,1000,1,1,0),(107,'【灵晶】','稀少难得的【灵晶】，升级装备的必须品！',2,2,1000,1,1,0),(108,'【引魄】','稀少难得的【引魄】，升级装备的必须品！',2,2,1000,1,1,0),(109,'【勾魂】','稀少难得的【勾魂】，升级装备的必须品！',2,2,1000,1,1,0),(110,'【东海神铁】','稀少难得的【东海神铁】，升级装备的必须品！',2,2,1000,1,1,0),(111,'【千年寒冰】','稀少难得的【千年寒冰】，升级装备的必须品！',2,2,1000,1,1,0),(112,'〖黑曜石〗','稀少难得的〖黑曜石〗，升级装备的必须品！',2,2,1000,1,1,1),(113,'【玉鼎黄色碎片】','稀少难得的【玉鼎黄色碎片】，升级装备的必须品！',2,2,1000,1,1,0),(114,'【玉鼎红色碎片】','稀少难得的【玉鼎红色碎片】，升级装备的必须品！',2,2,1000,1,1,0),(115,'【玉鼎绿色碎片】','稀少难得的【玉鼎绿色碎片】，升级装备的必须品！',2,2,1000,1,1,0),(116,'【玉鼎橙色碎片】','稀少难得的【玉鼎橙色碎片】，升级装备的必须品！',2,2,1000,1,1,0),(117,'〖苍白内丹〗','稀少难得的〖苍白内丹〗，升级装备的必须品！',2,2,1000,1,1,1),(118,'〖黄澄内丹〗','稀少难得的〖黄澄内丹〗，升级装备的必须品！',2,2,1000,1,1,1),(119,'【千年冰魄】','稀少难得的【千年冰魄】，升级装备的必须品！',2,2,1000,1,1,0),(120,'黑龙之牙','稀少难得的黑龙之牙，升级装备的必须品！',2,2,1000,1,1,1),(121,'〖妖魔内丹〗','妖怪们修炼得内丹！',2,2,1000,1,1,1),(122,'【英雄牌】','英雄的象征，完成各大副本可以获得！',2,2,1000,1,1,0),(123,'〖石块〗','国家建设资源！',2,2,1000,1,1,1),(124,'〖木头〗','国家建设资源！',2,2,1000,1,1,1),(125,'〖硫磺〗','国家建设资源！',2,2,1000,1,1,1),(126,'小幸运草','稀少难得的小幸运草，升级装备的必须品！（直接在身上装备升级消耗）',4,1,1000,1,1,1),(127,'〖金豆〗','人人都喜欢的金豆子！',4,2,1000,1,1,1),(128,'【万能果】','据说这是无所不能的果子~~',4,2,1000,1,1,0),(129,'【新手礼包】（1级）','精心为新手准备的礼包，打开可获得大量物品～',4,2,1000,1,1,0),(130,'【新手礼包】（10级）','精心为新手准备的礼包，打开可获得大量物品～',4,2,1000,10,1,0),(131,'【新手礼包】（30级）','精心为新手准备的礼包，打开可获得大量物品～',4,2,1000,30,1,0),(132,'【新手礼包】（50级）','精心为新手准备的礼包，打开可获得大量物品～',4,2,1000,50,1,0),(133,'【新手礼包】（70级）','精心为新手准备的礼包，打开可获得大量物品～',4,2,1000,70,1,0),(134,'【新手礼包】（90级）','精心为新手准备的礼包，打开可获得大量物品～',4,2,1000,90,1,0),(136,'〖如意毫毛〗','使用可获得1个月属性祝福，生命增加10000点，防御增加7000点，攻击增加6000点，魔攻增加6000点',4,30,1000,1,1,1),(137,'【人参果】','使用可获得半个月属性祝福，生命增加5000点，防御增加3500点，攻击增加3000点，魔攻增加3000点',4,2,1000,1,1,0),(138,'【神秘人参果】','使用可获得1个月属性祝福，生命增加10000点，防御增加7000点，攻击增加6000点，魔攻增加6000点',4,2,1000,1,1,0),(147,'〖属性之王〗','使用后可以永久增加HP60000，攻击35000，防御40000，魔攻30000',4,2,1000,1,1,1),(148,'〖西游之星〗','使用可获得西游之星称号！附带永久生命值88888点！限用一次！',4,2,1000,1,1,1),(151,'〖小富豪〗','使用可获得小富豪称号，生命永久增加58888！',4,2,1000,1,1,1),(152,'〖富豪〗','使用可获得富豪称号！生命永久增加88888！',4,2,1000,1,1,1),(155,'〖三千年蟠桃礼包〗','使用可获得20个〖三千年蟠桃〗！',4,6,1000,1,1,1),(156,'〖六千年蟠桃礼包〗','使用可获得8个〖六千年蟠桃〗！',4,8,1000,1,1,1),(157,'〖九千年蟠桃礼包〗','使用可获得5个〖九千年蟠桃〗！',4,10,1000,1,1,1),(158,'〖仙魂套装〗','打开可获得仙魂装备一套！',4,2,1000,1,1,1),(159,'【三千年蟠桃礼包】','打开可获得20个【三千年蟠桃】！',4,2,1000,1,1,0),(160,'【六千年蟠桃礼包】','打开可获得8【六千年蟠桃】！',4,2,1000,1,1,0),(161,'【九千年蟠桃礼包】','打开可获得5个【九千年蟠桃】！',4,2,1000,1,1,0),(162,'〖师门声望礼包〗','打开可获得20张相应师门的声望卷！',4,5,1000,1,1,1),(163,'〖宝象国声望礼包〗','打开可获得20张〖宝象国声望卷〗！',4,5,1000,1,1,1),(164,'〖天宫声望礼包〗','打开可获得20张〖天宫声望卷〗！',4,5,1000,1,1,1),(168,'〖地府声望礼包〗','打开可获得20张〖地府声望卷〗！',4,5,1000,1,1,1),(169,'〖傲来国声望礼包〗','打开可获得20张〖傲来国声望卷〗！',4,5,1000,1,1,1),(170,'〖乌鸡国声望礼包〗','打开可获得20张〖乌鸡国声望卷〗！',4,5,1000,1,1,1),(175,'〖仓库扩容卷〗','使用后增加仓库容量加1000',4,5,1000,1,1,1),(191,'云南白药（中捆）','使用可恢复5000体力！',5,2,1000,1,1,1),(192,'灵丹（小捆）','使用恢复1000内力！',5,2,1000,1,1,1),(193,'冰糖葫芦','使用恢复MP800点！',5,2,1000,1,1,1),(194,'云南白药（小捆）','使用恢复2500体力！',5,2,1000,1,1,1),(195,'红烧狗肉','使用可恢复HP220点！',5,2,1000,1,1,1),(196,'花雕酒','使用可恢复MP110点！',5,2,1000,1,1,1),(197,'素菜包','香喷喷的素菜包！使用可恢复HP250',5,2,1000,1,1,1),(198,'猪肉包','香喷喷的猪肉包！使用可恢复HP370',5,2,1000,1,1,1),(199,'神仙汤','使用可恢复HP500点！',5,2,1000,1,1,1),(200,'【保命丸】','使用可恢复150000体力!',5,2,1000,1,1,0),(201,'〖小生命丹〗','1级丹药，使用增加100HP，每人限用100个。住宅炼丹房炼制；金豆超市购买获得！',5,30,1000,1,1,1),(203,'〖中生命丹〗','3级丹药，使用增加500HP，每人限用100个。住宅炼丹房炼制；金豆超市购买获得！',5,2,1000,1,1,1),(204,'〖大生命丹〗','4级丹药，使用增加5000HP，每人限用100个。住宅炼丹房炼制；金豆超市购买获得！',5,2,1000,1,1,1),(205,'〖小积分丹〗','使用增加200HP， 每人限用100颗。消费积分奖励！',5,2,1000,1,1,1),(206,'〖积分体力丹〗','使用增加200HP， 每人限用100颗。消费积分奖励！',5,2,1000,1,1,1),(207,'〖积分中生命丹〗','使用增加300HP， 每人限用100颗。消费积分奖励！',5,2,1000,1,1,1),(208,'〖积分大生命丹〗','使用增加500HP， 每人限用100颗。消费积分奖励！',5,2,1000,1,1,1),(209,'〖积分超级体力丹〗','使用增加1000HP， 每人限用100颗。消费积分奖励！',5,2,1000,1,1,1),(210,'〖神秘体力丹〗','使用增加200HP，每人限用100个。金豆超市购买获得！',5,2,1000,1,1,1),(211,'〖冰火丹〗','使用增加100HP，每人限用100颗！',5,2,1000,1,1,1),(212,'〖鬼面丹〗','使用增加100HP，每人限用100颗！',5,2,1000,1,1,1),(213,'〖混世丹〗','使用增加100HP，每人限用100颗！',5,2,1000,1,1,1),(214,'〖金银丹〗','使用增加200HP，每人限用100颗！',5,2,1000,1,1,1),(215,'〖金兜丹〗','使用增加200HP，每人限用100颗！',5,2,1000,1,1,1),(216,'〖魔牛丹〗','使用增加200HP，每人限用100颗！',5,2,1000,1,1,1),(217,'〖凤仙丸〗','使用增加300HP，每人限用100颗！',5,2,1000,1,1,1),(218,'〖麒麟丹〗','使用增加100HP，每人限用100颗！',5,2,1000,1,1,1),(219,'〖玉华丸〗','使用增加300HP，每人限用100颗！',5,2,1000,1,1,1),(220,'〖金平丸〗','使用增加300HP，每人限用100颗！',5,2,1000,1,1,1),(221,'〖龙虎豹胎丸〗','使用增加100HP，每人限用100颗！',5,2,1000,1,1,1),(222,'〖血河丹〗','使用增加200HP，每人限用100颗！',5,2,1000,1,1,1),(223,'〖白巫丹〗','使用增加200HP，每人限用100颗！',5,2,1000,1,1,1),(224,'〖玲珑丹〗','使用增加500HP，每人限用100颗！',5,2,1000,1,1,1),(225,'〖朱紫丸〗','使用增加300HP，每人限用100颗！',5,2,1000,1,1,1),(226,'〖比丘丸〗','使用增加100HP，每人限用100颗！',5,2,1000,1,1,1),(227,'〖比丘丹〗','使用增加200HP，每人限用100颗！',5,2,1000,1,1,1),(228,'〖天法丸〗','使用增加200HP，每人限用100颗！',5,2,1000,1,1,1),(229,'〖天竺丸〗','使用增加500HP，每人限用100颗！',5,2,1000,1,1,1),(230,'【公测生命丹】','使用增加300HP，每人限用100颗！',5,2,1000,1,1,0),(231,'【公测攻击丹】','使用永久增加攻击120点！最多可使用100颗！',5,2,1000,1,1,0),(232,'【公测防御丹】','使用永久增加防御250点！最多可使用100颗！',5,2,1000,1,1,0),(233,'【公测魔攻丹】','使用永久增加魔攻120点！最多可使用100颗！',5,2,1000,1,1,0),(234,'【99级解封丹】','使用后可解封99级继续升级到109级！',5,2,1000,1,1,0),(235,'〖经验丹〗','使用可获得300万经验(每日限制10次)',5,2,1000,1,1,1),(236,'【小蟠桃】','天宫蟠桃园的蟠桃，使用后可获得35万经验。（每日限用10次）',5,2,1000,1,1,0),(237,'【蟠桃】','天宫蟠桃园的蟠桃，使用后可获得80万经验。（每日限用10次）',5,2,1000,1,1,0),(238,'【三千年蟠桃】','王母娘娘蟠桃大会上用的蟠桃，使用可增加300万经验！（每日限用10次）',5,2,1000,1,1,0),(239,'【六千年蟠桃】','王母娘娘蟠桃大会上用的蟠桃，使用可增加700万经验！（每日限用10次）',5,2,1000,1,1,0),(240,'【九千年蟠桃】','王母娘娘蟠桃大会上用的蟠桃，使用可增加1500万经验！（每日限用10次）',5,2,1000,1,1,0),(241,'〖三千年蟠桃〗','王母娘娘蟠桃大会上用的蟠桃，使用可增加300万经验！（每日限用10次）',5,2,1000,1,1,1),(242,'〖六千年蟠桃〗','王母娘娘蟠桃大会上用的蟠桃，使用可增加700万经验！（每日限用10次）',5,2,1000,1,1,1),(243,'〖九千年蟠桃〗','王母娘娘蟠桃大会上用的蟠桃，使用可增加1500万经验！（每日限用10次）',5,2,1000,1,1,1),(244,'灵丹','使用可恢复MP500点',5,2,1000,1,1,1),(245,'猕猴桃干','使用恢复HP3690点！',5,2,1000,1,1,1),(246,'云南白药','使用恢复HP1000点！',5,2,1000,1,1,1),(247,'清酒','使用后恢复MP80点',5,2,500,1,1,1),(248,'饭团','使用后可恢复HP100点',5,2,500,1,1,1),(249,'云南白药（大捆）','使用可恢复10000体力！',5,2,1000,1,1,1),(250,'云南白药（超大捆）','使用可恢复80000体力！',5,2,1000,1,1,1),(252,'船票','任务物品村长赠予的船票',6,2,1000,1,1,0),(253,'桂花酒','任务物品桂花酒',6,2,1000,1,1,0),(256,'村长的信','村长的介绍信',6,2,1000,1,1,0),(257,'动物碎齿','动物碎齿!',2,2,1000,1,1,1),(258,'仙露','任务物品请勿丢弃!',6,2,1,1,1,1),(260,'鹿茸（药引）','任务物品请勿丢弃!',6,2,1,1,1,1),(262,'活鲤鱼','任务物品请勿丢弃!',6,2,1,1,1,1),(263,'包袱','任务物品请勿丢弃!',6,2,1,1,1,1),(264,'耳坠珠子','任务物品请勿丢弃!',6,2,1,1,1,1),(265,'闪光磷粉','任务物品请勿丢弃!',6,2,1,1,1,1),(266,'〖玄铁令〗','用于建立国家的重要信物',4,2,1000,1,1,1),(276,'〖铁宝箱〗','打开箱子可随机获得物品（需要万能钥匙开启）',8,2,1000,1,1,1),(278,'〖银宝箱〗','打开箱子可随机获得物品（需要万能钥匙开启）',8,2,1000,1,1,1),(302,'〖打孔器〗','此物品可为装备打造第一个孔（可在长安城兵器铺找装备锻造商进行使用）',2,100,1000,1,1,1),(303,'〖普通打孔器〗','此物品可为装备打造第二个孔（可在长安城兵器铺找装备锻造商进行使用）',2,200,1000,1,1,1),(304,'〖高级打孔器〗','此物品可为装备打造第三个孔（可在长安城兵器铺找装备锻造商进行使用）',2,300,1000,1,1,1),(305,'〖强化打孔器〗','此物品可为装备打造第四个孔（可在长安城兵器铺找装备锻造商进行使用）',2,500,1000,1,1,1),(306,'〖究极打孔器〗','此物品可为装备打造第五个孔（可在长安城兵器铺找装备锻造商进行使用）',2,1000,1000,1,1,1),(307,'大幸运草','可以为装备打孔或者装备升星提示10%的成功率，锻造装备必备！（直接在身上装备升级消耗）',4,3,1000,1,1,1),(308,'〖铁魂〗','升星装备的材料之铁魂（可在长安城兵器铺找装备锻造商进行使用）',2,2,1000,1,1,1),(309,'〖铜魂〗','升星装备的材料之铜魂（可在长安城兵器铺找装备锻造商进行使用）',2,2,1000,1,1,1),(310,'〖银魂〗','升星装备的材料之银魂（可在长安城兵器铺找装备锻造商进行使用）',2,2,1000,1,1,1),(311,'〖金魂〗','升星装备的材料之铁魂（可在长安城兵器铺找装备锻造商进行使用）',2,2,1000,1,1,1),(312,'〖钻魂〗','升星装备的材料之钻魂（可在长安城兵器铺找装备锻造商进行使用）',2,2,1000,1,1,1),(313,'〖陨魂〗','升星装备的材料之铁魂（可在长安城兵器铺找装备锻造商进行使用）',2,2,1000,1,1,1),(314,'〖铁星升星符〗','拥有这强大的力量的符咒，可将百分之百将铁星的装备升星成功！（可在长安城兵器铺找装备锻造商进行使用）',4,20,1000,1,1,1),(315,'〖铜星升星符〗','拥有这强大的力量的符咒，可将百分之百将铜星的装备升星成功！（可在长安城兵器铺找装备锻造商进行使用）',4,50,1000,1,1,1),(316,'〖银星升星符〗','拥有这强大的力量的符咒，可将百分之百将银星的装备升星成功！（可在长安城兵器铺找装备锻造商进行使用）',4,100,1000,1,1,1),(317,'〖金星升星符〗','拥有这强大的力量的符咒，可将百分之百将金星的装备升星成功！（可在长安城兵器铺找装备锻造商进行使用）',4,200,1000,1,1,1),(318,'〖钻星升星符〗','拥有这强大的力量的符咒，可将百分之百将钻星的装备升星成功！（可在长安城兵器铺找装备锻造商进行使用）',4,600,1000,1,1,1),(319,'〖陨星升星符〗','拥有这强大的力量的符咒，可将百分之百将陨星的装备升星成功！（可在长安城兵器铺找装备锻造商进行使用）',4,2000,1000,1,1,1),(320,'【幻想武器包】','打开可获得相应职业绝版武器一把！',4,2,1000,1,1,0),(321,'【幻想防具包】','打开可获得相应职业绝版衣服头盔鞋子！',4,2,1000,1,1,0),(322,'【幻想首饰包】','打开可获得相应职业绝版项链和手镯！',4,2,1000,1,1,0),(323,'〖雷皇套装〗','打开可获得雷皇装备一套',4,2,1000,1,1,1),(324,'〖小巨灵套装〗','打开可获得小巨灵装备一套',4,2,1000,1,1,1),(325,'〖玄冰套装〗','打开可获得玄冰装备一套',4,2,1000,1,1,1),(326,'〖仙魂套装〗','打开可获得仙魂装备一套',4,2,1000,1,1,1),(327,'螃蟹肉','美味可口的螃蟹肉',2,2,1000,1,1,1),(328,'海贼头巾','看上去有点破旧的头巾',2,2,1000,1,1,1),(329,'鳅鱼皮','鳅鱼精身上的皮甲',2,2,1000,1,1,1),(330,'赤背虾皮','赤背虾精身上的皮甲',2,2,1000,1,1,1),(331,'〖百年魔珠〗','妖魔修炼百年的魔珠',2,2,1000,1,1,1),(332,'皮皮虾','虾兵身上的宝贝',2,2,1000,1,1,1),(333,'大炸蟹','看上去美味可口',2,2,1000,1,1,1),(334,'巨鳌肉','看上去美味可口',2,2,1000,1,1,1),(335,'鲨鱼肉','看上去美味可口',2,2,1000,1,1,1),(336,'桂花枝','桂花树上的树枝',2,2,1000,1,1,1),(337,'杏花果','杏花树上的果实',2,2,1000,1,1,1),(338,'狼皮','老狼的皮毛',2,2,1000,1,1,1),(339,'西瓜籽','西瓜精掉落的西瓜籽',2,2,1000,1,1,1),(340,'竹子','细细长长的竹子',2,2,1000,1,1,1),(341,'蛇胆','青蛇怪的蛇胆',2,2,1000,1,1,1),(342,'黄雀羽毛','黄雀的羽毛',2,2,1000,1,1,1),(343,'磷粉','闪闪发光的磷粉',2,2,1000,1,1,1),(344,'兔毛','野兔的毛',2,2,1000,1,1,1),(345,'兔皮','野兔的皮',2,2,1000,1,1,1),(346,'野狼肉','野狼的肉',2,2,1000,1,1,1),(347,'山猪皮','山猪的皮甲',2,2,1000,1,1,1),(348,'灯芯','快要熄灭的灯芯',2,2,1000,1,1,1),(349,'扫帚','仿佛能看的它过去的凶残',2,2,1000,1,1,1),(350,'灯笼','红红的大灯笼',2,2,1000,1,1,1),(351,'蜡烛','好像快要熄灭了',2,2,1000,1,1,1),(352,'马刀兵俑泥人','马刀兵俑的原型',2,2,1000,1,1,1),(353,'长矛兵俑泥人','长矛兵俑的原型',2,2,1000,1,1,1),(354,'宣纸','普普通通的宣纸',2,2,1000,1,1,1),(355,'油墨','黑死的油墨',2,2,1000,1,1,1),(356,'银色星辰','天兵银色星辰',2,2,1000,1,1,1),(357,'金色星辰','天将银色星辰',2,2,1000,1,1,1),(358,'花粉','仙灵蝴蝶的花粉',2,2,1000,1,1,1),(359,'游荡魂魄','游荡妖魂最后的一丝魂魄',2,2,1000,1,1,1),(360,'蟠璃','蟠璃材料',2,2,1000,1,1,1),(361,'蟠龙','蟠龙材料',2,2,1000,1,1,1),(362,'花斑虎皮','花斑虎的皮甲',2,2,1000,1,1,1),(363,'鹿皮','野鹿的皮甲',2,2,1000,1,1,1),(364,'鹿角','野鹿的角',2,2,1000,1,1,1),(365,'熊胆','野熊的熊胆',2,2,1000,1,1,1),(366,'熊掌','野熊的熊掌',2,2,1000,1,1,1),(367,'山妖皮','野山妖皮',2,2,1000,1,1,1),(368,'大头骨','骷髅怪的头颅',2,2,1000,1,1,1),(369,'腐尸皮','腐尸怪的皮甲',2,2,1000,1,1,1),(370,'僵尸皮','僵尸怪的皮甲',2,2,1000,1,1,1),(371,'豹皮','豹妖的皮甲',2,2,1000,1,1,1),(372,'猫皮','猫妖的皮甲',2,2,1000,1,1,1),(373,'羚羊角','羚羊怪的角',2,2,1000,1,1,1),(374,'花鹿角','花鹿怪的角',2,2,1000,1,1,1),(375,'狐狸皮','狐狸精的皮甲',2,2,1000,1,1,1),(376,'野獾皮','野獾精的皮甲',2,2,1000,1,1,1),(378,'桃皮','桃妖的树皮',2,2,1000,1,1,1),(379,'雪球','圆圆的雪球',2,2,1000,1,1,1),(380,'雪莲','雪莲精的雪莲',2,2,1000,1,1,1),(381,'雪豹肉','雪豹的肉',2,2,1000,1,1,1),(382,'雪狼肉','雪狼的肉',2,2,1000,1,1,1),(383,'紫竹根','紫竹战士的根',2,2,1000,1,1,1),(384,'孤魂魄','孤魂的魂魄',2,2,1000,1,1,1),(385,'厉鬼魂','厉鬼的魂魄',2,2,1000,1,1,1),(386,'佛珠','冰晶塔掉落的佛珠',2,2,1000,1,1,1),(387,'牛角','一个普通的牛角',2,2,1000,1,1,1),(389,'芭蕉','芭蕉怪身上的芭蕉',2,2,1000,1,1,1),(390,'蜘蛛网','人面蛛妖的蜘蛛网',2,2,1000,1,1,1),(391,'麒麟肉','麒麟的肉',2,2,1000,1,1,1),(392,'惨白树皮','惨白树精的皮',2,2,1000,1,1,1),(393,'疯狂树皮','疯狂树精的皮',2,2,1000,1,1,1),(394,'【英雄牌】','通过完成各大副本所得的奖励，可在长安城英雄大厅兑换奖励',4,2,1000,1,1,0),(395,'〖储物袋〗','大小遗迹储物容量增加5,最多扩容15,在遗迹内使用',4,2,1000,1,1,1),(396,'〖豪宅优惠券〗','使用金豆在开封广场购买房子时会获得一定的优惠',4,2,1000,1,1,1),(397,'〖求婚玫瑰〗','赠人玫瑰收留余香，在月老处使用，可向自己心仪的玩家进行求婚',4,1,1000,1,1,1),(398,'〖小智慧果〗','使用后可获得60分钟的杀怪双倍经验',4,2,1000,1,1,1),(399,'〖大智慧果〗','使用后可获得60分钟的杀怪四倍经验',4,5,1000,1,1,1),(400,'〖背包扩容卷〗','使用后可增加背包容量1000',4,5,1000,1,1,1),(401,'〖万能钥匙〗','用于开启铜铁银金宝箱的钥匙',4,5,1000,1,1,1),(402,'【内测福利】','GM精心为大家准备的的小小礼物',4,5,1000,1,1,0),(403,'〖元旦宝箱〗','元旦节日宝箱(传说能开出各种宝贝绝对超值)',8,5,1000,1,1,1),(404,'【元】','元旦节日-【元】字(凑齐元旦快乐可以在元旦大使那里兑换〖元旦宝箱〗哦)',2,5,1000,1,1,0),(405,'【旦】','元旦节日-【旦】字(凑齐元旦快乐可以在元旦大使那里兑换〖元旦宝箱〗哦)',2,5,1000,1,1,0),(406,'【快】','元旦节日-【快】字(凑齐元旦快乐可以在元旦大使那里兑换〖元旦宝箱〗哦)',2,5,1000,1,1,0),(407,'【乐】','元旦节日-【乐】字(凑齐元旦快乐可以在元旦大使那里兑换〖元旦宝箱〗哦)',2,5,1000,1,1,0),(408,'〖元旦节日勋章〗','〖元旦节日勋章〗(可以在元旦大使那里兑换【元】【旦】【快】【乐】任意一个)',4,8,1000,1,1,1),(409,'【副本重置令】','vip每日的专属令牌用于各大副本重置无须再等待',4,5,1000,1,1,0),(410,'【GM的小内裤】','【GM的小内裤】(WHAT!?我没有看错吧?这居然GM的内裤到被爆出来了,GM太没节操了,暖冬活动限定可用于兑换积分,当然也可留做当纪念)',2,8,1000,1,1,0),(411,'〖暖〗','暖冬活动限定-〖暖〗字(凑齐-暖冬祝福每样五个可兑换暖冬积分参与暖冬大比拼)',2,8,1000,1,1,1),(412,'〖冬〗','暖冬活动限定-〖冬〗字(凑齐-暖冬祝福每样五个可兑换暖冬积分参与暖冬大比拼)',2,8,1000,1,1,1),(413,'〖祝〗','暖冬活动限定-〖祝〗字(凑齐-暖冬祝福每样五个可兑换暖冬积分参与暖冬大比拼)',2,8,1000,1,1,1),(414,'〖福〗','暖冬活动限定-〖福〗字(凑齐-暖冬祝福每样五个可兑换暖冬积分参与暖冬大比拼)',2,8,1000,1,1,1),(415,'【五角碎片】','【五角碎片】(GM每个月总有那么一次的大放血还不死的神奇生物凑齐20个可以兑换【五角兑换卷】也可以兑换成暖冬积分)',4,8,1000,1,1,0),(416,'【一元碎片】','【一元碎片】(GM每个月总有那么一次的大放血还不死的神奇生物凑齐20个可以兑换【一元兑换卷】也可以兑换成暖冬积分)',4,8,1000,1,1,0),(417,'【两元碎片】','【两元碎片】(GM每个月总有那么一次的大放血还不死的神奇生物凑齐20个可以兑换【两元兑换卷】也可以兑换成暖冬积分)',4,8,1000,1,1,0),(418,'【五角兑换卷】','【五角兑换卷】(GM每个月总有那么一次的大放血还不死的神奇生物快去放GM的血吧)',4,8,1000,1,1,0),(419,'【一元兑换卷】','【一元兑换卷】(GM每个月总有那么一次的大放血还不死的神奇生物快去放GM的血吧)',4,8,1000,1,1,0),(420,'【两元兑换卷】','【两元兑换卷】(GM每个月总有那么一次的大放血还不死的神奇生物快去放GM的血吧)',4,8,1000,1,1,0),(421,'〖暖冬宝箱〗','〖暖冬宝箱〗(在寒冷的冬季不再冷,为大家送上暖冬宝箱)',8,8,1000,1,1,1),(422,'〖1千法宝经验卷轴〗','使用后可获得1000法宝经验',1,8,1000,40,1,1),(423,'〖1万法宝经验卷轴〗','使用后可获得1万法宝经验',1,2,1000,40,1,1),(424,'〖10万法宝经验卷轴〗','使用后可获得10万法宝经验',1,20,1000,40,1,1),(425,'〖100万法宝经验卷轴〗','使用后可获得100万法宝经验',1,8,1000,40,1,1),(426,'〖魔化石〗','用于坐骑升级打造的必备物品',2,1,1000,1,1,1),(427,'〖1万西游声望卷轴〗','使用后可获得1万西声望',1,10,1000,1,1,1),(428,'〖风度偏偏〗','使用后可以永久增加HP24000，攻击45000，防御25000，魔攻45000',4,10,1000,1,1,1),(429,'〖至尊战神〗','使用后可以永久增加HP14000，攻击35000，防御15000，魔攻15000',4,10,1000,1,1,1),(430,'〖谁与争峰〗','使用后可以永久增加HP14000，攻击15000，防御15000，魔攻15000',4,10,1000,1,1,1),(431,'〖永不放弃〗','使用后可以永久增加HP24000，攻击25000，防御25000，魔攻25000',4,10,1000,1,1,1),(432,'〖威震幻影〗','使用后可以永久增加HP50000，攻击45000，防御45000，魔攻45000',4,10,1000,1,1,1),(433,'【新】','暖冬活动限定-【新】字(凑齐-新年快乐可在玄武大街找新年大使兑换新年宝箱)',2,10,1000,1,1,0),(434,'【年】','暖冬活动限定-【年】字(凑齐-新年快乐可在玄武大街找新年大使兑换新年宝箱)',2,10,1000,1,1,0),(435,'【快】','暖冬活动限定-【快】字(凑齐-新年快乐可在玄武大街找新年大使兑换新年宝箱)',2,10,1000,1,1,0),(436,'【乐】','暖冬活动限定-【乐】字(凑齐-新年快乐可在玄武大街找新年大使兑换新年宝箱)',2,10,1000,1,1,0),(437,'【时装宝箱】','携手共度公测【时装宝箱】',8,10,1000,1,1,0),(438,'【西游金晶卷】','此物品能购买幻想西游商城中的特殊物品',2,10,1000,1,1,0),(439,'【新年攻击丹】','携手共度2018年【新年攻击丹】(增加攻击300点,限服100个)',5,10,1000,1,1,0),(440,'【新年魔攻丹】','携手共度2018年【新年魔攻丹】(增加魔攻300点,限服100个)',5,10,1000,1,1,0),(441,'【新年防御丹】','携手共度2018年【新年防御丹】(增加防御180点,限服100个)',5,10,1000,1,1,0),(442,'【新年气血丹】','携手共度2018年【新年气血丹】(增加血量888点,限服100个)',5,10,1000,1,1,0),(443,'【恶魔广场门票】','传送至恶魔广场的门票【恶魔广场门票】',1,10,1000,1,1,0),(444,'【年糕】','携手共度2018年【年糕】(用五个年糕在十字街头喂养每天10:00和20:00出现的年兽)',5,10,1000,1,1,0),(445,'〖2018新年狂人〗','使用后可以永久增加HP88888，攻击50000，防御40000，魔攻50000',4,10,1000,1,1,1),(446,'〖2018新年红包〗','使用后可以开出1-10元的红包可找母鸡妈妈兑换红包',4,10,1000,1,1,1),(447,'〖2018一元红包〗','可找母鸡妈妈兑换红包',4,10,1000,1,1,1),(448,'〖2018两元红包〗','可找母鸡妈妈兑换红包',4,10,1000,1,1,1),(449,'〖2018三元红包〗','可找母鸡妈妈兑换红包',4,10,1000,1,1,1),(450,'〖2018五元红包〗','可找母鸡妈妈兑换红包',4,10,1000,1,1,1),(451,'〖2018十元红包〗','可找母鸡妈妈兑换红包',4,10,1000,1,1,1),(452,'【恶魔血】','恶魔广场掉落（可在恶魔广场兑换恶魔声望）',2,10,1000,1,1,0),(453,'〖财宝箱〗','装有满满的2000万银两，瞬间成为高富帅，迎娶白富美',8,5,1000,1,1,1),(454,'〖双倍掉宝符〗','使用后获得10分钟双倍美滋滋的掉率（同类祝福不叠加按最好的掉宝算）',4,5,1000,1,1,1),(455,'〖四倍掉宝符〗','使用后获得10分钟四倍美滋滋的掉率（同类祝福不叠加按最好的掉宝算）',4,5,1000,1,1,1),(456,'〖八倍掉宝符〗','使用后获得10分钟八倍美滋滋的掉率（同类祝福不叠加按最好的掉宝算）',4,10,1000,1,1,1),(457,'〖极品6位ID号（111111）靓号卡〗','使用后ID变更为111111，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(458,'〖极品6位ID号（222222）靓号卡〗','使用后ID变更为222222，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(459,'〖极品6位ID号（333333）靓号卡〗','使用后ID变更为333333，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(460,'〖极品6位ID号（444444）靓号卡〗','使用后ID变更为444444，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(461,'〖极品6位ID号（555555）靓号卡〗','使用后ID变更为555555，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(462,'〖极品6位ID号（666666）靓号卡〗','使用后ID变更为666666，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(463,'〖极品6位ID号（777777）靓号卡〗','使用后ID变更为777777，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(464,'〖极品6位ID号（888888）靓号卡〗','使用后ID变更为888888，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(465,'〖极品6位ID号（999999）靓号卡〗','使用后ID变更为999999，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(466,'〖极品6位ID号（123456）靓号卡〗','使用后ID变更为123456，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(467,'〖极品6位ID号（654321）靓号卡〗','使用后ID变更为654321，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(468,'〖极品6位ID号（520520）靓号卡〗','使用后ID变更为520520，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(469,'〖极品6位ID号（122222）靓号卡〗','使用后ID变更为122222，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(470,'〖极品6位ID号（133333）靓号卡〗','使用后ID变更为133333，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(471,'〖极品6位ID号（144444）靓号卡〗','使用后ID变更为144444，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(472,'〖极品6位ID号（155555）靓号卡〗','使用后ID变更为155555，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(473,'〖极品6位ID号（166666）靓号卡〗','使用后ID变更为166666，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(474,'〖极品6位ID号（177777）靓号卡〗','使用后ID变更为177777，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(475,'〖极品6位ID号（188888）靓号卡〗','使用后ID变更为188888，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(476,'〖极品6位ID号（199999）靓号卡〗','使用后ID变更为199999，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(487,'〖大号财宝箱〗','装有满满的2亿银两，瞬间成为高富帅，迎娶白富美',8,45,1000,1,1,1),(488,'【宠物岛门票】','通往宠物岛的门票（需要前往天宫找宠物岛传送员使用）',1,1,1000,1,1,0),(489,'【西游宣传礼包】','每日推广游戏宣传获得',4,1,1000,1,1,0),(490,'【西游邀请礼包】','每次邀请一人即可获得该礼包',4,1,1000,1,1,0),(491,'【西游新人礼包】','仅限制于被邀请新来的玩家福利，永久只发放一次',4,1,1000,1,1,0),(492,'【公测礼包】','所有公测玩家的福利，绝对超值',4,1,1000,1,1,0),(493,'〖瞌睡虫〗（典藏版）','〖瞌睡虫〗宠物一只充值消费获得，绝对超值',4,1,1000,1,1,1),(494,'〖荣誉宝石包〗（2个）','打开后获得〖荣誉宝石〗x2',4,1,1000,1,1,1),(495,'〖荣誉宝石包〗（15个）','打开后获得〖荣誉宝石〗x5',4,1,1000,1,1,1),(496,'〖荣誉宝石包〗（15个）','打开后获得〖荣誉宝石〗x5',4,1,1000,1,1,1),(497,'〖荣誉宝石包〗（40个）','打开后获得〖荣誉宝石〗x40',4,1,1000,1,1,1),(498,'〖荣誉宝石包〗（100个）','打开后获得〖荣誉宝石〗x100',4,1,1000,1,1,1),(499,'〖冲榜助力包〗','打开后获得〖钻魂〗x100，外加赠送大幸运草一根',4,20,1000,1,1,1),(500,'【才子印记】','【才子印记】暑期假日清凉一夏获得',6,20,1000,1,1,0),(501,'【才子印记】（碎片）','【才子印记】（碎片）凑足二十个可换【才子印记】',6,20,1000,1,1,0),(502,'超级幸运草','可以为装备打孔或者装备升星提示10%的成功率，锻造装备必备！（直接在身上装备升级消耗）',4,3,1000,1,1,1),(503,'【三彩贝壳】','【三彩贝壳】活动获得可随机开出以外惊喜哦（必得学分）',6,20,1000,1,1,0),(504,'【五彩贝壳】','【五彩贝壳】活动获得可随机开出以外惊喜哦（必得学分）',6,20,1000,1,1,0),(505,'【七彩贝壳】','【七彩贝壳】活动获得可随机开出以外惊喜哦（必得学分）',6,20,1000,1,1,0),(506,'【比翼图纸】','【比翼图纸】可以打造【比翼双飞の婚戒】（典藏版）或者【比翼双飞の婚链】（典藏版）',6,20,1000,1,1,0),(507,'〖武文双全〗','使用后可以永久增加HP50000，攻击35000，防御35000，魔攻35000',4,10,1000,1,1,1),(508,'〖文状元〗','使用后可以永久增加HP40000，攻击25000，防御25000，魔攻25000',4,10,1000,1,1,1),(509,'〖三好学生〗','使用后可以永久增加HP30000，攻击10000，防御10000，魔攻10000',4,10,1000,1,1,1),(510,'〖金符碎片〗','〖金符碎片〗+〖金魂〗+银两可在朱雀大街符咒大师处锻造成为成品（但并非一定成功哦）',2,10,1000,1,1,1),(511,'〖钻符碎片〗','〖钻符碎片〗+〖钻魂〗+银两可在朱雀大街符咒大师处锻造成为成品（但并非一定成功哦）',2,10,1000,1,1,1),(512,'〖陨符碎片〗','〖陨符碎片〗+〖陨魂〗+银两可在朱雀大街符咒大师处锻造成为成品（但并非一定成功哦）',2,10,1000,1,1,1),(513,'〖银符碎片〗','〖银符碎片〗+〖银魂〗+银两可在朱雀大街符咒大师处锻造成为成品（但并非一定成功哦）',2,10,1000,1,1,1),(514,'〖黄金贵族宝箱〗','〖黄金贵族宝箱〗开通黄金贵族的玩家每日领取获得',8,10,1000,1,1,1),(515,'〖铂金贵族宝箱〗','〖铂金贵族宝箱〗开通铂金贵族的玩家每日领取获得',8,10,1000,1,1,1),(516,'〖钻石皇族宝箱〗','〖钻石皇族宝箱〗开通钻石皇族的玩家每日领取获得',8,10,1000,1,1,1),(517,'〖至尊皇族宝箱〗','〖至尊皇族宝箱〗开通至尊皇族的玩家每日领取获得',8,10,1000,1,1,1),(518,'〖黄金贵族卡〗','使用后可获得黄金贵族的尊贵身份并且领取30次对应福利（每日1次），具体奖励看福利页面',4,10,1000,1,1,1),(519,'〖铂金贵族卡〗','使用后可获得黄铂金族的尊贵身份并且领取30次对应福利（每日1次），具体奖励看福利页面',4,10,1000,1,1,1),(520,'〖钻石皇族卡〗','使用后可获得钻石皇族的尊贵身份并且领取30次对应福利（每日1次），具体奖励看福利页面',4,10,1000,1,1,1),(521,'〖至尊皇族卡〗','使用后可获得尊皇族的尊贵身份并且领取30次对应福利（每日1次），具体奖励看福利页面',4,10,1000,1,1,1),(522,'【保命丸】','使用可恢复50万体力!',5,2,1000,1,1,0),(523,'【小保命丸】','使用可恢复100万体力!',5,2,1000,1,1,0),(524,'【中保命丸】','使用可恢复200万体力!',5,2,1000,1,1,0),(525,'【大保命丸】','使用可恢复500万体力!',5,2,1000,1,1,0),(526,'【超保命丸】','使用可恢复800万体力!',5,2,1000,1,1,0),(527,'【极品保命丸】','使用可恢复1500万体力!',5,2,1000,1,1,0),(528,'【灵品保命丸】','使用可恢复3000万体力!',5,2,1000,1,1,0),(529,'【仙品保命丸】','使用可恢复5000万体力!',5,2,1000,1,1,0),(530,'【神品保命丸】','使用可恢复7000万体力!',5,2,1000,1,1,0),(531,'【圣品保命丸】','使用可恢复1亿体力!',5,2,1000,1,1,0),(532,'〖冰晶丹〗','使用永久增加攻击120点！最多可使用100颗！',5,2,1000,1,1,1),(533,'〖花果丹〗','使用永久增加魔攻120点！最多可使用100颗！',5,2,1000,1,1,1),(534,'〖瑶池丹〗','使用永久增加防御200点！最多可使用100颗！',5,2,1000,1,1,1),(535,'〖老君丹〗','使用永久增加血量500点！最多可使用100颗！',5,2,1000,1,1,1),(536,'〖金刚经〗','使用永久增加攻击300点！最多可使用100颗！',5,2,1000,1,1,1),(537,'〖法华经〗','使用永久增加魔攻300点！最多可使用100颗！',5,2,1000,1,1,1),(538,'〖地藏经〗','使用永久增加防御500点！最多可使用100颗！',5,2,1000,1,1,1),(539,'〖严华经〗','使用永久增加血量1000点！最多可使用100颗！',5,2,1000,1,1,1),(540,'〖莲花金丹〗','使用永久增加攻击500点！最多可使用100颗！',5,2,1000,1,1,1),(541,'〖黑龙金丹〗','使用永久增加魔攻500点！最多可使用100颗！',5,2,1000,1,1,1),(542,'〖修炼攻击仙丹〗','使用永久增加攻击600点！最多可使用100颗！',5,2,1000,1,1,1),(543,'〖修炼魔攻仙丹〗','使用永久增加魔攻600点！最多可使用100颗！',5,2,1000,1,1,1),(544,'〖修炼防御仙丹〗','使用永久增加防御600点！最多可使用100颗！',5,2,1000,1,1,1),(545,'〖修炼生命仙丹〗','使用永久增加血量1000点！最多可使用100颗！',5,2,1000,1,1,1),(546,'〖攻之龙丹〗','使用永久增加攻击1000点！最多可使用100颗！',5,2,1000,1,1,1),(547,'〖魔之龙丹〗','使用永久增加魔攻1000点！最多可使用100颗！',5,2,1000,1,1,1),(548,'〖防之龙丹〗','使用永久增加防御1000点！最多可使用100颗！',5,2,1000,1,1,1),(549,'〖血之龙丹〗','使用永久增加血量3000点！最多可使用100颗！',5,2,1000,1,1,1),(550,'〖装备图纸〗（宠物）','升级宠物装备的必备图纸，无法直接使用请在宠物装备栏升级消耗',2,2,1000,1,1,1),(551,'〖女神之恋〗','使用后可以永久增加HP50000，攻击50000，防御50000，魔攻50000',4,2,1000,1,1,1),(552,'〖全服公敌〗','使用后可以永久增加HP100000，攻击100000，防御100000，魔攻100000',4,2,1000,1,1,1),(553,'〖至尊天圣〗','使用后可以永久增加HP60000，攻击60000，防御60000，魔攻60000',4,2,1000,1,1,1),(554,'〖一掷千金〗','使用后可以永久增加HP100000，攻击100000，防御100000，魔攻100000',4,2,1000,1,1,1),(555,'〖至尊红颜〗','使用后可以永久增加HP88888，攻击88888，防御88888，魔攻88888',4,2,1000,1,1,1),(556,'〖望门贵族〗','使用后可以永久增加HP66666，攻击66666，防御66666，魔攻66666',4,2,1000,1,1,1),(557,'〖倾城伊人〗','使用后可以永久增加HP50000，攻击50000，防御50000，魔攻50000',4,2,1000,1,1,1),(558,'【清】','【清】2018暑期活动获得，凑齐四字可在玄武大街找三藏兑换【清凉宝箱】哦',6,2,1000,1,1,0),(559,'【凉】','【凉】2018暑期活动获得，凑齐四字可在玄武大街找三藏兑换【清凉宝箱】哦',6,2,1000,1,1,0),(560,'【一】','【一】2018暑期活动获得，凑齐四字可在玄武大街找三藏兑换【清凉宝箱】哦',6,2,1000,1,1,0),(561,'【夏】','【夏】2018暑期活动获得，凑齐四字可在玄武大街找三藏兑换【清凉宝箱】哦',6,2,1000,1,1,0),(562,'【清凉宝箱】','【清凉宝箱】可随机获得1万西游声望卷或者1万法宝经验卷',8,2,1000,1,1,0),(563,'〖万能字〗','〖万能字〗可在玄武大街找三藏兑换任意字体哦哦',6,2,1000,1,1,1),(564,'【1万西游声望卷轴】','使用后可获得1万西声望',1,10,1000,1,1,0),(565,'【1万法宝经验卷轴】','使用后可获得1万法宝经验',1,2,1000,40,1,0),(566,'〖冠军宝石包〗（1个）','打开后获得〖冠军宝石〗x1',4,1,1000,1,1,1),(567,'〖冠军宝石包〗（3个）','打开后获得〖冠军宝石〗x3',4,1,1000,1,1,1),(568,'〖冠军宝石包〗（8个）','打开后获得〖冠军宝石〗x8',4,1,1000,1,1,1),(569,'〖冠军宝石包〗（30个）','打开后获得〖冠军宝石〗x30',4,1,1000,1,1,1),(570,'〖齐天大圣〗（宠物蛋）','通天塔20层齐天大圣掉落或者凑齐〖大圣精魄〗兑换',4,1,1000,1,1,1),(571,'〖大圣精魄〗','传说凑齐大圣精魄能够复活〖齐天大圣〗',4,1,1000,1,1,1),(572,'〖百年魔珠〗（小袋）','打开后可获得〖百年魔珠〗x1000',2,1,1000,1,1,1),(573,'〖百年魔珠〗（中袋）','打开后可获得〖百年魔珠〗x5000',2,1,1000,1,1,1),(574,'〖百年魔珠〗（大袋）','打开后可获得〖百年魔珠〗x10000',2,1,1000,1,1,1),(575,'【恶魔符文】','可在恶魔广场兑换恶魔声望',2,1,1000,1,1,0),(576,'【恶魔入场卷】','可在恶魔广场兑换恶魔声望',1,1,1000,1,1,0),(577,'〖圣灵锻造图纸〗','锻造圣灵装备的图纸',2,10,1000,1,1,1),(578,'【昊天神丹】','使用后可解封159等级',6,1,1000,159,1,0),(579,'〖探险符〗','〖探险符〗金银山探险获得可以兑换超值的物品哦',2,1,1000,1,1,1),(580,'〖天下至尊〗','使用后可以永久增加HP200000，攻击200000，防御200000，魔攻200000',4,2,1000,1,1,1),(581,'〖蓬莱至尊〗','使用后可以永久增加HP150000，攻击150000，防御150000，魔攻150000',4,2,1000,1,1,1),(582,'〖昆仑至尊〗','使用后可以永久增加HP100000，攻击100000，防御100000，魔攻100000',4,2,1000,1,1,1),(583,'〖名动天下〗','使用后可以永久增加HP150000，攻击150000，防御150000，魔攻150000',4,2,1000,1,1,1),(584,'〖万法不侵〗','使用后可以永久增加HP100000，攻击100000，防御100000，魔攻100000',4,2,1000,1,1,1),(585,'〖乾坤唯仙〗','使用后可以永久增加HP100000，攻击100000，防御100000，魔攻100000',4,2,1000,1,1,1),(586,'〖舞星仙姬〗','使用后可以永久增加HP100000，攻击100000，防御100000，魔攻100000',4,2,1000,1,1,1),(587,'〖王者宝石包〗（1个）','打开后获得〖王者宝石〗x1',4,1,1000,1,1,1),(588,'〖王者宝石包〗（3个）','打开后获得〖王者宝石〗x3',4,1,1000,1,1,1),(589,'〖王者宝石包〗（8个）','打开后获得〖王者宝石〗x8',4,1,1000,1,1,1),(590,'〖王者宝石包〗（30个）','打开后获得〖王者宝石〗x30',4,1,1000,1,1,1),(591,'【喜鹊蛋】','活动产出【喜鹊蛋】可在牛郎出孵化小喜鹊',6,1,1000,1,1,0),(592,'【小喜鹊】','每只【小喜鹊】都代表着牛郎与织女浓浓的爱情故事！！',6,1,1000,1,1,0),(593,'〖诛仙令〗','拥有此诛仙令可随机开出诛仙任意位置装备包一件',4,1000,1000,159,1,1),(594,'〖诛仙武器令〗','能够开出对应职业的诛仙武器一件',4,1000,1000,159,1,1),(595,'〖诛仙盔甲令〗','能够开出诛仙盔甲一件',4,1000,1000,159,1,1),(596,'〖诛仙头盔令〗','能够开出诛仙头盔一件',4,1000,1000,159,1,1),(597,'〖诛仙鞋子令〗','能够开出诛仙鞋子一件',4,1000,1000,159,1,1),(598,'〖诛仙项链令〗','能够开出诛仙项链一件',4,1000,1000,159,1,1),(599,'〖诛仙手镯令〗','能够开出诛仙手镯一件',4,1000,1000,159,1,1),(600,'【喜鹊令】','受到牛郎与织女的祝福（可将159典藏升级到179典藏）',4,1000,1000,159,1,0),(601,'〖玄天残叶〗','〖玄天残叶〗升级139坐骑仙兽必备材料',2,20,1000,1,1,1),(602,'〖神兽仙魄〗','〖神兽仙魄〗升级139坐骑必备材料',2,20,1000,1,1,1),(603,'〖祥云残片〗','〖祥云残片〗升级159坐骑仙兽必备材料',2,20,1000,1,1,1),(604,'〖大圣仙魄〗','〖大圣仙魄〗升级159坐骑仙兽必备材料',2,20,1000,1,1,1),(605,'〖灵匣宝盒〗','〖灵匣宝盒〗能开出许多意外的惊喜哟',8,20,1000,1,1,1),(606,'〖神匣宝盒〗','〖神匣宝盒〗能开出许多意外的惊喜哟',8,20,1000,1,1,1),(607,'〖月光宝盒〗','〖月光宝盒〗穿梭未来和过去，受到紫霞仙子的青睐后方才可开启',8,20,1000,1,1,1),(608,'〖宝盒钥匙〗','〖宝盒钥匙〗可以用来开启〖灵匣盒子〗和〖神匣盒子〗的钥匙',4,20,1000,1,1,1),(609,'〖金甲圣衣〗','〖金甲圣衣〗可帮助紫霞仙找到至尊宝',6,20,1000,1,1,1),(610,'〖七彩祥云〗','〖七彩祥云〗可帮助紫霞仙找到至尊宝',6,20,1000,1,1,1),(611,'〖紫霞眼泪〗','〖紫霞眼泪〗可帮助紫霞仙找到至尊宝',6,20,1000,1,1,1),(612,'〖紧箍咒〗','〖紧箍咒〗可帮助紫霞仙找到至尊宝',6,20,1000,1,1,1),(613,'〖至尊宝密令〗','〖至尊宝密令〗可用于开启〖月光宝盒〗',4,20,1000,1,1,1),(614,'〖麒麟圣祖〗（宠物蛋）','〖麒麟圣祖〗绝版宠物（至尊宝紫霞仙子活动充值获得）',4,1,1000,1,1,1),(615,'〖麒麟圣祖〗（宠物蛋-万里挑一）','被GM调教好了的宠物，必出五级变异圣品〖麒麟圣祖〗绝版宠物（至尊宝紫霞仙子活动充值获得）',4,1,1000,1,1,1),(616,'〖齐天大圣〗（宠物蛋-万里挑一）','被GM调教好了的宠物，必出五级变异圣品〖齐天大圣〗绝版宠物（至尊宝紫霞仙子活动充值获得）',4,1,1000,1,1,1),(617,'〖练星符〗（白）','宠物1至20星升星材料',4,1,1000,1,1,1),(618,'〖练星符〗（绿）','宠物21至40星升星材料',4,1,1000,1,1,1),(619,'〖练星符〗（蓝）','宠物41至60星升星材料',4,1,1000,1,1,1),(620,'〖练星符〗（紫）','宠物61至80星升星材料',4,1,1000,1,1,1),(621,'〖练星符〗（完美の紫）','宠物81至100星升星材料',4,1,1000,1,1,1),(622,'〖练星符〗（橙）','宠物101至120星升星材料',4,1,1000,1,1,1),(623,'〖练星符〗（完美の橙）','宠物121至150星升星材料',4,1,1000,1,1,1),(624,'〖许愿符〗','每次许愿后必得用于许愿落空后兑换',4,1,1000,1,1,1),(625,'〖1亿修炼经验丹〗','使用后获得一亿修炼经验',5,1,1000,160,1,1),(626,'〖5亿修炼经验丹〗','使用后获得五亿修炼经验',5,1,1000,160,1,1),(627,'〖10亿修炼经验丹〗','使用后获得十亿修炼经验',5,1,1000,160,1,1),(628,'〖金宝箱〗','打开箱子可随机获得物品（需要万能钥匙开启）',8,2,1000,1,1,1),(629,'〖七夕宝箱〗','七夕节日获得可开出大量宝贝',8,2,1000,1,1,1),(630,'【甜】','传说集齐甜蜜七夕四字可获取七夕宝箱',6,2,1000,1,1,0),(631,'【蜜】','传说集齐甜蜜七夕四字可获取七夕宝箱',6,2,1000,1,1,0),(632,'【七】','传说集齐甜蜜七夕四字可获取七夕宝箱',6,2,1000,1,1,0),(633,'【夕】','传说集齐甜蜜七夕四字可获取七夕宝箱',6,2,1000,1,1,0),(634,'〖鸳鸯帕〗','〖鸳鸯帕〗可用于兑换典藏婚饰品',6,2,1000,1,1,1),(635,'〖姻缘草〗','〖姻缘草〗可用于兑换典藏婚饰品',6,2,1000,1,1,1),(636,'〖银心铃〗','〖姻缘草〗可用于兑换典藏婚饰品',6,2,1000,1,1,1),(637,'〖噬魂锻造图纸〗','用于打造噬魂装备的图纸',2,2,1000,1,1,1),(638,'【七夕令】','用于179典藏升级到199典藏',4,2,1000,1,1,0),(639,'〖情圣〗','使用后可以永久增加HP50000，攻击50000，防御50000，魔攻50000',4,2,1000,1,1,1),(640,'〖万人迷〗','使用后可以永久增加HP50000，攻击50000，防御50000，魔攻50000',4,2,1000,1,1,1),(641,'〖天作之合〗','使用后可以永久增加HP80000，攻击80000，防御80000，魔攻80000',4,2,1000,1,1,1),(642,'〖爱你一万年〗','使用后可以永久增加HP100000，攻击100000，防御100000，魔攻100000',4,2,1000,1,1,1),(643,'〖真爱无敌〗','使用后可以永久增加HP100000，攻击100000，防御100000，魔攻100000',4,2,1000,1,1,1),(644,'〖绝世情圣〗','使用后可以永久增加HP100000，攻击100000，防御100000，魔攻100000',4,2,1000,1,1,1),(645,'〖天下最倾城〗','使用后可以永久增加HP110000，攻击110000，防御110000，魔攻110000',4,2,1000,1,1,1),(646,'〖天下最风流〗','使用后可以永久增加HP110000，攻击110000，防御110000，魔攻110000',4,2,1000,1,1,1),(647,'〖鹊桥仙子〗','使用后可以永久增加HP66666，攻击66666，防御66666，魔攻66666',4,2,1000,1,1,1),(648,'〖谦谦公子〗','使用后可以永久增加HP66666，攻击66666，防御66666，魔攻66666',4,2,1000,1,1,1),(649,'〖娇美宠儿〗','使用后可以永久增加HP77777，攻击77777，防御77777，魔攻77777',4,2,1000,1,1,1),(650,'〖柔情郎君〗','使用后可以永久增加HP77777，攻击77777，防御77777，魔攻77777',4,2,1000,1,1,1),(651,'〖传世战神〗','使用后可以永久增加HP150000，攻击150000，防御150000，魔攻150000',4,2,1000,1,1,1),(652,'〖天下第一〗','使用后可以永久增加HP160000，攻击160000，防御160000，魔攻160000',4,2,1000,1,1,1),(653,'〖灿若星斗〗','使用后可以永久增加HP160000，攻击160000，防御160000，魔攻160000',4,2,1000,1,1,1),(654,'〖富甲天下〗','使用后可以永久增加HP180000，攻击180000，防御180000，魔攻180000',4,2,1000,1,1,1),(655,'〖登峰造极〗','使用后可以永久增加HP200000，攻击200000，防御200000，魔攻200000',4,2,1000,1,1,1),(656,'【鹊翎】','【鹊翎】每日七夕天衣阁学徒苏语迟获取凑齐十个可兑换称号一个',6,2,1000,1,1,0),(657,'〖七夕万能字〗','〖七夕万能字〗用于兑换各种七夕字体',6,2,1000,1,1,1),(658,'〖超级七夕宝箱〗','能够开出〖七夕宝箱〗所得之物的10倍',8,2,1000,1,1,1),(659,'〖碎银块〗','价值连城的碎银块（可兑换1亿银两）',4,2,1000,1,1,1),(660,'〖银块〗','价值连城的银块（可兑换5亿银两）',4,2,1000,1,1,1),(661,'〖银锭〗','价值连城的银锭（可兑换10亿银两）',4,2,1000,1,1,1),(662,'〖金块〗','价值连城的金块（可兑换50亿银两）',4,2,1000,1,1,1),(663,'〖金锭〗','价值连城的金锭（可兑换100亿银两）',4,2,1000,1,1,1),(664,'【善果】','将【善果】交给天牢牢头可以助你减轻的罪孽（天牢牢头购买获得）',6,2,1000,1,1,0),(665,'〖免罪金牌〗','将〖免罪金牌〗交给天牢牢头可以助你减轻的罪孽（天牢牢头购买获得）',6,2,1000,1,1,1),(666,'〖西游新秀〗','使用后可以永久增加HP50000，攻击50000，防御50000，魔攻50000',4,2,1000,1,1,1),(667,'〖西游漫记〗','使用后可以永久增加HP50000，攻击50000，防御50000，魔攻50000',4,2,1000,1,1,1),(668,'〖玫瑰情人〗','使用后可以永久增加HP50000，攻击50000，防御50000，魔攻50000',4,2,1000,1,1,1),(669,'【科举答题】','使用后可以永久增加HP60000，攻击60000，防御60000，魔攻60000',4,2,1000,1,1,0),(670,'【举人】','使用后可以永久增加HP70000，攻击50000，防御50000，魔攻50000',4,2,1000,1,1,0),(671,'【榜眼】','使用后可以永久增加HP70000，攻击50000，防御50000，魔攻50000',4,2,1000,1,1,0),(672,'〖领跑西游〗','使用后可以永久增加HP70000，攻击70000，防御70000，魔攻70000',4,2,1000,1,1,1),(673,'〖超凡入圣〗','使用后可以永久增加HP150000，攻击100000，防御100000，魔攻100000',4,2,1000,1,1,1),(674,'〖震古烁今〗','使用后可以永久增加HP200000，攻击120000，防御120000，魔攻120000',4,2,1000,1,1,1),(675,'〖炉火纯青〗','使用后可以永久增加HP250000，攻击120000，防御120000，魔攻120000',4,2,1000,1,1,1),(676,'〖名扬四海〗','使用后可以永久增加HP300000，攻击150000，防御150000，魔攻150000',4,2,1000,1,1,1),(677,'〖进击の一骑绝尘〗','使用后可以永久增加HP300000，攻击180000，防御180000，魔攻180000',4,2,1000,1,1,1),(678,'〖进击の冠绝天下〗','使用后可以永久增加HP350000，攻击200000，防御200000，魔攻200000',4,2,1000,1,1,1),(679,'〖进击の笑傲苍穹〗','使用后可以永久增加HP500000，攻击300000，防御300000，魔攻300000',4,2,1000,1,1,1),(680,'【铅球】','体育老师的【铅球】开学活动获得',6,2,1000,1,1,0),(681,'【奖状】','〖活动〗脑筋急转弯老师开学活动获得',6,2,1000,1,1,0),(682,'〖开学礼包〗','〖开学礼包〗有小概率的范围开出称号〖西游漫记〗〖玫瑰情人〗〖领跑西游〗',8,2,1000,1,1,0),(683,'〖开学大礼包〗','〖开学大礼包〗有较高概率的范围开出称号〖西游漫记〗〖玫瑰情人〗〖领跑西游〗',8,2,1000,1,1,0),(684,'【粉笔】','开学活动获得（用于兑换各类物品）',6,2,1000,1,1,0),(685,'【橡皮擦】','开学活动获得（用于兑换各类物品）',6,2,1000,1,1,0),(686,'【铅笔】','开学活动获得（用于兑换各类物品）',6,2,1000,1,1,0),(687,'【墨水】','开学活动获得（用于兑换各类物品）',6,2,1000,1,1,0),(688,'〖女神同桌〗','开学活动获得（用于兑换各类物品）',6,2,1000,1,1,1),(689,'〖课本〗','开学活动获得（可交给找校长获取学分）',6,2,1000,1,1,1),(690,'〖帝王之心〗','王者风范帝王专属（打造帝王套装材料）',2,2,1000,1,1,1),(691,'〖帝王之血〗','王者风范帝王专属（打造帝王套装材料）',2,2,1000,1,1,1),(692,'〖帝王之魂〗','王者风范帝王专属（打造帝王套装材料）',2,2,1000,1,1,1),(693,'【九转仙丹】','服用后可解封199等级',6,2,1000,1,1,0),(694,'〖神仙果〗','通天层飞仙层或者堕魔层掉落（可在天蓬元帅处兑换金豆）',4,20,1000,1,1,1),(695,'〖BOSS如意令〗','凑齐相对应的〖BOSS如意令〗可兑换称号',4,20,1000,1,1,1),(696,'〖BOSS杀手〗','使用后可以永久增加HP50000，攻击50000，防御50000，魔攻50000',4,20,1000,1,1,1),(697,'〖猎魔之王〗','使用后可以永久增加HP100000，攻击100000，防御100000，魔攻100000',4,20,1000,1,1,1),(698,'〖不差钱〗','使用后可以永久增加HP100000，攻击100000，防御100000，魔攻100000',4,20,1000,1,1,1),(699,'〖我是大姐〗','使用后可以永久增加HP120000，攻击120000，防御120000，魔攻120000',4,20,1000,1,1,1),(700,'〖我是二哥〗','使用后可以永久增加HP120000，攻击120000，防御120000，魔攻120000',4,20,1000,1,1,1),(701,'〖十大富豪〗','使用后可以永久增加HP100000，攻击100000，防御100000，魔攻100000',4,20,1000,1,1,1),(702,'〖威力无边〗','使用后可以永久增加HP110000，攻击110000，防御110000，魔攻110000',4,20,1000,1,1,1),(703,'〖装备榜第一〗','使用后可以永久增加HP200000，攻击200000，防御200000，魔攻200000',4,20,1000,1,1,1),(704,'〖等级榜第一〗','使用后可以永久增加HP200000，攻击200000，防御200000，魔攻200000',4,20,1000,1,1,1),(705,'〖三界战神〗','使用后可以永久增加HP180000，攻击180000，防御180000，魔攻180000',4,20,1000,1,1,1),(706,'〖BOSS终结者〗','使用后可以永久增加HP200000，攻击200000，防御200000，魔攻200000',4,20,1000,1,1,1),(707,'〖一骑当先〗','使用后可以永久增加HP300000，攻击300000，防御300000，魔攻300000',4,20,1000,1,1,1),(708,'〖新妖之王〗','使用后可以永久增加HP400000，攻击400000，防御400000，魔攻400000',4,20,1000,1,1,1),(709,'〖豪无人性〗','使用后可以永久增加HP120000，攻击120000，防御120000，魔攻120000',4,20,1000,1,1,1),(711,'〖封神英雄〗','使用后可以永久增加HP130000，攻击130000，防御130000，魔攻130000',4,20,1000,1,1,1),(712,'〖天外飞仙征服者〗','使用后可以永久增加HP150000，攻击150000，防御150000，魔攻150000',4,20,1000,1,1,1),(713,'〖打遍天下无敌手〗','使用后可以永久增加HP200000，攻击200000，防御200000，魔攻200000',4,20,1000,1,1,1),(714,'〖土豪就是任性〗','使用后可以永久增加HP400000，攻击400000，防御400000，魔攻400000',4,20,1000,1,1,1),(715,'〖十大神翼〗','使用后可以永久增加HP180000，攻击180000，防御180000，魔攻180000',4,20,1000,1,1,1),(716,'〖不屈白银〗','使用后可以永久增加HP80000，攻击80000，防御80000，魔攻80000',4,20,1000,1,1,1),(717,'【坚毅之星】','放入星盘大阵后HP提升200000',4,20,1000,1,1,0),(718,'【守护之星】','放入星盘大阵后防御提升100000',4,20,1000,1,1,0),(719,'【盛怒之星】','放入星盘大阵后攻击提升100000',4,20,1000,1,1,0),(720,'【镇静之星】','放入星盘大阵后魔攻提升100000',4,20,1000,1,1,0),(721,'【复苏之星】','放入星盘大阵后HP提升300000',4,20,1000,1,1,0),(722,'【潮汐之星】','放入星盘大阵后防御提升200000',4,20,1000,1,1,0),(723,'【寂灭之星】','放入星盘大阵后攻击提升200000',4,20,1000,1,1,0),(724,'【风暴之星】','放入星盘大阵后魔攻提升200000',4,20,1000,1,1,0),(725,'【神星の永生】','放入星盘大阵后HP提升500000',4,20,1000,1,1,0),(726,'【神星の混沌】','放入星盘大阵后防御提升400000',4,20,1000,1,1,0),(727,'【神星の秩序】','放入星盘大阵后攻击提升400000',4,20,1000,1,1,0),(728,'【神星の圣恩】','放入星盘大阵后魔攻提升400000',4,20,1000,1,1,0),(729,'【小宇宙】','凑齐足够的可用于各类占星兑换',4,20,1000,1,1,0),(730,'【占星秘典】','可用于〖高级占星〗〖极品占星〗消耗',4,20,1000,1,1,0),(731,'【智慧之星】（攻）','放入星盘大阵后冰火雷攻+5',4,20,1000,1,1,0),(732,'【智慧之星】（防）','放入星盘大阵后冰火雷防+5',4,20,1000,1,1,0),(733,'【元素之星】（攻）','放入星盘大阵后冰火雷攻+10',4,20,1000,1,1,0),(734,'【元素之星】（防）','放入星盘大阵后冰火雷防+10',4,20,1000,1,1,0),(735,'【神星の元素之王】（攻）','放入星盘大阵后冰火雷攻+20',4,20,1000,1,1,0),(736,'【神星の元素之王】（防）','放入星盘大阵后冰火雷防+20',4,20,1000,1,1,0),(737,'【秘宝钥匙】','用于开启秘宝宝箱的钥匙',4,20,1000,1,1,0),(738,'【秘宝碎片】','用于合成秘宝宝箱或者钥匙的碎片',4,20,1000,1,1,0),(739,'【秘宝宝箱】','开启秘宝宝箱需要【秘宝钥匙】',8,20,1000,1,1,1),(740,'【桂花糕】','中秋节获得获取',6,20,1000,1,1,0),(741,'【糯米粉】','中秋节活动掉落',6,20,1000,1,1,0),(742,'〖香甜桂花〗','中秋节活动掉落',6,20,1000,1,1,1),(743,'〖玉兔蜜糖〗','中秋节活动掉落',6,20,1000,1,1,1),(744,'【金秋的思念】','中秋节活动各类礼盒开出（用于时装兑换）',6,20,1000,1,1,0),(745,'〖凤梨月饼〗','使用后永久增加HP1000（中秋节活动获得）',5,20,1000,1,1,1),(746,'〖玫瑰月饼〗','使用后永久增加HP1200（中秋节活动获得）',5,20,1000,1,1,1),(747,'〖莲蓉月饼〗','使用后永久增加HP1400（中秋节活动获得）',5,20,1000,1,1,1),(748,'〖椰蓉月饼〗','使用后永久增加HP1500（中秋节活动获得）',5,20,1000,1,1,1),(749,'〖蓝莓月饼〗','使用后永久增加HP1600（中秋节活动获得）',5,20,1000,1,1,1),(750,'〖桂花月饼〗','使用后永久增加HP1800（中秋节活动获得）',5,20,1000,1,1,1),(751,'〖葡萄月饼〗','使用后永久增加HP2000（中秋节活动获得）',5,20,1000,1,1,1),(752,'〖五仁月饼〗','使用后永久增加攻击500（中秋节活动获得）',5,20,1000,1,1,1),(753,'〖双黄月饼〗','使用后永久增加攻击700（中秋节活动获得）',5,20,1000,1,1,1),(754,'〖冰皮月饼〗','使用后永久增加攻击900（中秋节活动获得）',5,20,1000,1,1,1),(755,'〖水果月饼〗','使用后永久增加攻击1100（中秋节活动获得）',5,20,1000,1,1,1),(756,'〖红豆沙月饼〗','使用后永久增加攻击1500（中秋节活动获得）',5,20,1000,1,1,1),(757,'〖黄金月饼〗','使用后永久增加魔攻500（中秋节活动获得）',5,20,1000,1,1,1),(758,'〖云腿月饼〗','使用后永久增加魔攻700（中秋节活动获得）',5,20,1000,1,1,1),(759,'〖水蜜桃月饼〗','使用后永久增加魔攻900（中秋节活动获得）',5,20,1000,1,1,1),(760,'〖哈密瓜月饼〗','使用后永久增加魔攻1100（中秋节活动获得）',5,20,1000,1,1,1),(761,'〖草莓月饼〗','使用后永久增加魔攻1500（中秋节活动获得）',5,20,1000,1,1,1),(762,'〖鲜花月饼〗','使用后永久增加防御500（中秋节活动获得）',5,20,1000,1,1,1),(763,'〖七彩月饼〗','使用后永久增加防御700（中秋节活动获得）',5,20,1000,1,1,1),(764,'〖榄仁烧鸡月饼〗','使用后永久增加防御900（中秋节活动获得）',5,20,1000,1,1,1),(765,'〖奶油椰丝月饼〗','使用后永久增加防御1100（中秋节活动获得）',5,20,1000,1,1,1),(766,'〖叉烧腊肠月饼〗','使用后永久增加防御1500（中秋节活动获得）',5,20,1000,1,1,1),(767,'〖嫦娥月饼〗（血）','使用后永久增加HP6000（中秋节活动获得）',5,20,1000,1,1,1),(768,'〖嫦娥月饼〗（攻）','使用后永久增加攻击4000（中秋节活动获得）',5,20,1000,1,1,1),(769,'〖嫦娥月饼〗（魔）','使用后永久增加魔攻4000（中秋节活动获得）',5,20,1000,1,1,1),(770,'〖嫦娥月饼〗（防）','使用后永久增加防御3000（中秋节活动获得）',5,20,1000,1,1,1),(771,'〖玉兔月饼〗','将此月饼赠送给嫦娥将获得中秋积分（中秋节抢榜特供）',6,20,1000,1,1,1),(772,'〖风花月饼礼盒〗','能开出各种好吃的月饼',8,20,1000,1,1,1),(773,'〖雪月月饼礼盒〗','能开出各种好吃的月饼',8,20,1000,1,1,1),(774,'〖金秋月饼礼盒〗','能开出各种好吃的月饼',8,20,1000,1,1,1),(775,'〖鸿福月饼礼盒〗','能开出各种好吃的月饼',8,20,1000,1,1,1),(776,'〖嫦娥月饼礼盒〗','能开出各种好吃的月饼',8,20,1000,1,1,1),(777,'【10元充值卡】','使用后可获得10元现金充值1:10的金豆和对等的vip积分（使用此充值卡不参与充值排名）',4,20,1000,1,1,0),(778,'【20元充值卡】','使用后可获得20元现金充值1:10的金豆和对等的vip积分（使用此充值卡不参与充值排名）',4,20,1000,1,1,0),(779,'【50元充值卡】','使用后可获得50元现金充值1:10的金豆和对等的vip积分（使用此充值卡不参与充值排名）',4,20,1000,1,1,0),(780,'【100元充值卡】','使用后可获得100元现金充值1:10的金豆和对等的vip积分（使用此充值卡不参与充值排名）',4,20,1000,1,1,0),(781,'【200元充值卡】','使用后可获得200元现金充值1:10的金豆和对等的vip积分（使用此充值卡不参与充值排名）',4,20,1000,1,1,0),(782,'【500元充值卡】','使用后可获得500元现金充值1:10的金豆和对等的vip积分（使用此充值卡不参与充值排名）',4,20,1000,1,1,0),(783,'【1000元充值卡】','使用后可获得1000元现金充值1:10的金豆和对等的vip积分（使用此充值卡不参与充值排名）',4,20,1000,1,1,0),(784,'【2000元充值卡】','使用后可获得2000元现金充值1:10的金豆和对等的vip积分（使用此充值卡不参与充值排名）',4,20,1000,1,1,0),(785,'【150级升级卡】','使用后可获将等级变更为150级（注意请勿大于150等级使用否则也会变为150级）',4,20,1000,1,1,0),(786,'【1亿修炼经验丹】','使用后获得一亿修炼经验',5,1,1000,1,1,0),(787,'【5亿修炼经验丹】','使用后获得五亿修炼经验',5,1,1000,1,1,0),(788,'【10亿修炼经验丹】','使用后获得十亿修炼经验',5,1,1000,1,1,0),(789,'【二区花果山助力包】','打开后可获得【200充值卡】x1【诛仙套装】【150级升级卡】x1，【vip练级卷】x20，【10亿修炼经验丹】x10，【万能果】x100，【1万西游声望卷轴】x100，【1万法宝经验卷轴】x100，',4,1,1000,1,1,0),(790,'【三区水帘洞助力包】','打开后可获得【幻想套装】【vip练级卷】x20，【10亿修炼经验丹】x10，【万能果】x100，【1万西游声望卷轴】x100，【1万法宝经验卷轴】x100，〖瞌睡虫〗（典藏版）x5（全服赠送）',4,1,1000,1,1,0),(791,'〖圣贤宝石包〗（1个）','打开后获得〖圣贤宝石〗x1',4,1,1000,1,1,1),(792,'〖圣贤宝石包〗（3个）','打开后获得〖圣贤宝石〗x3',4,1,1000,1,1,1),(793,'〖圣贤宝石包〗（8个）','打开后获得〖圣贤宝石〗x8',4,1,1000,1,1,1),(794,'〖圣贤宝石包〗（30个）','打开后获得〖圣贤宝石〗x30',4,1,1000,1,1,1),(795,'〖极品7位ID号（11111111）靓号卡〗','使用后ID变更为11111111，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(796,'〖极品7位ID号（2222222）靓号卡〗','使用后ID变更为2222222，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(797,'〖极品7位ID号（3333333）靓号卡〗','使用后ID变更为3333333，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(798,'〖极品7位ID号（4444444）靓号卡〗','使用后ID变更为4444444，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(799,'〖极品7位ID号（5555555）靓号卡〗','使用后ID变更为5555555，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(800,'〖极品7位ID号（6666666）靓号卡〗','使用后ID变更为6666666，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(801,'〖极品7位ID号（7777777）靓号卡〗','使用后ID变更为7777777，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(802,'〖极品7位ID号（8888888）靓号卡〗','使用后ID变更为8888888，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(803,'〖极品7位ID号（9999999）靓号卡〗','使用后ID变更为9999999，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(804,'〖极品7位ID号（1234567）靓号卡〗','使用后ID变更为1234567，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(805,'〖极品7位ID号（1314520）靓号卡〗','使用后ID变更为1314520，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(806,'〖极品7位ID号（5201314）靓号卡〗','使用后ID变更为5201314，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(807,'〖极品7位ID号（5203344）靓号卡〗','使用后ID变更为5203344，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(808,'〖皇者宝石包〗（1个）','打开后获得〖皇者宝石〗x1',4,1,1000,1,1,1),(809,'〖皇者宝石包〗（3个）','打开后获得〖皇者宝石〗x3',4,1,1000,1,1,1),(810,'〖皇者宝石包〗（8个）','打开后获得〖皇者宝石〗x8',4,1,1000,1,1,1),(811,'〖皇者宝石包〗（30个）','打开后获得〖皇者宝石〗x30',4,1,1000,1,1,1),(812,'〖铁魂材料包〗','打开后获得〖铁魂〗x100',4,10,1000,1,1,1),(813,'〖铜魂材料包〗','打开后获得〖铜魂〗x100',4,20,1000,1,1,1),(814,'〖银魂材料包〗','打开后获得〖银魂〗x100',4,50,1000,1,1,1),(815,'〖金魂材料包〗','打开后获得〖金魂〗x100',4,100,1000,1,1,1),(816,'〖钻魂材料包〗','打开后获得〖钻魂〗x100',4,150,1000,1,1,1),(817,'〖陨魂材料包〗','打开后获得〖陨魂〗x100',4,200,1000,1,1,1),(818,'〖时装碎片〗','〖时装碎片〗制作时装必备材料',2,20,1000,1,1,1),(819,'〖时装契约〗','〖时装契约〗制作时装必备材料',2,20,1000,1,1,1),(820,'〖时装凭证〗','〖时装凭证〗制作时装的证书',4,20,1000,1,1,1),(821,'〖云梯石〗','〖云梯石〗可用于娱乐爬楼的宝贝',4,10,1000,1,1,1),(822,'〖如意の称号宝箱〗','〖如意の称号宝箱〗各类称号屌丝的逆袭，王者的荣耀（同等的几率开出各类称号）',8,10,1000,1,1,1),(823,'〖仙の陨魂〗','〖仙の陨魂〗能提升仙陨以上装备星级材料',2,10,1000,1,1,1),(824,'〖仙の陨升星符〗','〖仙の陨升星符〗百分之百将仙陨以上装备星级提升成功',4,1000,1000,1,1,1),(825,'【圣星の永生】','放入星盘大阵后HP提升700000',4,20,1000,1,1,0),(826,'【圣星の混沌】','放入星盘大阵后防御提升600000',4,20,1000,1,1,0),(827,'【圣星の秩序】','放入星盘大阵后攻击提升600000',4,20,1000,1,1,0),(828,'【圣星の圣恩】','放入星盘大阵后魔攻提升600000',4,20,1000,1,1,0),(829,'【圣星の元素之王】（攻）','放入星盘大阵后冰火雷攻+30',4,20,1000,1,1,0),(830,'【圣星の元素之王】（防）','放入星盘大阵后冰火雷防+30',4,20,1000,1,1,0),(831,'【五星红旗】','可在爱国富商处进行升旗用（每日领取一次）',6,20,1000,1,1,0),(832,'【欢】','凑齐一定数量欢迎公测可兑换【公测宝箱】',2,20,1000,1,1,0),(833,'【庆】','凑齐一定数量欢迎公测可兑换【公测宝箱】',2,20,1000,1,1,0),(834,'【公】','凑齐一定数量欢迎公测可兑换【公测宝箱】】',2,20,1000,1,1,0),(835,'【测】','凑齐一定数量欢迎公测可兑换【公测宝箱】',2,20,1000,1,1,0),(836,'〖国庆万能字〗','可在国庆期间使用转换任意字',6,20,1000,1,1,1),(837,'【国庆金铲】','可用于国庆挖宝',6,20,1000,1,1,0),(838,'【金铲】','可用于国庆挖宝',6,20,1000,1,1,0),(839,'【至尊铲】','可用于国庆挖宝',6,20,1000,1,1,0),(840,'〖国庆藏宝图〗（银图）','配合对应的铲子进行挖宝',6,20,1000,1,1,1),(841,'〖国庆藏宝图〗（金图）','配合对应的铲子进行挖宝',6,20,1000,1,1,1),(842,'〖国庆藏宝图〗（至尊图）','配合对应的铲子进行挖宝',6,20,1000,1,1,1),(843,'【国庆金锤】','可用于国庆敲金蛋活动',6,20,1000,1,1,0),(844,'〖国庆宝箱〗','可开出价值不菲的宝藏',8,20,1000,1,1,1),(845,'〖国庆愉快卡〗','可在国庆大使处提交用于国庆活动期间抢榜',6,20,1000,1,1,0),(846,'〖凤凰圣祖〗（宠物蛋）','〖凤凰圣祖〗绝版宠物，威力十分惊人',4,1,1000,1,1,1),(847,'〖凤凰圣祖〗（宠物蛋-万里挑一）','被小轩GM调教好了的宠物，必出五级变异圣品〖凤凰圣祖〗绝版宠物，威力十分惊人',4,1,1000,1,1,1),(848,'〖国庆充值10元消费礼宝箱〗','在2018.10.1-2018.10.7回馈充值赠送宝箱',8,1,1000,1,1,1),(849,'〖国庆充值20元消费礼宝箱〗','在2018.10.1-2018.10.7回馈充值赠送宝箱',8,1,1000,1,1,1),(850,'〖国庆充值50元消费礼宝箱〗','在2018.10.1-2018.10.7回馈充值赠送宝箱',8,1,1000,1,1,1),(851,'〖国庆充值100元消费礼宝箱〗','在2018.10.1-2018.10.7回馈充值赠送宝箱',8,1,1000,1,1,1),(852,'〖国庆充值200元消费礼宝箱〗','在2018.10.1-2018.10.7回馈充值赠送宝箱',8,1,1000,1,1,1),(853,'〖国庆充值500元消费礼宝箱〗','在2018.10.1-2018.10.7回馈充值赠送宝箱',8,1,1000,1,1,1),(854,'〖国庆充值1000元消费礼宝箱〗','在2018.10.1-2018.10.7回馈充值赠送宝箱',8,1,1000,1,1,1),(855,'〖国庆充值2000元消费礼宝箱〗','在2018.10.1-2018.10.7回馈充值赠送宝箱',8,1,1000,1,1,1),(856,'〖至尊宝石包〗（1个）','打开后获得〖至尊宝石〗x1',4,1,1000,1,1,1),(857,'〖挂售扩容卷〗','使用后可增加背包容量500',4,5,1000,1,1,1),(858,'〖尊享VIP〗（月卡）','使用后实力可大幅度提升从此走向人生巅峰，30天月卡',4,5,1000,1,1,1),(859,'〖尊享VIP〗（季卡）','使用后实力可大幅度提升从此走向人生巅峰，90天季卡',4,5,1000,1,1,1),(860,'〖尊享VIP〗（半年卡）','使用后实力可大幅度提升从此走向人生巅峰，180天半年卡',4,5,1000,1,1,1),(861,'〖尊享VIP〗（至尊年卡）','使用后实力可大幅度提升从此走向人生巅峰，366天年卡',4,5,1000,1,1,1),(862,'【尊享VIP】（月卡）','使用后实力可大幅度提升从此走向人生巅峰，30天月卡',4,5,1000,1,1,0),(863,'〖采花花魁〗','每日采花大盗排名奖励获取可用于兑换【尊享VIP】（月卡）',4,5,1000,1,1,1),(864,'〖尊享VIP〗（天卡）','使用后实力可大幅度提升从此走向人生巅峰，1天卡',4,5,1000,1,1,1),(865,'【尊享VIP】（1天）','使用后实力可大幅度提升从此走向人生巅峰，1天卡',4,5,1000,1,1,0),(866,'【尊享VIP】（3天）','使用后实力可大幅度提升从此走向人生巅峰，3天卡',4,5,1000,1,1,0),(867,'【尊享VIP】（7天）','使用后实力可大幅度提升从此走向人生巅峰，7天卡',4,5,1000,1,1,0),(868,'〖鲜果蛋糕〗','食用后可永久提升500hp',5,5,1000,1,1,1),(869,'〖奶油蛋糕〗','食用后可永久提升700hp',5,5,1000,1,1,1),(870,'〖草莓蛋糕〗','食用后可永久提升900hp',5,5,1000,1,1,1),(871,'〖焦糖蛋糕〗','食用后可永久提升1200hp',5,5,1000,1,1,1),(872,'〖香椰子蛋糕〗','食用后可永久提升1500hp',5,5,1000,1,1,1),(873,'〖曲奇饼干〗','食用后可永久提升500攻击',5,5,1000,1,1,1),(874,'〖蛋卷饼干〗','食用后可永久提升700攻击',5,5,1000,1,1,1),(875,'〖夹心饼干〗','食用后可永久提升900攻击',5,5,1000,1,1,1),(876,'〖芝麻饼干〗','食用后可永久提升1200攻击',5,5,1000,1,1,1),(877,'〖杏仁饼干〗','食用后可永久提升1500攻击',5,5,1000,1,1,1),(878,'〖奶油面包〗','食用后可永久提升500魔攻',5,5,1000,1,1,1),(879,'〖奶香面包〗','食用后可永久提升700魔攻',5,5,1000,1,1,1),(880,'〖抹茶面包〗','食用后可永久提升900魔攻',5,5,1000,1,1,1),(881,'〖椰蓉面包〗','食用后可永久提升1200魔攻',5,5,1000,1,1,1),(882,'〖毛毛虫面包〗','食用后可永久提升1500魔攻',5,5,1000,1,1,1),(883,'〖酥圈巧克力〗','食用后可永久提升500防御',5,5,1000,1,1,1),(884,'〖浓夫巧克力〗','食用后可永久提升700防御',5,5,1000,1,1,1),(885,'〖米雪巧克力〗','食用后可永久提升900防御',5,5,1000,1,1,1),(886,'〖乐荷巧克力〗','食用后可永久提升1200防御',5,5,1000,1,1,1),(887,'〖香雪巧克力〗','食用后可永久提升1500防御',5,5,1000,1,1,1),(888,'〖麦乐堡蛋糕〗（血）','食用后可永久提升5000hp',5,5,1000,1,1,1),(889,'〖麦乐堡蛋糕〗（攻）','食用后可永久提升5000攻击',5,5,1000,1,1,1),(890,'〖麦乐堡蛋糕〗（魔）','食用后可永久提升5000魔攻',5,5,1000,1,1,1),(891,'〖麦乐堡蛋糕〗（防）','食用后可永久提升5000防御',5,5,1000,1,1,1),(892,'〖麦乐堡甜品箱〗','能开出各类蛋糕，饼干，面包，巧克力，【尊享VIP】（1-7天）（必得麦乐堡蛋糕）',8,5,1000,1,1,1),(893,'〖西游蛋糕〗','不能吃的哦，但是可用于积分抢榜',6,5,1000,1,1,1),(894,'〖鸟蛋〗','制作糕点的原材料',6,5,1000,1,1,1),(895,'〖奶油〗','制作糕点的原材料',6,5,1000,1,1,1),(896,'〖白糖〗','制作糕点的原材料',6,5,1000,1,1,1),(897,'〖牛奶〗','制作糕点的原材料',6,5,1000,1,1,1),(898,'〖面粉〗','制作糕点的原材料',6,5,1000,1,1,1),(899,'〖黄油〗','制作糕点的原材料',6,5,1000,1,1,1),(900,'〖小麦粉〗','制作糕点的原材料',6,5,1000,1,1,1),(901,'〖巧克力酱〗','制作糕点的原材料',6,5,1000,1,1,1),(902,'〖可可粉〗','制作糕点的原材料',6,5,1000,1,1,1),(903,'〖力娇酒〗','制作糕点的原材料',6,5,1000,1,1,1),(904,'〖原料购物票〗','可使用〖原料购物票〗购买你需要的原材料',6,5,1000,1,1,1),(905,'〖生日甜品礼盒〗','可使用半，周，年，庆，典，四字兑换',8,5,1000,1,1,1),(906,'〖半周岁10元消费礼宝箱〗','在2018.10.10-2018.10.16回馈充值赠送宝箱',8,1,1000,1,1,1),(907,'〖半周岁20元消费礼宝箱〗','在2018.10.10-2018.10.16回馈充值赠送宝箱',8,1,1000,1,1,1),(908,'〖半周岁50元消费礼宝箱〗','在2018.10.10-2018.10.16回馈充值赠送宝箱',8,1,1000,1,1,1),(909,'〖半周岁100元消费礼宝箱〗','在2018.10.10-2018.10.16回馈充值赠送宝箱',8,1,1000,1,1,1),(910,'〖半周岁200元消费礼宝箱〗','在2018.10.10-2018.10.16回馈充值赠送宝箱',8,1,1000,1,1,1),(911,'〖半周岁500元消费礼宝箱〗','在2018.10.10-2018.10.16回馈充值赠送宝箱',8,1,1000,1,1,1),(912,'〖半周岁1000元消费礼宝箱〗','在2018.10.10-2018.10.16回馈充值赠送宝箱',8,1,1000,1,1,1),(913,'〖半周岁2000元消费礼宝箱〗','在2018.10.10-2018.10.16回馈充值赠送宝箱',8,1,1000,1,1,1),(914,'〖绝世盟主〗（纪念版）','〖绝世盟主〗（纪念版）在2018.10.10-2018.10.16周年庆典获得,使用后可以永久增加HP1000000，攻击1000000，防御1000000，魔攻1000000',4,1,1000,1,1,1),(915,'〖绝世仙盟〗（纪念版）','〖绝世仙盟〗（纪念版）在2018.10.10-2018.10.16周年庆典获得,使用后可以永久增加HP800000，攻击800000，防御800000，魔攻800000',4,1,1000,1,1,1),(916,'〖君临王城の至尊王城〗（纪念版）','〖君临王城の至尊王城〗（纪念版）在2018.10.10-2018.10.16周年庆典获得,使用后可以永久增加HP500000，攻击500000，防御500000，魔攻500000',4,1,1000,1,1,1),(917,'〖八荒雷动の傲视群雄〗（纪念版）','〖八荒雷动の傲视群雄〗（纪念版）在2018.10.10-2018.10.16周年庆典获得,使用后可以永久增加HP500000，攻击500000，防御500000，魔攻500000',4,1,1000,1,1,1),(918,'〖天下无双の群雄霸主〗（纪念版）','〖天下无双の群雄霸主〗（纪念版）在2018.10.10-2018.10.16周年庆典获得,使用后可以永久增加HP400000，攻击400000，防御400000，魔攻400000',4,1,1000,1,1,1),(919,'〖火树银花の名士风流〗（纪念版）','〖火树银花の名士风流〗（纪念版）在2018.10.10-2018.10.16周年庆典获得,使用后可以永久增加HP300000，攻击300000，防御300000，魔攻300000',4,1,1000,1,1,1),(920,'〖万花迎春の国色天香〗（纪念版）','〖万花迎春の国色天香〗（纪念版）在2018.10.10-2018.10.16周年庆典获得,使用后可以永久增加HP200000，攻击200000，防御200000，魔攻200000',4,1,1000,1,1,1),(921,'〖勇者之王〗（纪念版）','〖勇者之王〗（纪念版）在2018.10.10-2018.10.16周年庆典获得,使用后可以永久增加HP500000，攻击200000，防御200000，魔攻200000',4,1,1000,1,1,1),(922,'〖庆〗','〖庆〗',2,1,1000,1,1,1),(923,'〖祝〗','〖祝〗',2,1,1000,1,1,1),(924,'〖新〗','〖新〗',2,1,1000,1,1,1),(925,'〖区〗','〖区〗',2,1,1000,1,1,1),(926,'〖新区红包〗','〖新区红包〗能开出丰富的奖励哦',4,1,1000,1,1,1),(927,'〖极品3位ID号（111）靓号卡〗','使用后ID变更为111，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(928,'〖极品3位ID号（222）靓号卡〗','使用后ID变更为222，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(929,'〖极品3位ID号（333）靓号卡〗','使用后ID变更为333，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(930,'〖极品3位ID号（444）靓号卡〗','使用后ID变更为444，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(931,'〖极品3位ID号（555）靓号卡〗','使用后ID变更为555，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(932,'〖极品3位ID号（666）靓号卡〗','使用后ID变更为666，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(933,'〖极品3位ID号（777）靓号卡〗','使用后ID变更为777，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(934,'〖极品3位ID号（888）靓号卡〗','使用后ID变更为888，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(935,'〖极品3位ID号（999）靓号卡〗','使用后ID变更为999，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(936,'〖极品3位ID号（123）靓号卡〗','使用后ID变更为123，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(937,'〖极品1位ID号（1）靓号卡〗','使用后ID变更为1，此区只能用一次唯一的专属靓号（如果已是靓号再次使用则原来的靓号会被替换掉）',4,10,1000,1,1,1),(938,'【伏羲阵图】','【伏羲阵图】用于伏羲大阵消耗使用',1,10,1000,1,1,0),(939,'〖帝王石〗','用于合成帝王宝石的宝贵材料',2,10,1000,1,1,1),(940,'〖帝王宝石包〗（1个）','打开后获得〖帝王宝石〗x1',4,1,1000,1,1,1),(941,'〖护身符〗','〖护身符〗用于伏羲大阵跳阵使用',4,1,1000,1,1,1),(942,'【黑沃土】','【黑沃土】重阳节活动产物用于施肥',6,1,1000,1,1,0),(943,'【仙玉露】','【仙玉露】重阳节活动产物用于施肥',6,1,1000,1,1,0),(944,'〖紫星币〗','〖紫星币〗比金豆还要珍贵的物品',4,1,1000,1,1,1),(945,'〖小公主の激素〗','〖小公主の激素〗用于催生植物的产品（提升1小时收获时间）',4,1,1000,1,1,1),(946,'【面粉】','【面粉】重阳节活动用于制作【重阳糕】',6,1,1000,1,1,0),(947,'【红枣】','【红枣】重阳节活动用于制作【重阳糕】',6,1,1000,1,1,0),(948,'【栗子】','【栗子】重阳节活动用于制作【重阳糕】',6,1,1000,1,1,0),(949,'【杏仁】','【杏仁】重阳节活动用于制作【重阳糕】',6,1,1000,1,1,0),(950,'〖小公主の材料票〗','〖小公主の材料票〗用于购买【杏仁】【栗子】【红枣】【面粉】【黑沃土】【仙玉露】',6,1,1000,1,1,1),(951,'〖小公主の仙竹〗','〖小公主の仙竹〗用于活动抢夺积分榜',6,1,1000,1,1,1),(952,'【重阳糕】','【重阳糕】用于兑换称号和〖小公主の激素〗',6,1,1000,1,1,0),(953,'〖小公主の仙竹〗','〖小公主の仙竹〗用于活动抢夺积分榜',6,1,1000,1,1,1),(954,'〖绝代芳华〗','〖绝代芳华〗使用后hp增加30万，攻击魔攻防御各20万',4,1,1000,1,1,1),(955,'〖君临天下の武道至尊〗','〖君临天下の武道至尊〗使用后hp增加150万，攻击魔攻防御各100万',4,1,1000,1,1,1),(956,'〖倾城佳人の艳冠天下〗','〖倾城佳人の艳冠天下〗使用后hp增加120万，攻击魔攻防御各80万',4,1,1000,1,1,1),(957,'〖风流倜傥の百战无双〗','〖风流倜傥の百战无双〗使用后hp增加100万，攻击魔攻防御各70万',4,1,1000,1,1,1),(958,'〖天下无双の群雄霸主〗','〖天下无双の群雄霸主〗使用后hp增加80万，攻击魔攻防御各50万',4,1,1000,1,1,1),(959,'〖君临王城の至尊皇者〗','〖君临王城の至尊皇者〗使用后hp增加100万，攻击魔攻防御各70万',4,1,1000,1,1,1),(960,'〖至尊无敌〗','〖至尊无敌〗使用后hp增加80万，攻击魔攻防御各50万',4,1,1000,1,1,1),(961,'〖妖火天尊〗','〖妖火天尊〗使用后hp增加50万，攻击魔攻防御各30万',4,1,1000,1,1,1),(962,'〖神乎其技〗','〖神乎其技〗使用后hp增加30万，攻击魔攻防御各15万',4,1,1000,1,1,1),(963,'〖灵机百变〗','〖灵机百变〗使用后hp增加30万，攻击魔攻防御各15万',4,1,1000,1,1,1),(964,'〖姐是白富美〗','〖姐是白富美〗使用后hp增加30万，攻击魔攻防御各15万',4,1,1000,1,1,1),(965,'〖帝王（GM版）套装〗','〖帝王GM版）套装〗打开后获得〖帝王（GM版）套装〗',4,1,1000,1,1,1),(966,'〖圣灵1级套装〗','〖圣灵1级套装〗打开后获得圣灵1级套装一套',4,1,1000,1,1,1),(967,'〖圣灵2级套装〗','〖圣灵2级套装〗打开后获得圣灵2级套装一套',4,1,1000,1,1,1),(968,'〖圣灵3级套装〗','〖圣灵3级套装〗打开后获得圣灵3级套装一套',4,1,1000,1,1,1),(969,'〖圣灵☯天元套装〗','〖圣灵☯天元套装〗打开后获得圣灵☯天元套装一套',4,1,1000,1,1,1),(970,'〖噬魂套装〗','〖噬魂套装〗打开后获得噬魂套装一套',4,1,1000,1,1,1),(971,'〖帝王套装〗','〖帝王套装〗打开后获得帝王套装一套',4,1,1000,1,1,1),(972,'〖比翼双飞〗（典藏套装）','〖比翼双飞〗打开后获得比翼双飞婚饰一套',4,1,1000,1,1,1),(973,'【伏羲仙丹】','使用后可解封仙20等级',6,1,1000,220,1,0),(974,'〖仙佑石〗','〖仙佑石〗升级人物200级装备材料',2,1,1000,1,1,1),(975,'〖仙晶砂〗','〖仙晶砂〗升级人物200级装备材料',2,1,1000,1,1,1),(976,'〖仙器魂〗','〖仙器魂〗升级人物200级装备材料',2,1,1000,1,1,1),(977,'〖神佑石〗','〖神佑石〗升级人物仙20级装备材料',2,1,1000,1,1,1),(978,'〖神晶砂〗','〖神晶砂〗升级人物仙20级装备材料',2,1,1000,1,1,1),(979,'〖神器魂〗','〖神器魂〗升级人物仙20级装备材料',2,1,1000,1,1,1),(980,'〖圣佑石〗','〖圣佑石〗升级人物仙30级装备材料',2,1,1000,1,1,1),(981,'〖圣晶砂〗','〖圣晶砂〗升级人物仙30级装备材料',2,1,1000,1,1,1),(982,'〖圣器魂〗','〖圣器魂〗升级人物仙30级装备材料',2,1,1000,1,1,1),(983,'〖混沌天佑石〗','〖混沌天佑石〗升级人物仙40级装备材料',2,1,1000,1,1,1),(984,'〖混沌天晶砂〗','〖混沌天晶砂〗升级人物仙40级装备材料',2,1,1000,1,1,1),(985,'〖混沌天器魂〗','〖混沌天器魂〗升级人物仙40级装备材料',2,1,1000,1,1,1),(986,'〖混沌神佑石〗','〖混沌神佑石〗升级人物仙50级装备材料',2,1,1000,1,1,1),(987,'〖混沌神晶砂〗','〖混沌神晶砂〗升级人物仙50级装备材料',2,1,1000,1,1,1),(988,'〖混沌神器魂〗','〖混沌神器魂〗升级人物仙50级装备材料',2,1,1000,1,1,1),(989,'〖混沌圣佑石〗','〖混沌圣佑石〗升级人物仙60级装备材料',2,1,1000,1,1,1),(990,'〖混沌圣晶砂〗','〖混沌圣晶砂〗升级人物仙60级装备材料',2,1,1000,1,1,1),(991,'〖混沌圣器魂〗','〖混沌圣器魂〗升级人物仙60级装备材料',2,1,1000,1,1,1),(992,'〖鸿蒙天佑石〗','〖鸿蒙天佑石〗升级人物仙70级装备材料',2,1,1000,1,1,1),(993,'〖鸿蒙天晶砂〗','〖鸿蒙天晶砂〗升级人物仙70级装备材料',2,1,1000,1,1,1),(994,'〖鸿蒙天器魂〗','〖鸿蒙天器魂〗升级人物仙70级装备材料',2,1,1000,1,1,1),(995,'〖鸿蒙神佑石〗','〖鸿蒙神佑石〗升级人物仙80级装备材料',2,1,1000,1,1,1),(996,'〖鸿蒙神晶砂〗','〖鸿蒙神晶砂〗升级人物仙80级装备材料',2,1,1000,1,1,1),(997,'〖鸿蒙神器魂〗','〖鸿蒙神器魂〗升级人物仙80级装备材料',2,1,1000,1,1,1),(998,'〖鸿蒙圣佑石〗','〖鸿蒙圣佑石〗升级人物仙90级装备材料',2,1,1000,1,1,1),(999,'〖鸿蒙圣晶砂〗','〖鸿蒙圣晶砂〗升级人物仙90级装备材料',2,1,1000,1,1,1),(1000,'〖鸿蒙圣器魂〗','〖鸿蒙圣器魂〗升级人物仙90级装备材料',2,1,1000,1,1,1),(1001,'〖鸿蒙天圣石〗','〖鸿蒙圣佑石〗升级人物仙90级装备材料',2,1,1000,1,1,1),(1002,'〖鸿蒙天圣砂〗','〖鸿蒙天圣砂〗升级人物仙90级装备材料',2,1,1000,1,1,1),(1003,'〖鸿蒙天圣魂〗','〖鸿蒙天圣魂〗升级人物仙90级装备材料',2,1,1000,1,1,1),(1004,'【万】','【万】万圣节节日多动字体',6,1,1000,1,1,0),(1005,'【圣】','【圣】万圣节节日多动字体',6,1,1000,1,1,0),(1006,'【节】','【节】万圣节节日多动字体',6,1,1000,1,1,0),(1007,'【快】','【快】万圣节节日多动字体',6,1,1000,1,1,0),(1008,'【乐】','【乐】万圣节节日多动字体',6,1,1000,1,1,0),(1009,'〖万圣节万能字〗','〖万圣节万能字〗任意兑换活动字体',6,1,1000,1,1,1),(1010,'〖神の陨魂〗','仙陨的装备升星材料！',2,9999,1000,1,1,1),(1011,'〖神の陨升星符〗','拥有这强大的力量的符咒，可将百分之百将仙陨的装备升星成功！',4,9999,1000,1,1,1),(1012,'〖棒棒糖〗','使用后HP上限增加500！',5,9999,1000,1,1,1),(1013,'〖杏仁糖〗','使用后HP上限增加800！',5,9999,1000,1,1,1),(1014,'〖米花糖〗','使用后HP上限增加1000！',5,9999,1000,1,1,1),(1015,'〖水果糖〗','使用后HP上限增加1300！',5,9999,1000,1,1,1),(1016,'〖棉花糖〗','使用后攻击增加500！',5,9999,1000,1,1,1),(1017,'〖牛皮糖〗','使用后攻击增加700！',5,9999,1000,1,1,1),(1018,'〖咖啡糖〗','使用后攻击增加900！',5,9999,1000,1,1,1),(1019,'〖可乐糖〗','使用后攻击增加1200！',5,9999,1000,1,1,1),(1020,'〖太妃糖〗','使用后魔攻增加500！',5,9999,1000,1,1,1),(1021,'〖胡桃糖〗','使用后魔攻增加700！',5,9999,1000,1,1,1),(1022,'〖南瓜糖〗','使用后魔攻增加900！',5,9999,1000,1,1,1),(1023,'〖榴莲糖〗','使用后魔攻增加1200！',5,9999,1000,1,1,1),(1024,'〖狮子糖〗','使用后防御增加500！',5,9999,1000,1,1,1),(1025,'〖绵羊糖〗','使用后防御增加700！',5,9999,1000,1,1,1),(1026,'〖大象糖〗','使用后防御增加900！',5,9999,1000,1,1,1),(1027,'〖老虎塘〗','使用后防御增加1200！',5,9999,1000,1,1,1),(1028,'〖甜蜜梅心棒〗','使用后HP增加5000！',5,9999,1000,1,1,1),(1029,'〖云朵棉花糖〗','使用后攻击增加5000！',5,9999,1000,1,1,1),(1030,'〖浪漫酒心糖〗','使用后魔攻增加5000！',5,9999,1000,1,1,1),(1031,'〖大白兔奶糖〗','使用后防御增加5000！',5,9999,1000,1,1,1),(1032,'〖万圣节精品糖果箱〗','能够开出万圣节各种活动糖果！',8,9999,1000,1,1,1),(1033,'〖万圣节极品糖果箱〗','能够开出万圣节各种活动糖果+限定糖果！',8,9999,1000,1,1,1),(1034,'〖千秋万载〗','使用后可提升属性HP+200万，攻击+200万，魔攻+200万，防御+200万！',4,9999,1000,1,1,1),(1035,'〖纵横三界づ王者风云〗','使用后可提升属性HP+140万，攻击+140万，魔攻+140万，防御+140万！',4,9999,1000,1,1,1),(1036,'〖天下第一盟〗','使用后可提升属性HP+100万，攻击+100万，魔攻+100万，防御+100万！',4,9999,1000,1,1,1),(1037,'〖天下第一盟主〗','使用后可提升属性HP+80万，攻击+80万，魔攻+80万，防御+80万！',4,9999,1000,1,1,1),(1038,'〖富甲一方〗','使用后可提升属性HP+80万，攻击+80万，魔攻+80万，防御+80万！',4,9999,1000,1,1,1),(1039,'〖至高无上〗','使用后可提升属性HP+50万，攻击+50万，魔攻+50万，防御+50万！',4,9999,1000,1,1,1),(1040,'〖哥是高富帅〗','使用后可提升属性HP+30万，攻击+30万，魔攻+30万，防御+30万！',4,9999,1000,1,1,1),(1041,'〖探宝之神〗','使用后可提升属性HP+30万，攻击+30万，魔攻+30万，防御+30万！',4,9999,1000,1,1,1),(1042,'〖仙境状元〗','使用后可提升属性HP+20万，攻击+20万，魔攻+20万，防御+20万！',4,9999,1000,1,1,1),(1043,'〖制胜斗者〗','使用后可提升属性HP+15万，攻击+15万，魔攻+15万，防御+15万！',4,9999,1000,1,1,1),(1044,'〖诛魔大神〗','使用后可提升属性HP+10万，攻击+10万，魔攻+10万，防御+10万！',4,9999,1000,1,1,1),(1045,'〖珠光宝气〗','使用后可提升属性HP+50万，攻击+50万，魔攻+50万，防御+50万！',4,9999,1000,1,1,1),(1046,'【万圣节捣蛋劵】','用于万圣节称号兑换',6,9999,1000,1,1,0),(1047,'〖南瓜宝箱〗','〖南瓜宝箱〗能开出价值不菲的物品',8,1,1000,1,1,1),(1048,'【177级升级卡】','使用后可获将等级变更为177级（注意请勿大于177等级使用否则也会变为177级）',4,20,1000,1,1,0),(1049,'【155级升级卡】','使用后可获将等级变更为155级（注意请勿大于155等级使用否则也会变为155级）',4,20,1000,1,1,0),(1050,'【160级升级卡】','使用后可获将等级变更为160级（注意请勿大于160等级使用否则也会变为160级）',4,20,1000,1,1,0),(1051,'【165级升级卡】','使用后可获将等级变更为165级（注意请勿大于165等级使用否则也会变为165级）',4,20,1000,1,1,0),(1052,'【170级升级卡】','使用后可获将等级变更为170级（注意请勿大于170等级使用否则也会变为170级）',4,20,1000,1,1,0),(1053,'【175级升级卡】','使用后可获将等级变更为175级（注意请勿大于175等级使用否则也会变为175级）',4,20,1000,1,1,0),(1054,'【180级升级卡】','使用后可获将等级变更为180级（注意请勿大于180等级使用否则也会变为180级）',4,20,1000,1,1,0),(1055,'【185级升级卡】','使用后可获将等级变更为185级（注意请勿大于185等级使用否则也会变为185级）',4,20,1000,1,1,0),(1056,'【190级升级卡】','使用后可获将等级变更为190级（注意请勿大于190等级使用否则也会变为190级）',4,20,1000,1,1,0),(1057,'【195级升级卡】','使用后可获将等级变更为195级（注意请勿大于195等级使用否则也会变为195级）',4,20,1000,1,1,0),(1058,'【199级升级卡】','使用后可获将等级变更为199级（注意请勿大于199等级使用否则也会变为199级）',4,20,1000,1,1,0),(1059,'【烤火鸡】','感恩节活动掉落【烤火鸡】',6,20,1000,1,1,0),(1060,'【南瓜饼】','感恩节活动掉落【南瓜饼】',6,20,1000,1,1,0),(1061,'【红莓酱】','感恩节活动掉落【红莓酱】',6,20,1000,1,1,0),(1062,'【天宫玉兰】','【天宫玉兰】',2,20,1000,1,1,0),(1063,'【天宫雪莲】','【天宫雪莲】',2,20,1000,1,1,0),(1064,'〖伏魔重置卡〗','〖伏魔重置卡〗',2,20,1000,1,1,1),(1065,'〖良品烤火鸡〗（血）','使用后HP上限增加500！',5,9999,1000,1,1,1),(1066,'〖上品烤火鸡〗（血）','使用后HP上限增加800！',5,9999,1000,1,1,1),(1067,'〖精品烤火鸡〗（血）','使用后HP上限增加1000！',5,9999,1000,1,1,1),(1068,'〖极品烤火鸡〗（血）','使用后HP上限增加1300！',5,9999,1000,1,1,1),(1069,'〖良品烤火鸡〗（攻）','使用后攻击增加500！',5,9999,1000,1,1,1),(1070,'〖上品烤火鸡〗（攻）','使用后攻击增加800！',5,9999,1000,1,1,1),(1071,'〖精品烤火鸡〗（攻）','使用后攻击增加1000！',5,9999,1000,1,1,1),(1072,'〖极品烤火鸡〗（攻）','使用后攻击增加1300！',5,9999,1000,1,1,1),(1073,'〖良品烤火鸡〗（魔）','使用后魔攻增加500！',5,9999,1000,1,1,1),(1074,'〖上品烤火鸡〗（魔）','使用后魔攻增加800！',5,9999,1000,1,1,1),(1075,'〖精品烤火鸡〗（魔）','使用后魔攻增加1000！',5,9999,1000,1,1,1),(1076,'〖极品烤火鸡〗（魔）','使用后魔攻增加1300！',5,9999,1000,1,1,1),(1077,'〖良品烤火鸡〗（防）','使用后御增增加500！',5,9999,1000,1,1,1),(1078,'〖上品烤火鸡〗（防）','使用后御增增加800！',5,9999,1000,1,1,1),(1079,'〖精品烤火鸡〗（防）','使用后御增增加1000！',5,9999,1000,1,1,1),(1080,'〖极品烤火鸡〗（防）','使用后防御增加1300！',5,9999,1000,1,1,1),(1081,'〖极品烤全羊〗（血）','使用后hp上限增加10000！',5,9999,1000,1,1,1),(1082,'〖极品烤全羊〗（攻）','使用后攻击增加8888！',5,9999,1000,1,1,1),(1083,'〖极品烤全羊〗（魔）','使用后魔攻增加8888！',5,9999,1000,1,1,1),(1084,'〖极品烤全羊〗（防）','使用后防御增加8888！',5,9999,1000,1,1,1),(1085,'〖感恩小羊礼包〗','打开后可烤火鸡和烤全羊！！美味~~',8,9999,1000,1,1,1),(1086,'〖感恩火鸡礼包〗','打开后可烤火鸡！！美味~~',8,9999,1000,1,1,1),(1087,'〖10至500元现金红包〗','打开可随机得到10元至500元不等的现金红包',4,9999,1000,1,1,1),(1088,'〖10至200元现金红包〗','打开可随机得到10元至200元不等的现金红包',4,9999,1000,1,1,1),(1089,'〖10至50元现金红包〗','打开可随机得到10元至50元不等的现金红包',4,9999,1000,1,1,1),(1090,'〖10元红包〗','赠送给游戏ID为10000001的小轩GM兑换现金',4,9999,1000,1,1,1),(1091,'〖20元红包〗','赠送给游戏ID为10000001的小轩GM兑换现金',4,9999,1000,1,1,1),(1092,'〖50元红包〗','赠送给游戏ID为10000001的小轩GM兑换现金',4,9999,1000,1,1,1),(1093,'〖100元红包〗','赠送给游戏ID为10000001的小轩GM兑换现金',4,9999,1000,1,1,1),(1094,'〖200元红包〗','赠送给游戏ID为10000001的小轩GM兑换现金',4,9999,1000,1,1,1),(1095,'〖300元红包〗','赠送给游戏ID为10000001的小轩GM兑换现金',4,9999,1000,1,1,1),(1096,'〖400元红包〗','赠送给游戏ID为10000001的小轩GM兑换现金',4,9999,1000,1,1,1),(1097,'〖500元红包〗','赠送给游戏ID为10000001的小轩GM兑换现金',4,9999,1000,1,1,1),(1098,'〖点石成金劵〗','〖点石成金劵〗可在玄武大街点石成金员传送进入矿山，遇到各路神仙能够获得更多的金矿石',4,9999,1000,1,1,1),(1099,'〖金矿石〗','〖金矿石〗可在玄武大街点石成金员换购金劵',4,9999,1000,1,1,1),(1101,'〖1金矿券〗','〖1金矿券〗可用于换取对应金额充值卡',4,1,1000,1,1,1),(1102,'〖5金矿券〗','〖5金矿券〗可用于换取对应金额充值卡',4,1,1000,1,1,1),(1103,'〖10金矿券〗','〖10金矿券〗可用于换取对应金额充值卡',4,1,1000,1,1,1),(1104,'〖20金矿券〗','〖20金矿券〗可用于换取对应金额充值卡',4,1,1000,1,1,1),(1105,'〖50金矿券〗','〖50金矿券〗可用于换取对应金额充值卡',4,1,1000,1,1,1),(1106,'〖100金矿券〗','〖100金矿券〗可用于换取对应金额充值卡',4,1,1000,1,1,1),(1107,'无名仙法','酒剑侠留下的功法秘籍',1,2,1000,1,1,1),(1108,'秦家霸王枪','将军府专用功法秘籍',1,2,1000,1,1,1),(1109,'金刚砂','升级炼妖壶神器所需物品',2,0,1000,1,1,1),(1110,'黄铁矿石','升级神器炼妖壶所需物品',2,0,1000,1,1,1),(1111,'剑柄碎片','升级神器轩辕剑所需物品',2,0,1000,1,1,1),(1112,'玄铁矿石','升级神器轩辕剑所需物品',2,0,1000,1,1,1),(1113,'昆仑神木','升级昆仑镜神器所需物品',2,0,1000,1,1,1),(1114,'神秘矿石','升级昆仑镜神器所需物品',2,0,1000,1,1,1),(1115,'【精炼的玄铁】','神器升星阶时所需的通用物品',2,100,1000,1,1,0),(1116,'〖伏魔币〗','兑换伏魔塔物品的货币',4,1,1000,1,1,0),(1117,'堕落的魔心','兑换伏魔塔装备套装的重要物品',2,1,1000,1,1,0),(1118,'@css01@【龙吟苍穹の首饰套装】@css@','开启就能获得属性超强的首饰神装！',4,1,1000,1,1,0),(1119,'【筑基金丹】','突破筑基期必需要的物品',2,1,1000,1,1,0),(1120,'【金丹金丹】','突破金丹期必需要的物品',2,1,1000,1,1,0),(1121,'【元婴金丹】','突破元婴期必需要的物品',2,1,1000,1,1,0),(1122,'【化神金丹】','突破化神期必需要的物品',2,1,1000,1,1,0),(1123,'【炼虚金丹】','突破炼虚期必需要的物品',2,1,1000,1,1,0),(1124,'【合体金丹】','突破合体期必需要的物品',2,1,1000,1,1,0),(1125,'【大乘金丹】','突破大乘期必需要的物品',2,1,1000,1,1,0),(1126,'【真仙仙丹】','突破真仙期必需要的物品',2,1,1000,1,1,0),(1127,'【金仙仙丹】','突破金仙期必需要的物品',2,1,1000,1,1,0),(1128,'【太乙仙丹】','突破太乙期必需要的物品',2,1,1000,1,1,0),(1129,'【大罗仙丹】','突破大罗期必需要的物品',2,1,1000,1,1,0),(1130,'【道祖仙丹】','突破道祖期必需要的物品',2,1,1000,1,1,0),(1131,'【虚神仙丹】','突破虚神期必需要的物品',2,1,1000,1,1,0),(1132,'【真神仙丹】','突破真神期必需要的物品',2,1,1000,1,1,0),(1133,'【神王仙丹】','突破神王期必需要的物品',2,1,1000,1,1,0),(1134,'【祖神仙丹】','突破神神期必需要的物品',2,1,1000,1,1,0),(1135,'〖洪荒圣佑石〗','升级洪荒苍穹装备时需要的物品',2,2,1000,1,1,1),(1136,'〖洪荒圣晶砂〗','升级洪荒苍穹装备时需要的物品',2,2,1000,1,1,1),(1137,'〖洪荒圣器魂〗','升级洪荒苍穹装备时需要的物品',2,2,1000,1,1,1),(1138,'〖幸运转盘币〗','幸运大转盘中启动转盘时所需物品',4,1,1000,1,1,1),(1139,'〖神威圣佑石〗','升级霸气神威装备时需要的物品',2,2,1000,1,1,1),(1140,'〖神威圣晶砂〗','升级霸气神威装备时需要的物品',2,2,1000,1,1,1),(1141,'〖神威圣器魂〗','升级霸气神威装备时需要的物品',2,2,1000,1,1,1),(1142,'〖神威材料包〗','能开出升级霸气神威装备时需要的材料',4,2,1000,1,1,1),(1143,'〖洪荒苍穹材料包〗','能开出升级洪荒苍穹时需要的材料',4,2,1000,1,1,1),(1144,'〖首饰披风材料包〗','能开出升级首饰与披风时需要的材料',4,2,1000,1,1,1),(1145,'〖情义之圣晶〗','升级戒指与手链装备时需要的物品',2,2,1000,1,1,1),(1146,'〖威武之披风〗','升级披风装备时需要的物品',2,2,1000,1,1,1),(1147,'九彩铃兰','提炼丹药时需要的物品材料',2,2,1000,1,1,1),(1148,'冰葵','提炼丹药时需要的物品材料',2,2,1000,1,1,1),(1149,'魂婴果','提炼丹药时需要的物品材料',2,2,1000,1,1,1),(1150,'蚀心菇','提炼丹药时需要的物品材料',2,2,1000,1,1,1),(1151,'地脉龙晶','提炼丹药时需要的物品材料',2,2,1000,1,1,1),(1152,'〖龙鸣之圣晶〗','升级戒指与手链装备时需要的物品',2,2,1000,1,1,1),(1153,'〖超级转盘币〗','超级转盘中启动转盘时所需物品',4,1,1000,1,1,1),(1154,'@css03@【精品 · 烈焰战马】@css@','拥有火焰般的鬃毛和尾巴，皮肤深红，仿佛岩浆流淌',4,1,1000,1,1,1),(1155,'@css05@【极品 • 烈焰凤凰】@css@','羽毛火红华丽，体型优雅，翅膀展开时壮观无比',4,1,1000,1,1,1),(1156,'〖鸿蒙宝石包〗（10）','能开出鸿蒙宝石10个',4,2,1000,1,1,1),(1157,'〖混沌装备材料包〗','能开出升级混沌装备时需要的材料',4,2,1000,1,1,1),(1158,'〖鸿蒙装备材料包〗','能开出升级鸿蒙装备时需要的材料',4,2,1000,1,1,1),(1159,'@css04@【精锐 • 灵虎先锋】@css@','拥有梅花般的鬃毛和尾巴，皮肤白色，仿佛猛虎',4,1,1000,1,1,1),(1160,'〖累计赞助100证明卷〗','〖累计赞助100证明卷〗',4,2,1000,1,1,1),(1161,'〖累计赞助300证明卷〗','〖累计赞助300证明卷〗',4,2,1000,1,1,1),(1162,'〖累计赞助500证明卷〗','〖累计赞助500证明卷〗',4,2,1000,1,1,1),(1163,'〖累计赞助1000证明卷〗','〖累计赞助1000证明卷〗',4,2,1000,1,1,1),(1164,'【坐骑升星符】','坐骑提升星级所用',4,500,1000,1,1,1),(1165,'@css01@【斗战神猪】@css@','使用后，坐骑将更换成【斗战神猪】@css@',4,2,1000,1,1,1),(1166,'@css03@【傲世凤凰】@css@','使用后，坐骑将更换成【傲世凤凰】@css@',4,2,1000,1,1,1),(1167,'@css04@【黄金圣象】@css@','使用后，坐骑将更换成【黄金圣象】@css@',4,2,1000,1,1,1),(1168,'@css06@【七彩天尊 - 玄武】@css@','使用后，坐骑将更换成【七彩天尊 - 玄武】@css@',4,2,1000,1,1,1),(1169,'@css06@【雷霆神兽 - 白虎】@css@','使用后，坐骑将更换成【雷霆神兽 - 白虎】@css@',4,2,1000,1,1,1),(1170,'【坐骑升级丹】','坐骑提升级时所用',2,100,1000,1,1,1),(1171,'【神职证明卡】','【神职证明卡】',2,100,1000,1,1,0),(1172,'【神职挑战令牌】','【神职挑战令牌】',2,100,1000,1,1,0),(1173,'【天将封神令】','【天将封神令】',2,100,1000,1,1,0),(1174,'【天神封神令】','【天神封神令】',2,100,1000,1,1,0),(1175,'【日月星君封神令】','【日月星君封神令】',2,100,1000,1,1,0),(1176,'【地魁星君封神令】','【地魁星君封神令】',2,100,1000,1,1,0),(1177,'【天魁星君封神令】','【天魁星君封神令】',2,100,1000,1,1,0),(1178,'【地煞星君封神令】','【地煞星君封神令】',2,100,1000,1,1,0),(1179,'【天煞星君封神令】','【天煞星君封神令】',2,100,1000,1,1,0),(1180,'【天罡星君封神令】','【天罡星君封神令】',2,100,1000,1,1,0),(1181,'【天机星君封神令】','【天机星君封神令】',2,100,1000,1,1,0),(1182,'【日游神君封神令】','【日游神君封神令】',2,100,1000,1,1,0),(1183,'【夜游神君封神令】','【夜游神君封神令】',2,100,1000,1,1,0),(1184,'【白马帝君封神令】','【白马帝君封神令】',2,100,1000,1,1,0),(1185,'【司命帝君封神令】','【司命帝君封神令】',2,100,1000,1,1,0),(1186,'【太乙上仙封神令】','【太乙上仙封神令】',2,100,1000,1,1,0),(1187,'【太乙金仙封神令】','【太乙金仙封神令】',2,100,1000,1,1,0),(1188,'【太白金仙封神令】','【太白金仙封神令】',2,100,1000,1,1,0),(1189,'@css06@【龙族娇傲 - 小白龙】@css@','使用后，坐骑将更换成【龙族娇傲 - 小白龙】@css@',4,2,1000,1,1,1),(1190,'@css08@【远古神兽 - 麒麟】@css@','使用后，坐骑将更换成【远古神兽 - 麒麟】@css@',4,2,1000,1,1,1),(1191,'@css06@【仙界异兽 - 月兔】@css@','使用后，获得宠物: @css06@【仙界异兽 - 月兔】@css@',4,2,1000,1,1,1),(1192,'@css08@【异界魔人 - 八跂神】@css@','使用后，获得宠物: @css08@【异界魔人 - 八跂神】@css@',4,2,1000,1,1,1),(1193,'@css06@【龙族神兽- 青龙】（宠物）@css@','使用后，获得宠物: @css06@【龙族神兽- 青龙】@css@',4,2,1000,1,1,1),(1194,'〖战力榜第一证明卷〗','〖战力榜第一证明卷〗',4,2,1000,1,1,1),(1195,'〖战力榜第二证明卷〗','〖战力榜第二证明卷〗',4,2,1000,1,1,1),(1196,'〖战力榜第三证明卷〗','〖战力榜第三证明卷〗',4,2,1000,1,1,1),(1197,'〖战力榜第四-十证明卷〗','〖战力榜第四-十证明卷〗',4,2,1000,1,1,1),(1198,'@css08@【远古神兽 - 雄狮】@css@','使用后，坐骑将更换成【远古神兽 - 雄狮】@css@',4,2,1000,1,1,1),(1199,'【祖王仙丹】','突破祖王期必需要的物品',2,1,1000,1,1,0),(1200,'【祖皇仙丹】','突破祖皇期必需要的物品',2,1,1000,1,1,0),(1201,'【祖帝仙丹】','突破祖帝期必需要的物品',2,1,1000,1,1,0),(1202,'【圣尊仙丹】','突破圣尊期必需要的物品',2,1,1000,1,1,0),(1203,'【仙尊仙丹】','突破仙尊期必需要的物品',2,1,1000,1,1,0),(1204,'【天帝仙丹】','突破天帝期必需要的物品',2,1,1000,1,1,0),(1205,'【如来佛仙丹】','突破如来佛期必需要的物品',2,1,1000,1,1,0),(1206,'【天宫东殿主封神令】','【天宫东殿主封神令】',2,100,1000,1,1,0),(1207,'【天宫西殿主封神令】','【天宫西殿主封神令】',2,100,1000,1,1,0),(1208,'【天宫南殿主封神令】','【天宫南殿主封神令】',2,100,1000,1,1,0),(1209,'【天宫北殿主封神令】','【天宫北殿主封神令】',2,100,1000,1,1,0),(1210,'【天宫神殿将军封神令】','【天宫神殿将军封神令】',2,100,1000,1,1,0),(1211,'【佛陀舍利子】','渡劫飞升时必需要的物品',2,1,1000,1,1,0),(1212,'【佛陀护心珠】','渡劫飞升时必需要的物品',2,1,1000,1,1,0),(1213,'【佛陀的降魔心】','渡劫飞升时必需要的物品',2,1,1000,1,1,0),(1214,'【开劈洞府证书】','【开劈洞府证书】',4,100000000,1000,1,1,0),(1215,'【洞府升级券】','【洞府升级券】',4,10000,1000,1,1,0),(1216,'【洞府装修打造券】','装修洞府时所需物品',4,1000000,1000,1,1,0);
/*!40000 ALTER TABLE `wpxx` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `xl`
--

DROP TABLE IF EXISTS `xl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `xl` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '编号id',
  `wjid` int(10) unsigned NOT NULL DEFAULT '0',
  `xlid` int(11) NOT NULL DEFAULT '0' COMMENT '修炼id',
  `xldj` int(11) NOT NULL DEFAULT '0' COMMENT '修炼等级',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `xl`
--

LOCK TABLES `xl` WRITE;
/*!40000 ALTER TABLE `xl` DISABLE KEYS */;
/*!40000 ALTER TABLE `xl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `xp`
--

DROP TABLE IF EXISTS `xp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `xp` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '编号id',
  `wjid` int(10) unsigned NOT NULL DEFAULT '0',
  `seq` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '星盘顺序编号',
  `xpid` int(11) NOT NULL DEFAULT '0' COMMENT '星盘id',
  `xpkq` int(11) NOT NULL DEFAULT '0' COMMENT '星盘开启',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `xp`
--

LOCK TABLES `xp` WRITE;
/*!40000 ALTER TABLE `xp` DISABLE KEYS */;
/*!40000 ALTER TABLE `xp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `xtbl`
--

DROP TABLE IF EXISTS `xtbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `xtbl` (
  `id` int(11) NOT NULL,
  `bl1` int(11) NOT NULL,
  `bl2` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `xtbl`
--

LOCK TABLES `xtbl` WRITE;
/*!40000 ALTER TABLE `xtbl` DISABLE KEYS */;
/*!40000 ALTER TABLE `xtbl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `xydfw`
--

DROP TABLE IF EXISTS `xydfw`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `xydfw` (
  `wjid` int(11) NOT NULL,
  `plcs` int(11) NOT NULL DEFAULT '1',
  `pl_time` int(11) NOT NULL,
  `pl_mfcz` int(11) NOT NULL,
  `pl_10` int(11) NOT NULL DEFAULT '0',
  `pl_20` int(11) NOT NULL DEFAULT '0',
  `pl_50` int(11) NOT NULL DEFAULT '0',
  `pl_60` int(11) NOT NULL,
  `pl_80` int(11) NOT NULL,
  `pl_100` int(11) NOT NULL,
  `pl_150` int(11) NOT NULL,
  `pl_200` int(11) NOT NULL,
  `pl_300` int(11) NOT NULL,
  `pl_400` int(11) NOT NULL,
  `pl_500` int(11) NOT NULL,
  `pl_600` int(11) NOT NULL,
  `pl_700` int(11) NOT NULL,
  `pl_800` int(11) NOT NULL,
  `pl_900` int(11) NOT NULL,
  `pl_1000` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `xydfw`
--

LOCK TABLES `xydfw` WRITE;
/*!40000 ALTER TABLE `xydfw` DISABLE KEYS */;
/*!40000 ALTER TABLE `xydfw` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `yxrw`
--

DROP TABLE IF EXISTS `yxrw`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `yxrw` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '编号ID',
  `wjid` int(10) unsigned NOT NULL DEFAULT '0',
  `rwid` int(11) NOT NULL DEFAULT '0' COMMENT '任务ID',
  `rwbl` int(11) NOT NULL DEFAULT '0' COMMENT '任务变量',
  `rwmz` text NOT NULL COMMENT '任务名字',
  `yisg` int(11) NOT NULL DEFAULT '0' COMMENT '已杀怪',
  `ysg` int(11) NOT NULL DEFAULT '0' COMMENT '要杀怪',
  `rwfl` int(11) NOT NULL DEFAULT '0' COMMENT '任务分类',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `yxrw`
--

LOCK TABLES `yxrw` WRITE;
/*!40000 ALTER TABLE `yxrw` DISABLE KEYS */;
/*!40000 ALTER TABLE `yxrw` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `zb`
--

DROP TABLE IF EXISTS `zb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `zb` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '编号ID',
  `wjid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '玩家ID',
  `zbid` int(11) NOT NULL DEFAULT '0' COMMENT '装备ID',
  `zbxj` int(11) NOT NULL DEFAULT '0' COMMENT '装备星级',
  `zbsj` int(11) NOT NULL DEFAULT '0',
  `zbk1` int(11) NOT NULL DEFAULT '0' COMMENT '装备孔1',
  `zbxq1` int(11) NOT NULL DEFAULT '0' COMMENT '镶嵌1',
  `zbk2` int(11) NOT NULL DEFAULT '0' COMMENT '装备孔2',
  `zbxq2` int(11) NOT NULL DEFAULT '0' COMMENT '镶嵌2',
  `zbk3` int(11) NOT NULL DEFAULT '0' COMMENT '装备孔3',
  `zbxq3` int(11) NOT NULL DEFAULT '0' COMMENT '镶嵌3',
  `zbk4` int(11) NOT NULL DEFAULT '0' COMMENT '装备孔4',
  `zbxq4` int(11) NOT NULL DEFAULT '0' COMMENT '镶嵌4',
  `zbk5` int(11) NOT NULL DEFAULT '0' COMMENT '装备孔5',
  `zbxq5` int(11) NOT NULL DEFAULT '0' COMMENT '镶嵌5',
  `zbpd` int(11) NOT NULL DEFAULT '0' COMMENT '装备佩戴',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='装备';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `zb`
--

LOCK TABLES `zb` WRITE;
/*!40000 ALTER TABLE `zb` DISABLE KEYS */;
/*!40000 ALTER TABLE `zb` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `zbb`
--

DROP TABLE IF EXISTS `zbb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `zbb` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '编号ID',
  `wjid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '玩家ID',
  `zbid` int(11) NOT NULL DEFAULT '0' COMMENT '装备ID',
  `zbxj` int(11) NOT NULL DEFAULT '0' COMMENT '装备星级',
  `zbsj` int(11) NOT NULL DEFAULT '0',
  `zbk1` int(11) NOT NULL DEFAULT '0' COMMENT '装备孔1',
  `zbxq1` int(11) NOT NULL DEFAULT '0' COMMENT '镶嵌1',
  `zbk2` int(11) NOT NULL DEFAULT '0' COMMENT '装备孔2',
  `zbxq2` int(11) NOT NULL DEFAULT '0' COMMENT '镶嵌2',
  `zbk3` int(11) NOT NULL DEFAULT '0' COMMENT '装备孔3',
  `zbxq3` int(11) NOT NULL DEFAULT '0' COMMENT '镶嵌3',
  `zbk4` int(11) NOT NULL DEFAULT '0' COMMENT '装备孔4',
  `zbxq4` int(11) NOT NULL DEFAULT '0' COMMENT '镶嵌4',
  `zbk5` int(11) NOT NULL DEFAULT '0' COMMENT '装备孔5',
  `zbxq5` int(11) NOT NULL DEFAULT '0' COMMENT '镶嵌5',
  `zbfl` int(11) NOT NULL DEFAULT '0' COMMENT '装备分类',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `zbb`
--

LOCK TABLES `zbb` WRITE;
/*!40000 ALTER TABLE `zbb` DISABLE KEYS */;
/*!40000 ALTER TABLE `zbb` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `zbxx`
--

DROP TABLE IF EXISTS `zbxx`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `zbxx` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '装备编号',
  `mz` varchar(100) NOT NULL DEFAULT '' COMMENT '名字',
  `ms` varchar(100) NOT NULL DEFAULT '' COMMENT '描述',
  `hp` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '血量',
  `gj` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '攻击',
  `mg` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '魔攻',
  `fy` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '防御',
  `bg` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '冰攻',
  `hg` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '火攻',
  `lg` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '雷攻',
  `bf` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '冰防',
  `hf` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '火防',
  `lf` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '雷防',
  `dj` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '等级',
  `zl` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '重量',
  `bd` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '是否绑定',
  `jd` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '金豆价格',
  `jg` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '价格',
  `pd` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '佩戴',
  `mp` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '门派',
  `fl` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '分类',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=866 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `zbxx`
--

LOCK TABLES `zbxx` WRITE;
/*!40000 ALTER TABLE `zbxx` DISABLE KEYS */;
INSERT INTO `zbxx` VALUES (1,'〖玄冰枪〗','破旧的玄冰枪',0,329,110,0,1,1,1,0,0,0,1,10,1,0,1000,0,1,3),(2,'〖仙魂枪〗','仙魂套装之--枪！',0,190,150,0,5,5,5,0,0,0,10,10,1,0,1000,0,1,3),(3,'【白虎枪】','白虎套装之--枪！！（拾取绑定）',0,268,157,0,8,8,8,0,0,0,60,10,0,0,1000,0,1,3),(4,'【白虎笑傲枪】','白虎笑傲套之枪！（拾取绑定）',0,983,479,0,15,15,15,0,0,0,65,10,0,0,1000,0,1,3),(5,'【玄武枪】','玄武套装之枪（拾取绑定）',0,1256,652,0,15,15,15,0,0,0,65,10,0,0,1000,0,1,3),(6,'【玄武撼地枪】','玄武撼地套装之枪！（拾取绑定）',0,1595,898,0,18,18,18,0,0,0,70,10,0,0,1000,0,1,3),(7,'【朱雀枪】','朱雀套装之枪（拾取绑定）',0,2395,1580,0,22,22,22,0,0,0,80,10,0,0,1000,0,1,3),(8,'【应龙戟】（40）','强大的师门神兵！',0,549,236,0,8,8,8,0,0,0,40,10,0,0,1000,0,1,3),(9,'【应龙戟】（60）','强大的师门神兵！',0,748,473,0,12,12,12,0,0,0,60,10,0,0,1000,0,1,3),(10,'【应龙戟】（80）','强大的师门神兵！',0,1398,795,0,15,15,15,0,0,0,80,10,0,0,1000,0,1,3),(11,'【应龙戟】（89）','强大的师门神兵！',0,2485,1350,0,18,18,18,0,0,0,89,10,0,0,1000,0,1,3),(12,'【应龙戟】（99）','强大的师门神兵！',0,3158,1735,0,20,20,20,0,0,0,99,10,0,0,1000,0,1,3),(13,'〖雷皇枪〗','雷皇套装之一',0,68,54,0,5,5,5,0,0,0,40,10,1,0,1000,0,1,3),(14,'【幻想枪】','幻想绝版套装之武器！（拾取绑定）',0,2235,1548,0,18,18,18,0,0,0,50,10,0,0,1000,0,1,3),(15,'〖玄冰叉〗','龙宫初级武器',0,19,0,0,1,1,1,0,0,0,1,10,1,0,1000,0,2,3),(16,'〖仙魂叉〗','仙魂套装之--叉！',0,150,190,0,5,5,5,0,0,0,10,10,1,0,1000,0,2,3),(17,'【龙鳞叉】','龙鳞套装之--叉！！（拾取绑定）',0,268,157,0,8,8,8,0,0,0,60,10,0,0,1000,0,2,3),(18,'【龙鳞破天叉】','龙鳞破天套之叉！（拾取绑定）',0,983,479,0,15,15,15,0,0,0,65,10,0,0,1000,0,2,3),(19,'【青龙叉】','青龙套装之叉（拾取绑定）',0,1256,652,0,15,15,15,0,0,0,65,10,0,0,1000,0,2,3),(20,'【青龙在天叉】','青龙在天套装之叉！（拾取绑定）',0,1595,898,0,18,18,18,0,0,0,70,10,0,0,1000,0,2,3),(21,'【天龙叉】','天龙套装之叉（拾取绑定）',0,2395,1580,0,22,22,22,0,0,0,80,10,0,0,1000,0,2,3),(22,'【五龙叉】（40）','强大的师门神兵！',0,549,236,0,8,8,8,0,0,0,40,10,0,0,1000,0,2,3),(23,'【五龙叉】（60）','强大的师门神兵！',0,748,473,0,12,12,12,0,0,0,60,10,0,0,1000,0,2,3),(24,'【五龙叉】（80）','强大的师门神兵！',0,1398,795,0,15,15,15,0,0,0,80,10,0,0,1000,0,2,3),(25,'【五龙叉】（89）','强大的师门神兵！',0,2485,1350,0,18,18,18,0,0,0,89,10,0,0,1000,0,2,3),(26,'【五龙叉】（99）','强大的师门神兵！',0,3158,1735,0,20,20,20,0,0,0,99,10,0,0,1000,0,2,3),(27,'〖雷皇叉〗','雷皇套装之一',0,68,54,0,5,5,5,0,0,0,40,10,1,0,1000,0,2,2),(28,'【幻想叉】','幻想绝版套装之武器！（拾取绑定）',0,2235,1548,0,18,18,18,0,0,0,50,10,0,0,1000,0,2,3),(29,'〖玄冰棍〗','方寸山初级武器',0,19,0,0,1,1,1,0,0,0,1,10,1,0,1000,0,4,3),(30,'〖仙魂棍〗','仙魂套装之--棍',0,190,150,0,5,5,5,0,0,0,10,10,1,0,1000,0,4,3),(31,'【七星棍】','七星套装之--棍！！（拾取绑定）',0,268,157,0,8,8,8,0,0,0,60,10,0,0,1000,0,4,3),(32,'【七星逐月棍】','七星逐月套之棍！（拾取绑定）',0,983,479,0,15,15,15,0,0,0,65,10,0,0,1000,0,4,3),(33,'【无极棍】','无极套装之棍（拾取绑定）',0,1256,652,0,15,15,15,0,0,0,65,10,0,0,1000,0,4,3),(34,'【无极无道棍】','无极无道套装之棍！（拾取绑定）',0,1595,898,0,18,18,18,0,0,0,70,10,0,0,1000,0,4,3),(35,'【太乙棍】','太乙套装之棍（拾取绑定）',0,2395,1580,0,22,22,22,0,0,0,80,10,0,0,1000,0,4,3),(36,'【夸父棍】（40）','强大的师门神兵！',0,549,236,0,8,8,8,0,0,0,40,10,0,0,1000,0,4,3),(37,'【夸父棍】（60）','强大的师门神兵！',0,748,473,0,8,8,8,0,0,0,60,10,0,0,1000,0,4,3),(38,'【夸父棍】（80）','强大的师门神兵！',0,1398,795,0,15,15,15,0,0,0,80,10,0,0,1000,0,4,3),(39,'【夸父棍】（89）','强大的师门神兵！',0,2485,1350,0,18,18,18,0,0,0,89,10,0,0,1000,0,4,3),(40,'【夸父棍】（99）','强大的师门神兵！',0,3158,1735,0,20,20,20,0,0,0,99,10,0,0,1000,0,4,3),(41,'〖雷皇棍〗','雷皇套装之一',0,68,54,0,5,5,5,0,0,0,40,10,1,0,1000,0,4,3),(42,'【幻想棍】','幻想绝版套装之武器！（拾取绑定）',0,2235,1548,0,18,18,18,0,0,0,50,10,0,0,1000,0,4,3),(43,'〖玄冰杖〗','普陀山初级武器',0,0,19,0,1,1,1,0,0,0,1,10,1,0,1000,0,5,3),(44,'〖仙魂仗〗','仙魂套装之--仗！',0,190,150,0,5,5,5,0,0,0,10,10,1,0,1000,0,5,3),(45,'【伏虎杖】','伏虎套装之--杖！！（拾取绑定）',0,157,268,0,8,8,8,0,0,0,60,10,0,0,1000,0,5,3),(46,'【伏虎降龙杖】','伏虎降龙套之杖！（拾取绑定）',0,983,479,0,15,15,15,0,0,0,65,10,0,0,1000,0,5,3),(47,'【金刚杖】','金刚套装之杖（拾取绑定）',0,1256,652,0,15,15,15,0,0,0,65,10,0,0,1000,0,5,3),(48,'【怒目金刚杖】','怒目金刚套装之杖！（拾取绑定）',0,1595,898,0,18,18,18,0,0,0,70,10,0,0,1000,0,5,3),(49,'【罗汉杖】','罗汉套装之杖（拾取绑定）',0,2395,1580,0,22,22,22,0,0,0,80,10,0,0,1000,0,5,3),(50,'【般若杖】（40）','强大的师门神兵！',0,236,549,0,8,8,8,0,0,0,40,10,0,0,1000,0,5,3),(51,'【般若杖】（60）','强大的师门神兵！',0,748,473,0,12,12,12,0,0,0,60,10,0,0,1000,0,5,3),(52,'【般若杖】（80）','强大的师门神兵！',0,1398,795,0,15,15,15,0,0,0,80,10,0,0,1000,0,5,3),(53,'【般若杖】（89）','强大的师门神兵！',0,2485,1350,0,18,18,18,0,0,0,89,10,0,0,1000,0,5,3),(54,'【般若杖】（99）','强大的师门神兵！',0,3158,1735,0,20,20,20,0,0,0,99,10,0,0,1000,0,5,3),(55,'〖雷皇杖〗','雷皇套装之一',0,54,68,0,5,5,5,0,0,0,40,10,1,0,1000,0,5,3),(56,'【幻想杖】','幻想绝版套装之武器！（拾取绑定）',0,1548,2235,0,18,18,18,0,0,0,50,10,0,0,1000,0,5,3),(57,'〖玄冰剑〗','月宫初级武器',0,0,19,0,1,1,1,0,0,0,1,10,1,0,1000,0,3,3),(58,'〖仙魂剑〗','仙魂套装之--剑！',0,150,190,0,5,5,5,0,0,0,10,10,1,0,1000,0,3,3),(59,'【碧海剑】','碧海套装之--剑！！（拾取绑定）',0,157,268,0,8,8,8,0,0,0,60,10,0,0,1000,0,3,3),(60,'【碧海青天剑】','碧海青天套之剑！（拾取绑定）',0,479,983,0,15,15,15,0,0,0,65,10,0,0,1000,0,3,3),(61,'【银沙剑】','银沙套装之剑（拾取绑定）',0,652,1256,0,15,15,15,0,0,0,65,10,0,0,1000,0,3,3),(62,'【银沙瀚海剑】','银沙瀚海套装之剑！（拾取绑定）',0,898,1595,0,18,18,18,0,0,0,70,10,0,0,1000,0,3,3),(63,'【奔月剑】','奔月套装之剑（拾取绑定）',0,1580,2395,0,22,22,22,0,0,0,80,10,0,0,1000,0,3,3),(64,'【碧落剑】（40）','强大的师门神兵！',0,236,549,0,8,8,8,0,0,0,40,10,0,0,1000,0,3,3),(65,'【碧落剑】（60）','强大的师门神兵！',0,473,748,0,12,12,12,0,0,0,60,10,0,0,1000,0,3,3),(66,'【碧落剑】（80）','强大的师门神兵！',0,795,1398,0,15,15,15,0,0,0,80,10,0,0,1000,0,3,3),(67,'【碧落剑】（89）','强大的师门神兵！',0,1350,2485,0,18,18,18,0,0,0,89,10,0,0,1000,0,3,3),(68,'【碧落剑】（99）','强大的师门神兵！',0,1735,3158,0,20,20,20,0,0,0,99,10,0,0,1000,0,3,3),(69,'〖雷皇剑〗','雷皇套装之一',0,54,68,0,5,5,5,0,0,0,40,10,1,0,1000,0,3,3),(70,'【幻想剑】','幻想绝版套装之武器！（拾取绑定）',0,1548,2235,0,18,18,18,0,0,0,50,10,0,0,1000,0,3,3),(71,'〖玄冰战甲〗','初级战甲',0,0,0,15,0,0,0,1,1,1,1,10,1,0,1000,0,6,4),(72,'〖仙魂战甲〗','仙魂套装之--战甲！',0,0,0,222,0,0,0,4,4,4,10,10,1,0,1000,0,6,4),(73,'【白虎盔甲】','白虎套装之甲！（拾取绑定）',0,0,0,438,0,0,0,5,5,5,60,10,0,0,1000,0,1,4),(74,'【七星盔甲】','七星套装之甲！（拾取绑定）',0,0,0,438,0,0,0,5,5,5,60,10,0,0,1000,0,4,4),(75,'【龙鳞盔甲】','龙鳞套装之甲！（拾取绑定）',0,0,0,438,0,0,0,5,5,5,60,10,0,0,1000,0,2,4),(76,'【伏虎盔甲】','伏虎套装之甲！（拾取绑定）',0,0,0,438,0,0,0,5,5,5,60,10,0,0,1000,0,5,4),(77,'【碧海盔甲】','碧海套装之甲！（拾取绑定）',0,0,0,438,0,0,0,5,5,5,60,10,0,0,1000,0,3,4),(78,'【白虎笑傲铠】','白虎笑傲套之甲！（拾取绑定）',0,0,0,547,0,0,0,5,5,5,65,10,0,0,1000,0,1,4),(79,'【七星逐月铠】','七星逐月套之甲！（拾取绑定）',0,0,0,547,0,0,0,5,5,5,65,10,0,0,1000,0,4,4),(80,'【龙鳞破天铠】','龙鳞破天套之甲！（拾取绑定）',0,0,0,547,0,0,0,5,5,5,65,10,0,0,1000,0,2,4),(81,'【伏虎降龙铠】','伏虎降龙套之甲！（拾取绑定）',0,0,0,547,0,0,0,5,5,5,65,10,0,0,1000,0,5,4),(82,'【碧海青天铠】','碧海青天套之甲！（拾取绑定）',0,0,0,547,0,0,0,5,5,5,65,10,0,0,1000,0,3,4),(83,'【玄武铠甲】','玄武套装之甲！（拾取绑定）',0,0,0,786,0,0,0,8,8,8,65,10,0,0,1000,0,1,4),(84,'【无极铠甲】','无极套装之甲！（拾取绑定）',0,0,0,786,0,0,0,8,8,8,65,10,0,0,1000,0,4,4),(85,'【青龙铠甲】','青龙套装之甲！（拾取绑定）',0,0,0,786,0,0,0,8,8,8,65,10,0,0,1000,0,2,4),(86,'【金刚铠甲】','金刚套装之甲！（拾取绑定）',0,0,0,786,0,0,0,8,8,8,65,10,0,0,1000,0,5,4),(87,'【银沙铠甲】','银沙套装之甲！（拾取绑定）',0,0,0,786,0,0,0,8,8,8,65,10,0,0,1000,0,3,4),(88,'【玄武撼地甲】','玄武撼地套装之枪！（拾取绑定）',0,0,0,786,0,0,0,10,10,10,70,10,0,0,1000,0,1,4),(89,'【无极无道甲】','无极无道套装之甲！（拾取绑定）',0,0,0,1350,0,0,0,10,10,10,70,10,0,0,1000,0,4,4),(90,'【青龙在天甲】','青龙在天套装之甲！（拾取绑定）',0,0,0,1350,0,0,0,10,10,10,70,10,0,0,1000,0,2,4),(91,'【怒目金刚甲】','怒目金刚套装之甲！（拾取绑定）',0,0,0,1350,0,0,0,10,10,10,70,10,0,0,1000,0,5,4),(92,'【银沙瀚海甲】','银沙瀚海套装之甲！（拾取绑定）',0,0,0,1350,0,0,0,10,10,10,70,10,0,0,1000,0,3,4),(93,'【朱雀战甲】','朱雀套装之战甲！（拾取绑定）',0,0,0,786,0,0,0,18,18,18,80,10,0,0,1000,0,1,4),(94,'【太乙战甲】','太乙套装之战甲！（拾取绑定）',0,0,0,1350,0,0,0,18,18,18,80,10,0,0,1000,0,4,4),(95,'【天龙战甲】','天龙套装之战甲！（拾取绑定）',0,0,0,1350,0,0,0,18,18,18,80,10,0,0,1000,0,2,4),(96,'【罗汉战甲】','罗汉套装之战甲！（拾取绑定）',0,0,0,1350,0,0,0,18,18,18,80,10,0,0,1000,0,5,4),(97,'【奔月战甲】','奔月套装之战甲！（拾取绑定）',0,0,0,1350,0,0,0,18,18,18,80,10,0,0,1000,0,3,4),(98,'〖刑天铁甲〗','战神刑天用过的战甲！(可在长安装备锻造商处进行升级)',0,0,0,953,0,0,0,8,8,8,60,10,1,0,1000,0,6,4),(99,'【巨灵宝甲】','传说中的大巨灵装备，你值得拥有！（拾取绑定）',0,0,0,2765,0,0,0,25,25,25,109,10,0,0,1000,0,6,4),(100,'〖雷皇战衣〗','雷皇套装之一',0,0,0,186,0,0,0,3,3,3,40,10,1,0,1000,0,6,4),(101,'【幻想战甲】','幻想绝版套装之战甲！（拾取绑定）',0,0,0,2985,0,0,0,15,15,15,50,10,0,0,1000,0,6,4),(102,'〖玄冰头盔〗','初级头盔',0,0,0,33,0,0,0,1,1,1,1,10,1,0,1000,0,6,5),(103,'〖仙魂头盔〗','仙魂套装之--头盔！',0,0,0,200,0,0,0,3,3,3,10,10,1,0,1000,0,6,5),(104,'【白虎头盔】','白虎套装之盔！（拾取绑定）',0,0,0,228,0,0,0,5,5,5,60,10,0,0,1000,0,1,5),(105,'【七星头盔】','七星套装之盔！（拾取绑定）',0,0,0,228,0,0,0,5,5,5,60,10,0,0,1000,0,4,5),(106,'【龙鳞头盔】','龙鳞套装之盔！（拾取绑定）',0,0,0,228,0,0,0,5,5,5,60,10,0,0,1000,0,2,5),(107,'【伏虎头盔】','伏虎套装之盔！（拾取绑定）',0,0,0,228,0,0,0,5,5,5,60,10,0,0,1000,0,5,5),(108,'【碧海头盔】','碧海套装之盔！（拾取绑定）',0,0,0,228,0,0,0,5,5,5,60,10,0,0,1000,0,3,5),(109,'【白虎笑傲盔】','白虎笑傲套之盔！（拾取绑定）',0,253,0,535,0,0,0,5,5,5,65,10,0,0,1000,0,1,5),(110,'【七星逐月盔】','七星逐月套之盔！（拾取绑定）',0,253,0,535,0,0,0,5,5,5,65,10,0,0,1000,0,4,5),(111,'【龙鳞破天盔】','龙鳞破天套之盔！（拾取绑定）',0,253,0,535,0,0,0,5,5,5,65,10,0,0,1000,0,2,5),(112,'【伏虎降龙盔】','伏虎降龙套之盔！（拾取绑定）',0,253,0,535,0,0,0,5,5,5,65,10,0,0,1000,0,5,5),(113,'【碧海青天盔】','白虎笑傲套之盔！（拾取绑定）',0,253,0,535,0,0,0,5,5,5,65,10,0,0,1000,0,3,5),(114,'【玄武头盔】','玄武套装之盔！（拾取绑定）',0,311,0,735,0,0,0,8,8,8,65,10,0,0,1000,0,1,5),(115,'【无极头盔】','无极套装之盔！（拾取绑定）',0,311,0,735,0,0,0,8,8,8,65,10,0,0,1000,0,4,5),(116,'【青龙头盔】','青龙套装之盔！（拾取绑定）',0,311,0,735,0,0,0,8,8,8,65,10,0,0,1000,0,2,5),(117,'【金刚头盔】','金刚套装之盔！（拾取绑定）',0,311,0,735,0,0,0,8,8,8,65,10,0,0,1000,0,5,5),(118,'【银沙头盔】','玄武套装之盔！（拾取绑定）',0,311,0,735,0,0,0,8,8,8,65,10,0,0,1000,0,3,5),(119,'【玄武撼地盔】','玄武撼地套装之盔！（拾取绑定）',0,510,0,1135,0,0,0,10,10,10,70,10,0,0,1000,0,1,5),(120,'【无极无道盔】','无极无道套装之盔！（拾取绑定）',0,510,0,1135,0,0,0,10,10,10,70,10,0,0,1000,0,4,5),(121,'【青龙在天盔】','青龙在天套装之盔！（拾取绑定）',0,510,0,1135,0,0,0,10,10,10,70,10,0,0,1000,0,2,5),(122,'【怒目金刚盔】','怒目金刚套装之盔！（拾取绑定）',0,510,0,1135,0,0,0,10,10,10,70,10,0,0,1000,0,5,5),(123,'【银沙瀚海盔】','银沙瀚海套装之盔！（拾取绑定）',0,510,0,1135,0,0,0,10,10,10,70,10,0,0,1000,0,3,5),(124,'【朱雀头盔】','朱雀套装之头盔！（拾取绑定）',0,1138,0,2758,0,0,0,18,18,18,80,10,0,0,1000,0,1,5),(125,'【太乙头盔】','太乙套装之头盔！（拾取绑定）',0,1138,0,2758,0,0,0,18,18,18,80,10,0,0,1000,0,4,5),(126,'【天龙头盔】','天龙套装之头盔！（拾取绑定）',0,1138,0,2758,0,0,0,18,18,18,80,10,0,0,1000,0,2,5),(127,'【罗汉头盔】','罗汉套装之头盔！（拾取绑定）',0,1138,0,2758,0,0,0,18,18,18,80,10,0,0,1000,0,5,5),(128,'【奔月头盔】','奔月套装之头盔！（拾取绑定）',0,1138,0,2758,0,0,0,18,18,18,80,10,0,0,1000,0,3,5),(129,'〖旱魃鬼面〗','旱魃用过的头盔！(可在长安装备锻造商处进行升级)',0,0,0,937,0,0,0,8,8,8,60,10,1,0,1000,0,6,5),(130,'【旱魃鬼面】','旱魃用过的头盔！！（拾取绑定）',0,1638,1638,3076,0,0,0,20,20,20,99,10,0,0,1000,0,6,5),(131,'【巨灵头盔】','传说中的大巨灵装备，你值得拥有！！（拾取绑定）',0,4565,4565,3345,0,0,0,25,25,25,109,10,0,0,1000,0,6,5),(132,'〖雷皇战盔〗','雷皇套装之一',0,0,0,158,0,0,0,3,3,3,40,10,1,0,1000,0,6,5),(133,'【幻想战盔】','幻想绝版套装之战盔！（拾取绑定）',0,3752,3752,2784,0,0,0,15,15,15,50,10,0,0,1000,0,6,5),(134,'〖玄冰战靴〗','初级战靴',0,0,0,23,0,0,0,1,1,1,1,10,1,0,1000,0,6,6),(135,'〖仙魂战靴〗','仙魂套装之--战靴！',0,0,0,180,0,0,0,3,3,3,10,10,1,0,1000,0,6,6),(136,'【白虎战靴】','白虎套装之靴！（拾取绑定）',0,0,0,230,0,0,0,5,5,5,60,10,0,0,1000,0,1,6),(137,'【七星战靴】','七星套装之靴！（拾取绑定）',0,0,0,230,0,0,0,5,5,5,60,10,0,0,1000,0,4,6),(138,'【龙鳞战靴】','龙鳞套装之靴！（拾取绑定）',0,0,0,230,0,0,0,5,5,5,60,10,0,0,1000,0,2,6),(139,'【伏虎战靴】','伏虎套装之靴！（拾取绑定）',0,0,0,230,0,0,0,5,5,5,60,10,0,0,1000,0,5,6),(140,'【碧海战靴】','碧海套装之靴！（拾取绑定）',0,0,0,230,0,0,0,5,5,5,60,10,0,0,1000,0,3,6),(141,'【白虎笑傲靴】','白虎笑傲套之靴！（拾取绑定）',0,0,0,369,0,0,0,5,5,5,65,10,0,0,1000,0,1,6),(142,'【七星逐月靴】','七星逐月套之靴！（拾取绑定）',0,0,0,369,0,0,0,5,5,5,65,10,0,0,1000,0,4,6),(143,'【龙鳞破天靴】','龙鳞破天套之靴！（拾取绑定）',0,0,0,369,0,0,0,5,5,5,65,10,0,0,1000,0,2,6),(144,'【伏虎降龙靴】','伏虎降龙套之靴！（拾取绑定）',0,0,0,369,0,0,0,5,5,5,65,10,0,0,1000,0,5,6),(145,'【碧海青天靴】','碧海青天套之靴！（拾取绑定）',0,0,0,369,0,0,0,5,5,5,65,10,0,0,1000,0,3,6),(146,'【玄武战靴】','玄武套装之靴！（拾取绑定）',0,0,0,580,0,0,0,8,8,8,65,10,0,0,1000,0,1,6),(147,'【无极战靴】','无极套装之靴！（拾取绑定）',0,0,0,580,0,0,0,8,8,8,65,10,0,0,1000,0,4,6),(148,'【青龙战靴】','青龙套装之靴！（拾取绑定）',0,0,0,580,0,0,0,8,8,8,65,10,0,0,1000,0,2,6),(149,'【金刚战靴】','金刚套装之靴！（拾取绑定）',0,0,0,580,0,0,0,8,8,8,65,10,0,0,1000,0,5,6),(150,'【银沙战靴】','银沙套装之靴！（拾取绑定）',0,0,0,580,0,0,0,8,8,8,65,10,0,0,1000,0,3,6),(151,'【玄武撼地靴】','玄武撼地套装之靴！（拾取绑定）',0,0,0,1076,0,0,0,10,10,10,70,10,0,0,1000,0,1,6),(152,'【无极无道靴】','无极无道套装之靴！（拾取绑定）',0,0,0,1076,0,0,0,10,10,10,70,10,0,0,1000,0,4,6),(153,'【青龙在天靴】','青龙在天套装之靴！（拾取绑定）',0,0,0,1076,0,0,0,10,10,10,70,10,0,0,1000,0,2,6),(154,'【怒目金刚靴】','怒目金刚套装之靴！（拾取绑定）',0,0,0,1076,0,0,0,10,10,10,70,10,0,0,1000,0,5,6),(155,'【银沙瀚海靴】','银沙瀚海套装之靴！（拾取绑定）',0,0,0,1076,0,0,0,10,10,10,70,10,0,0,1000,0,3,6),(156,'【朱雀战靴】','朱雀套装之战靴！（拾取绑定）',0,0,0,2463,0,0,0,18,18,18,80,10,0,0,1000,0,1,6),(157,'【太乙战靴】','太乙套装之战靴！（拾取绑定）',0,0,0,2463,0,0,0,18,18,18,80,10,0,0,1000,0,4,6),(158,'【天龙战靴】','天龙套装之战靴！（拾取绑定）',0,0,0,2463,0,0,0,18,18,18,80,10,0,0,1000,0,2,6),(159,'【罗汉战靴】','罗汉套装之战靴！（拾取绑定）',0,0,0,2463,0,0,0,18,18,18,80,10,0,0,1000,0,5,6),(160,'【奔月战靴】','奔月战套装之战靴！（拾取绑定）',0,0,0,2463,0,0,0,18,18,18,80,10,0,0,1000,0,3,6),(161,'〖神皇之靴〗','战神神皇用过的靴子！(可在长安装备锻造商处进行升级)',0,0,0,895,0,0,0,8,8,8,60,10,1,0,1000,0,6,6),(162,'【神皇之靴】','战神神皇用过的靴子！！（拾取绑定）',0,0,0,2654,0,0,0,20,20,20,99,10,0,0,1000,0,6,6),(163,'【巨灵战靴】','传说中的大巨灵装备，你值得拥有！！（拾取绑定）',0,3656,3656,3656,0,0,0,25,25,25,109,10,0,0,1000,0,6,6),(164,'〖雷皇战靴〗','雷皇套装之一',0,0,0,152,0,0,0,3,3,3,40,10,1,0,1000,0,6,6),(165,'【幻想战靴】','幻想绝版套装之战靴！（拾取绑定）',0,0,0,2563,0,0,0,15,15,15,50,10,0,0,1000,0,6,6),(166,'〖玄冰项链〗','初级项链',0,39,39,29,1,1,1,1,1,1,1,10,1,0,1000,0,6,7),(167,'〖仙魂之怒〗','仙魂套装之--项链！',0,110,110,98,2,2,2,2,2,2,10,10,1,0,1000,0,6,7),(168,'【白虎项链】','白虎套装之项链！（拾取绑定）',0,211,211,198,0,0,0,5,5,5,60,10,0,0,1000,0,1,7),(169,'【七星项链】','七星套装之项链！（拾取绑定）',0,211,211,198,0,0,0,5,5,5,60,10,0,0,1000,0,4,7),(170,'【龙鳞项链】','龙鳞套装之项链！（拾取绑定）',0,211,211,198,0,0,0,5,5,5,60,10,0,0,1000,0,2,7),(171,'【伏虎项链】','伏虎套装之项链！（拾取绑定）',0,211,211,198,0,0,0,5,5,5,60,10,0,0,1000,0,5,7),(172,'【碧海项链】','碧海套装之项链！（拾取绑定）',0,211,211,198,0,0,0,5,5,5,60,10,0,0,1000,0,3,7),(173,'【白虎笑傲项链】','白虎笑傲套之项链！（拾取绑定）',0,458,458,325,5,5,5,5,5,5,65,10,0,0,1000,0,1,7),(174,'【七星逐月项链】','七星逐月套之项链！（拾取绑定）',0,458,458,325,5,5,5,5,5,5,65,10,0,0,1000,0,4,7),(175,'【龙鳞破天项链】','龙鳞破天套之项链！（拾取绑定）',0,458,458,325,5,5,5,5,5,5,65,10,0,0,1000,0,2,7),(176,'【伏虎降龙项链】','伏虎降龙套之项链！（拾取绑定）',0,458,458,325,5,5,5,5,5,5,65,10,0,0,1000,0,5,7),(177,'【碧海青天项链】','碧海青天套之项链！（拾取绑定）',0,458,458,325,5,5,5,5,5,5,65,10,0,0,1000,0,3,7),(178,'【玄武项链】','玄武套装之项链！（拾取绑定）',0,765,765,886,8,8,8,8,8,8,65,10,0,0,1000,0,1,7),(179,'【无极项链】','无极套装之项链！（拾取绑定）',0,765,765,886,8,8,8,8,8,8,65,10,0,0,1000,0,4,7),(180,'【青龙项链】','青龙套装之项链！（拾取绑定）',0,765,765,886,8,8,8,8,8,8,65,10,0,0,1000,0,2,7),(181,'【金刚项链】','金刚套装之项链！（拾取绑定）',0,765,765,886,8,8,8,8,8,8,65,10,0,0,1000,0,5,7),(182,'【银沙项链】','银沙套装之项链！（拾取绑定）',0,765,765,886,8,8,8,8,8,8,65,10,0,0,1000,0,3,7),(183,'【玄武撼地项链】','玄武撼地套装之项链！（拾取绑定）',0,1087,1087,1285,10,10,10,10,10,10,70,10,0,0,1000,0,1,7),(184,'【无极无道项链】','无极无道套装之项链！（拾取绑定）',0,1087,1087,1285,10,10,10,10,10,10,70,10,0,0,1000,0,4,7),(185,'【青龙在天项链】','青龙在天套装之项链！（拾取绑定）',0,1087,1087,1285,10,10,10,10,10,10,70,10,0,0,1000,0,2,7),(186,'【怒目金刚项链】','怒目金刚套装之项链！（拾取绑定）',0,1087,1087,1285,10,10,10,10,10,10,70,10,0,0,1000,0,5,7),(187,'【银沙瀚海项链】','银沙瀚海套装之项链！（拾取绑定）',0,1087,1087,1285,10,10,10,10,10,10,70,10,0,0,1000,0,3,7),(188,'【朱雀项链】','朱雀套装之项链！（拾取绑定）',0,1987,1987,2213,18,18,18,18,18,18,80,10,0,0,1000,0,1,7),(189,'【太乙项链】','太乙套装之项链！（拾取绑定）',0,1987,1987,2213,18,18,18,18,18,18,80,10,0,0,1000,0,4,7),(190,'【天龙项链】','天龙套装之项链！（拾取绑定）',0,1987,1987,2213,18,18,18,18,18,18,80,10,0,0,1000,0,2,7),(191,'【罗汉项链】','罗汉套装之项链！（拾取绑定）',0,1987,1987,2213,18,18,18,18,18,18,80,10,0,0,1000,0,5,7),(192,'【奔月项链】','奔月套装之项链！（拾取绑定）',0,1987,1987,2213,18,18,18,18,18,18,80,10,0,0,1000,0,3,7),(193,'【共工护符】','战神神皇用过的护符！（拾取绑定）',0,2134,2134,2345,20,20,20,20,20,20,99,10,0,0,1000,0,6,7),(194,'【巨灵项链】','传说中的大巨灵装备，你值得拥有！！（拾取绑定）',0,3443,3443,2767,25,25,25,25,25,25,109,10,0,0,1000,0,6,7),(195,'〖雷皇之怒〗','雷皇套装之一',0,211,211,195,5,5,5,4,4,4,40,10,1,0,1000,0,6,7),(196,'【幻想项链】','幻想绝版套装之项链！（拾取绑定）',0,2688,2688,0,0,0,0,15,15,15,50,10,0,0,1000,0,6,7),(197,'〖玄冰手镯〗','初级手镯',0,28,28,33,1,1,1,1,1,1,1,10,1,0,1000,0,6,8),(198,'〖仙魂守护〗','仙魂套装之--手镯！',0,99,99,150,2,2,2,2,2,2,10,10,1,0,1000,0,6,8),(199,'【白虎手镯】','白虎套装之手镯！（拾取绑定）',0,268,268,244,0,0,0,5,5,5,60,10,0,0,1000,0,1,8),(200,'【七星手镯】','七星套装之手镯！（拾取绑定）',0,268,268,244,0,0,0,5,5,5,60,10,0,0,1000,0,4,8),(201,'【龙鳞手镯】','龙鳞套装之手镯！（拾取绑定）',0,268,268,244,0,0,0,5,5,5,60,10,0,0,1000,0,2,8),(202,'【伏虎手镯】','伏虎套装之手镯！（拾取绑定）',0,268,268,244,0,0,0,5,5,5,60,10,0,0,1000,0,5,8),(203,'【碧海手镯】','碧海套装之手镯！（拾取绑定）',0,268,268,244,0,0,0,5,5,5,60,10,0,0,1000,0,3,8),(204,'【白虎笑傲手镯】','白虎笑傲套之手镯！（拾取绑定）',0,510,510,415,5,5,5,5,5,5,65,10,0,0,1000,0,1,8),(205,'【七星逐月手镯】','七星逐月套之手镯！（拾取绑定）',0,510,510,415,5,5,5,5,5,5,65,10,0,0,1000,0,4,8),(206,'【龙鳞破天手镯】','龙鳞破天套之手镯！（拾取绑定）',0,510,510,415,5,5,5,5,5,5,65,10,0,0,1000,0,2,8),(207,'【伏虎降龙手镯】','伏虎降龙套之手镯！（拾取绑定）',0,510,510,415,5,5,5,5,5,5,65,10,0,0,1000,0,5,8),(208,'【碧海青天手镯】','碧海青天套之手镯！（拾取绑定）',0,510,510,415,5,5,5,5,5,5,65,10,0,0,1000,0,3,8),(209,'【玄武手镯】','玄武套装之手镯！（拾取绑定）',0,881,881,992,8,8,8,8,8,8,65,10,0,0,1000,0,1,8),(210,'【无极手镯】','无极套装之手镯！（拾取绑定）',0,881,881,992,8,8,8,8,8,8,65,10,0,0,1000,0,4,8),(211,'【青龙手镯】','青龙套装之手镯！（拾取绑定）',0,881,881,992,8,8,8,8,8,8,65,10,0,0,1000,0,2,8),(212,'【金刚手镯】','金刚套装之手镯！（拾取绑定）',0,881,881,992,8,8,8,8,8,8,65,10,0,0,1000,0,5,8),(213,'【银沙手镯】','银沙套装之手镯！（拾取绑定）',0,881,881,992,8,8,8,8,8,8,65,10,0,0,1000,0,3,8),(214,'【玄武撼地手镯】','玄武撼地套装之手镯！（拾取绑定）',0,1353,1353,1557,10,10,10,10,10,10,70,10,0,0,1000,0,1,8),(215,'【无极无道手镯】','无极无道套装之手镯！（拾取绑定）',0,1353,1353,1557,10,10,10,10,10,10,70,10,0,0,1000,0,4,8),(216,'【青龙在天手镯】','青龙在天套装之手镯！（拾取绑定）',0,1353,1353,1557,10,10,10,10,10,10,70,10,0,0,1000,0,2,8),(217,'【怒目金刚手镯】','怒目金刚套装之手镯！（拾取绑定）',0,1353,1353,1557,10,10,10,10,10,10,70,10,0,0,1000,0,5,8),(218,'【银沙瀚海手镯】','银沙瀚海套装之手镯！（拾取绑定）',0,1353,1353,1557,10,10,10,10,10,10,70,10,0,0,1000,0,3,8),(219,'【朱雀手镯】','朱雀套装之手镯！（拾取绑定）',0,3153,3153,3328,18,18,18,18,18,18,80,10,0,0,1000,0,1,8),(220,'【太乙手镯】','太乙套装之手镯！（拾取绑定）',0,3153,3153,3328,18,18,18,18,18,18,80,10,0,0,1000,0,4,8),(221,'【天龙手镯】','天龙套装之手镯！（拾取绑定）',0,3153,3153,3328,18,18,18,18,18,18,80,10,0,0,1000,0,2,8),(222,'【罗汉手镯】','罗汉套装之手镯！（拾取绑定）',0,3153,3153,3328,18,18,18,18,18,18,80,10,0,0,1000,0,5,8),(223,'【奔月手镯】','奔月套装之手镯！（拾取绑定）',0,3153,3153,3328,18,18,18,18,18,18,80,10,0,0,1000,0,3,8),(224,'〖祝融戒指〗','战神祝融使用过的戒指！(可在长安装备锻造商处进行升级)',0,364,364,731,8,8,8,8,8,8,60,10,1,0,1000,0,6,8),(232,'【巨灵手镯】','战神祝融使用过的戒指！！（拾取绑定）',0,4534,4534,3654,25,25,25,25,25,25,109,10,1,0,1000,0,6,8),(233,'〖雷皇守护〗','雷皇套装之一',0,288,288,234,5,5,5,4,4,4,40,10,1,0,1000,0,6,8),(234,'【幻想手镯】','幻想绝版套装之手镯！（拾取绑定）',0,2514,2514,0,0,0,0,15,15,15,50,10,0,0,1000,0,6,8),(235,'〖共工护符〗','战神共工用过的护符！(可在长安装备锻造商处进行升级)',0,899,899,1000,10,10,10,10,10,10,60,10,1,0,1000,0,7,7),(236,'【刑天铁甲】','战神刑天用过的战甲！（拾取绑定）',0,0,0,2131,0,0,0,20,20,20,99,10,0,0,1000,0,6,4),(237,'【祝融戒指】','战神祝融使用过的戒指！！（拾取绑定）',0,3324,3324,3567,20,20,20,20,20,20,99,10,0,0,1000,0,6,8),(238,'【阐气瓶】（1级）','低级的法宝武器-【阐气瓶】',20000,800,800,500,3,3,3,3,3,3,99,10,0,0,1000,0,6,1),(239,'【阐气瓶】（2级）','低级的法宝武器-【阐气瓶】',22000,1080,1080,700,4,4,4,4,4,4,99,10,0,0,1000,0,6,1),(240,'【阐气瓶】（3级）','低级的法宝武器-【阐气瓶】',25000,1460,1460,1080,5,5,5,5,5,5,99,10,0,0,1000,0,6,1),(241,'【阐气瓶】（4级）','低级的法宝武器-【阐气瓶】',30000,1628,1628,1325,6,6,6,6,6,6,99,10,0,0,1000,0,6,1),(242,'【阐气瓶】（5级）','低级的法宝武器-【阐气瓶】',35000,1888,1888,1269,7,7,7,7,7,7,99,10,0,0,1000,0,6,1),(243,'【开天珠】（1级）','中级的法宝武器【开天珠】',40000,2158,2158,1388,8,8,8,8,8,8,99,10,0,0,1000,0,6,1),(244,'【开天珠】（2级）','中级的法宝武器【开天珠】',45822,2352,2352,1599,9,9,9,9,9,9,99,10,0,0,1000,0,6,1),(245,'【开天珠】（3级）','中级的法宝武器【开天珠】',52102,2689,2679,1688,10,10,10,10,10,10,99,10,0,0,1000,0,6,1),(246,'【开天珠】（4级）','中级的法宝武器【开天珠】',62158,2825,2825,2111,11,11,11,11,11,11,99,10,0,0,1000,0,6,1),(247,'【开天珠】（5级）','中级的法宝武器【开天珠】',72158,3125,3125,2356,12,12,12,12,12,12,99,10,0,0,1000,0,6,1),(248,'【定海珠】（1级）','中级的法宝武器【定海珠】',74125,3514,3514,2579,13,13,13,13,13,13,99,10,0,0,1000,0,6,1),(249,'【定海珠】（2级）','中级的法宝武器【定海珠】',76852,3869,3869,2789,14,14,14,14,14,14,99,10,0,0,1000,0,6,1),(250,'【定海珠】（3级）','中级的法宝武器【定海珠】',78588,4012,4012,2956,15,15,15,15,15,15,99,10,0,0,1000,0,6,1),(251,'【定海珠】（4级）','中级的法宝武器【定海珠】',80258,4256,4256,3126,16,16,16,16,16,16,99,10,0,0,1000,0,6,1),(252,'【定海珠】（5级）','中级的法宝武器【定海珠】',82456,4452,4452,3315,17,17,17,17,17,17,99,10,0,0,1000,0,6,1),(253,'【乾坤圈】（1级）','高级的法宝武器【乾坤圈】',84215,4621,4621,3542,18,18,18,18,18,18,109,10,0,0,1000,0,6,1),(254,'【乾坤圈】（2级）','高级的法宝武器【乾坤圈】',86524,4852,4852,3687,18,18,18,18,18,18,109,10,0,0,1000,0,6,1),(255,'【乾坤圈】（3级）','高级的法宝武器【乾坤圈】',88596,5014,5014,3689,18,18,18,18,18,18,109,10,0,0,1000,0,6,1),(256,'【乾坤圈】（4级）','高级的法宝武器【乾坤圈】',90261,6235,6235,3856,18,18,18,18,18,18,109,10,0,0,1000,0,6,1),(257,'【乾坤圈】（5级）','高级的法宝武器【乾坤圈】',92365,6425,6425,4015,18,18,18,18,18,18,109,10,0,0,1000,0,6,1),(258,'【金箍棒】（1级）','齐天大圣曾使用过的【金箍棒】',105822,7058,7058,5028,21,21,21,21,21,21,139,10,0,0,1000,0,6,1),(259,'【金箍棒】（2级）','齐天大圣曾使用过的【金箍棒】',108822,7358,7358,5328,22,22,22,22,22,22,139,10,0,0,1000,0,6,1),(260,'【金箍棒】（3级）','齐天大圣曾使用过的【金箍棒】',111822,7658,7658,5628,23,23,23,23,23,23,139,10,0,0,1000,0,6,1),(261,'【金箍棒】（4级）','齐天大圣曾使用过的【金箍棒】',114822,7958,7958,5928,24,24,24,24,24,24,139,10,0,0,1000,0,6,1),(262,'【金箍棒】（5级）','齐天大圣曾使用过的【金箍棒】',117822,8358,8358,8328,25,25,25,25,25,25,139,10,0,0,1000,0,6,1),(263,'【金箍棒】（6级）','齐天大圣曾使用过的【金箍棒】',120822,8658,8658,8628,26,26,26,26,26,26,139,10,0,0,1000,0,6,1),(264,'【金箍棒】（7级）','齐天大圣曾使用过的【金箍棒】',123822,8958,8958,8928,27,27,27,27,27,27,139,10,0,0,1000,0,6,1),(265,'【金箍棒】（8级）','齐天大圣曾使用过的【金箍棒】',126822,9258,9258,9228,28,28,28,28,28,28,139,10,0,0,1000,0,6,1),(266,'【金箍棒】（9级）','齐天大圣曾使用过的【金箍棒】',129822,9558,9558,9528,29,29,29,29,29,29,139,10,0,0,1000,0,6,1),(267,'【金箍棒】（10级）','齐天大圣曾使用过的【金箍棒】',132822,10058,10058,10028,30,30,30,30,30,30,159,10,0,0,1000,0,6,1),(268,'【金箍棒】（11级）','齐天大圣曾使用过的【金箍棒】',136822,10458,10458,10428,31,31,31,31,31,31,159,10,0,0,1000,0,6,1),(269,'【金箍棒】（12级）','齐天大圣曾使用过的【金箍棒】',140822,10858,10858,10828,32,32,32,32,32,32,159,10,0,0,1000,0,6,1),(270,'【金箍棒】（13级）','齐天大圣曾使用过的【金箍棒】',144822,11258,11258,11228,33,33,33,33,33,33,159,10,0,0,1000,0,6,1),(271,'【金箍棒】（14级）','齐天大圣曾使用过的【金箍棒】',148822,11658,11658,11628,34,34,34,34,34,34,159,10,0,0,1000,0,6,1),(272,'【金箍棒】（15级）','齐天大圣曾使用过的【金箍棒】',152822,12058,12058,12028,35,35,35,35,35,35,159,10,0,0,1000,0,6,1),(273,'【金箍棒】（16级）','齐天大圣曾使用过的【金箍棒】',156822,12458,12458,12428,36,36,36,36,36,36,159,10,0,0,1000,0,6,1),(274,'【金箍棒】（17级）','齐天大圣曾使用过的【金箍棒】',160822,12858,12858,12828,37,37,37,37,37,37,159,10,0,0,1000,0,6,1),(275,'【金箍棒】（18级）','齐天大圣曾使用过的【金箍棒】',164822,13258,13258,13228,38,38,38,38,38,38,159,10,0,0,1000,0,6,1),(276,'【金箍棒】（19级）','齐天大圣曾使用过的【金箍棒】',168822,13658,13658,13628,39,39,39,30,30,30,159,10,0,0,1000,0,6,1),(277,'【金箍棒】（20级）','齐天大圣曾使用过的【金箍棒】',172822,14058,14058,14028,40,40,40,40,40,40,159,10,0,0,1000,0,6,1),(278,'【如意金箍棒】（1级）','【如意金箍棒】号令天下，谁敢不从，能够自动收缩抽打敌人',180000,15000,15000,15000,50,50,50,50,50,50,199,10,0,0,1000,0,6,1),(279,'【如意金箍棒】（2级）','【如意金箍棒】号令天下，谁敢不从，能够自动收缩抽打敌人',190000,16000,16000,16000,51,51,51,51,51,51,199,10,0,0,1000,0,6,1),(280,'【如意金箍棒】（3级）','【如意金箍棒】号令天下，谁敢不从，能够自动收缩抽打敌人',200000,17000,17000,17000,52,52,52,52,52,52,199,10,0,0,1000,0,6,1),(281,'【如意金箍棒】（4级）','【如意金箍棒】号令天下，谁敢不从，能够自动收缩抽打敌人',210000,18000,18000,18000,53,53,53,53,53,53,199,10,0,0,1000,0,6,1),(282,'【如意金箍棒】（5级）','【如意金箍棒】号令天下，谁敢不从，能够自动收缩抽打敌人',220000,19000,19000,19000,54,54,54,54,54,54,199,10,0,0,1000,0,6,1),(283,'【如意金箍棒】（6级）','【如意金箍棒】号令天下，谁敢不从，能够自动收缩抽打敌人',230000,20000,20000,20000,55,55,55,55,55,55,199,10,0,0,1000,0,6,1),(284,'【如意金箍棒】（7级）','【如意金箍棒】号令天下，谁敢不从，能够自动收缩抽打敌人',240000,21000,21000,21000,56,56,56,56,56,56,199,10,0,0,1000,0,6,1),(285,'【如意金箍棒】（8级）','【如意金箍棒】号令天下，谁敢不从，能够自动收缩抽打敌人',250000,22000,22000,22000,57,57,57,57,57,57,199,10,0,0,1000,0,6,1),(286,'【如意金箍棒】（9级）','【如意金箍棒】号令天下，谁敢不从，能够自动收缩抽打敌人',260000,23000,23000,23000,58,58,58,58,58,58,199,10,0,0,1000,0,6,1),(287,'【如意金箍棒】（10级）','【如意金箍棒】号令天下，谁敢不从，能够自动收缩抽打敌人',270000,24000,24000,24000,65,65,65,65,65,65,200,10,0,0,1000,0,6,1),(288,'【如意金箍棒】（11级）','【如意金箍棒】号令天下，谁敢不从，能够自动收缩抽打敌人',280000,25000,25000,25000,66,66,66,66,66,66,200,10,0,0,1000,0,6,1),(289,'【如意金箍棒】（12级）','【如意金箍棒】号令天下，谁敢不从，能够自动收缩抽打敌人',290000,26000,26000,26000,67,67,67,67,67,67,200,10,0,0,1000,0,6,1),(290,'【如意金箍棒】（14级）','【如意金箍棒】号令天下，谁敢不从，能够自动收缩抽打敌人',310000,28000,28000,28000,69,69,69,69,69,69,200,10,0,0,1000,0,6,1),(291,'【如意金箍棒】（15级）','【如意金箍棒】号令天下，谁敢不从，能够自动收缩抽打敌人',320000,29000,29000,29000,75,75,75,75,75,75,200,10,0,0,1000,0,6,1),(292,'【如意金箍棒】（16级）','【如意金箍棒】号令天下，谁敢不从，能够自动收缩抽打敌人',330000,30000,30000,30000,76,76,76,76,76,76,200,10,0,0,1000,0,6,1),(293,'【如意金箍棒】（17级）','【如意金箍棒】号令天下，谁敢不从，能够自动收缩抽打敌人',340000,31000,31000,31000,77,77,77,77,77,77,200,10,0,0,1000,0,6,1),(294,'【如意金箍棒】（17级）','【如意金箍棒】号令天下，谁敢不从，能够自动收缩抽打敌人',350000,32000,32000,32000,78,78,78,78,78,78,200,10,0,0,1000,0,6,1),(295,'【如意金箍棒】（18级）','【如意金箍棒】号令天下，谁敢不从，能够自动收缩抽打敌人',360000,33000,33000,33000,79,79,79,79,79,79,200,10,0,0,1000,0,6,1),(296,'【如意金箍棒】（19级）','【如意金箍棒】号令天下，谁敢不从，能够自动收缩抽打敌人',370000,34000,34000,34000,80,80,80,80,80,80,200,10,0,0,1000,0,6,1),(297,'【风火双轮】','低阶坐骑-【风火双轮】，（可在天宫升级，合成中阶坐骑的必备）',200,30,50,80,3,3,3,3,3,3,99,10,0,0,1000,0,6,2),(298,'【玉角麒麟】','低阶坐骑-【玉角麒麟】，（可在天宫升级，合成中阶坐骑的必备）',200,30,50,80,3,3,3,3,3,3,99,10,0,0,1000,0,6,2),(299,'【五彩神牛】','低阶坐骑-【五彩神牛】，（可在天宫升级，合成中阶坐骑的必备）',200,30,50,80,3,3,3,3,3,3,99,10,0,0,1000,0,6,2),(300,'【章鱼哥】','中阶坐骑-【章鱼哥】，（可在长安装备锻造商处进行魔化升级）',200,30,50,80,3,3,3,3,3,3,99,10,0,0,1000,0,6,2),(301,'【仙鹤】','中阶坐骑-【仙鹤】，（可在长安装备锻造商处进行魔化升级）',200,30,50,80,3,3,3,3,3,3,99,10,0,0,1000,0,6,2),(302,'【五爪金龙】','中阶坐骑-【五爪金龙】，（可在长安装备锻造商处进行魔化升级）',200,30,50,80,3,3,3,3,3,3,99,10,0,0,1000,0,6,2),(333,'【镇东神兽】（青龙）','高阶坐骑-【镇东神兽】（青龙）',35888,4345,4345,3258,20,20,20,20,20,20,139,10,0,0,1000,0,6,2),(334,'【镇东神兽】（白虎）','高阶坐骑-【镇东神兽】（白虎）',8888,6789,4345,3258,20,20,20,20,20,20,139,10,0,0,1000,0,6,2),(335,'【镇东神兽】（朱雀）','高阶坐骑-【镇东神兽】（朱雀）',8888,4345,6789,3258,20,20,20,20,20,20,139,10,0,0,1000,0,6,2),(336,'【镇东神兽】（玄武）','高阶坐骑-【镇东神兽】（玄武）',8888,4345,4345,6088,20,20,20,20,20,20,139,10,0,0,1000,0,6,2),(337,'【心心相印】（婚戒）','【心心相印】（婚戒）象征着彼此相爱恋人的信物',2100,980,1025,885,3,3,3,3,3,3,40,10,0,0,1000,0,6,9),(338,'【心心相印】（婚链）','【心心相印】（婚链）象征着彼此相爱恋人的信物',2100,980,1025,885,3,3,3,3,3,3,40,10,0,0,1000,0,6,10),(400,'【幻想枪Ⅰ】','幻想西游vip玩家专属【幻想枪Ⅰ】',0,5894,5894,0,20,20,20,0,0,0,99,10,0,0,1000,0,1,3),(401,'【幻想战甲Ⅰ】','幻想西游vip玩家专属【幻想战甲Ⅰ】',0,0,0,3318,20,20,20,0,0,0,99,10,0,0,1000,0,6,4),(402,'【幻想战盔Ⅰ】','幻想西游vip玩家专属【幻想战盔Ⅰ】',0,4214,4214,3041,20,20,20,0,0,0,99,10,0,0,1000,0,6,5),(403,'【幻想战靴Ⅰ】','幻想西游vip玩家专属【幻想战靴Ⅰ】',0,3325,3325,3325,20,20,20,0,0,0,99,10,0,0,1000,0,6,6),(404,'【幻想项链Ⅰ】','幻想西游vip玩家专属【幻想项链Ⅰ】',0,3322,3322,0,20,20,20,20,20,20,99,10,0,0,1000,0,6,7),(405,'【幻想手镯Ⅰ】','幻想西游vip玩家专属【幻想手镯Ⅰ】',0,4578,4578,0,20,20,20,20,20,20,99,10,0,0,1000,0,6,8),(407,'【幻想战甲ⅠⅠ】','幻想西游vip玩家专属【幻想战甲ⅠⅠ】',0,0,0,3678,25,25,25,0,0,0,109,10,0,0,1000,0,6,4),(408,'【幻想战盔ⅠⅠ】','幻想西游vip玩家专属【幻想战盔ⅠⅠ】',0,5158,5158,3854,25,25,25,0,0,0,109,10,0,0,1000,0,6,5),(409,'【幻想战靴ⅠⅠ】','幻想西游vip玩家专属【幻想战靴ⅠⅠ】',0,4015,4015,3888,25,25,25,0,0,0,109,10,0,0,1000,0,6,6),(410,'【幻想项链ⅠⅠ】','幻想西游vip玩家专属【幻想项链ⅠⅠ】',0,3845,3845,0,25,25,25,25,25,25,109,10,0,0,1000,0,6,7),(411,'【幻想手镯ⅠⅠ】','幻想西游vip玩家专属【幻想手镯ⅠⅠ】',0,5048,5048,0,25,25,25,25,25,25,109,10,0,0,1000,0,6,8),(412,'【幻想叉Ⅰ】','幻想西游vip玩家专属【幻想叉Ⅰ】',0,5894,5894,0,20,20,20,0,0,0,99,10,0,0,1000,0,2,3),(413,'【幻想棍Ⅰ】','幻想西游vip玩家专属【幻想棍Ⅰ】',0,5894,5894,0,20,20,20,0,0,0,99,10,0,0,1000,0,4,3),(414,'【幻想仗Ⅰ】','幻想西游vip玩家专属【幻想仗Ⅰ】',0,5894,5894,0,20,20,20,0,0,0,99,10,0,0,1000,0,5,3),(415,'【幻想剑Ⅰ】','幻想西游vip玩家专属【幻想剑Ⅰ】',0,5894,5894,0,20,20,20,0,0,0,99,10,0,0,1000,0,3,3),(416,'【元帅戟】','将军府武器之【元帅戟】！（拾取绑定）',0,5894,5894,0,25,25,25,0,0,0,109,10,0,0,1000,0,1,3),(417,'【龙王叉】','龙宫武器之【龙王叉】！（拾取绑定）',0,5894,5894,0,25,25,25,0,0,0,109,10,0,0,1000,0,2,3),(418,'【天尊棍】','方寸山武器之【天尊棍】！（拾取绑定）',0,5894,5894,0,25,25,25,0,0,0,109,10,0,0,1000,0,4,3),(419,'【菩萨仗】','普陀山武器之【菩萨仗】！（拾取绑定）',0,5894,5894,0,25,25,25,0,0,0,109,10,0,0,1000,0,5,3),(420,'【王母剑】','月宫武器之【王母剑】！（拾取绑定）',0,5894,5894,0,25,25,25,0,0,0,109,10,0,0,1000,0,3,3),(421,'【幻想枪ⅠⅠ】','幻想西游vip玩家专属【幻想枪ⅠⅠ】',0,6688,6688,0,25,25,25,0,0,0,109,10,0,0,1000,0,1,3),(422,'【幻想叉ⅠⅠ】','幻想西游vip玩家专属【幻想叉ⅠⅠ】',0,6688,6688,0,25,25,25,0,0,0,109,10,0,0,1000,0,2,3),(423,'【幻想棍ⅠⅠ】','幻想西游vip玩家专属【幻想棍ⅠⅠ】',0,6688,6688,0,25,25,25,0,0,0,109,10,0,0,1000,0,4,3),(424,'【幻想仗ⅠⅠ】','幻想西游vip玩家专属【幻想仗ⅠⅠ】',0,6688,6688,0,25,25,25,0,0,0,109,10,0,0,1000,0,5,3),(425,'【幻想剑ⅠⅠ】','幻想西游vip玩家专属【幻想剑ⅠⅠ】',0,6688,6688,0,25,25,25,0,0,0,109,10,0,0,1000,0,3,3),(426,'〖小兽爪〗','宠物可穿戴的初级武器',0,158,158,0,1,1,1,0,0,0,1,10,1,0,1000,0,7,3),(427,'〖小兽甲〗','宠物可穿戴的初级衣服',600,0,0,100,0,0,0,1,1,1,1,10,1,0,1000,0,7,4),(428,'〖小兽盔〗','宠物可穿戴的初级头盔',0,80,80,0,0,0,0,1,1,1,1,10,1,0,1000,0,7,5),(429,'〖小兽靴〗','宠物可穿戴的初级鞋子',0,69,69,0,1,1,1,1,1,1,1,10,1,0,1000,0,7,6),(430,'〖小兽链〗','宠物可佩戴带的初级项链',500,69,69,0,1,1,1,1,1,1,1,10,1,0,1000,0,7,7),(431,'〖小兽镯〗','宠物可佩戴的初级手镯',525,77,77,0,1,1,1,1,1,1,1,10,1,0,1000,0,7,8),(432,'【心有灵犀】（婚戒）','【心有灵犀】（婚戒）象征着彼此相爱恋人的信物',6858,2125,2125,1852,5,5,5,5,5,5,99,10,0,0,1000,0,6,9),(433,'【心有灵犀】（婚链）','【心有灵犀】（婚链）象征着彼此相爱恋人的信物',6858,2125,2125,1852,5,5,5,5,5,5,99,10,0,0,1000,0,6,10),(434,'【山盟海誓】（婚戒）','【山盟海誓】（婚戒）象征着彼此相爱恋人的信物',11258,4252,4252,3645,10,10,10,10,10,10,139,10,0,0,1000,0,6,9),(435,'【山盟海誓】（婚链）','【山盟海誓】（婚链）象征着彼此相爱恋人的信物',11258,4252,4252,3645,10,10,10,10,10,10,139,10,0,0,1000,0,6,10),(436,'【比翼双飞の婚戒】（典藏版）','【比翼双飞の婚戒】（典藏版）在天愿作比翼鸟，在地愿为连理枝',21125,7521,7521,7894,15,15,15,15,15,15,139,10,0,0,1000,0,6,9),(437,'【比翼双飞の婚链】（典藏版）','【比翼双飞の婚链】（典藏版）在天愿作比翼鸟，在地愿为连理枝',23125,7721,7769,8012,15,15,15,15,15,15,139,10,0,0,1000,0,6,10),(438,'【幻想枪ⅠⅠⅠ】','幻想西游vip玩家专属【幻想枪ⅠⅠⅠ】',0,7821,7821,0,30,30,30,0,0,0,139,10,0,0,1000,0,1,3),(439,'【幻想叉ⅠⅠⅠ】','幻想西游vip玩家专属【幻想叉ⅠⅠⅠ】',0,7821,7821,0,30,30,30,0,0,0,139,10,0,0,1000,0,2,3),(440,'【幻想棍ⅠⅠⅠ】','幻想西游vip玩家专属【幻想棍ⅠⅠⅠ】',0,7821,7821,0,30,30,30,0,0,0,139,10,0,0,1000,0,4,3),(441,'【幻想仗ⅠⅠⅠ】','幻想西游vip玩家专属【幻想仗ⅠⅠⅠ】',0,7821,7821,0,30,30,30,0,0,0,139,10,0,0,1000,0,5,3),(442,'【幻想剑ⅠⅠⅠ】','幻想西游vip玩家专属【幻想剑ⅠⅠⅠ】',0,7821,7821,0,30,30,30,0,0,0,139,10,0,0,1000,0,3,3),(443,'【幻想战甲ⅠⅠⅠ】','幻想西游vip玩家专属【幻想战甲ⅠⅠⅠ】',0,0,0,4578,30,30,30,0,0,0,139,10,0,0,1000,0,6,4),(444,'【幻想战盔ⅠⅠⅠ】','幻想西游vip玩家专属【幻想战盔ⅠⅠⅠ】',0,6158,6158,5854,30,30,30,0,0,0,139,10,0,0,1000,0,6,5),(445,'【幻想战靴ⅠⅠⅠ】','幻想西游vip玩家专属【幻想战靴ⅠⅠⅠ】',0,4715,4715,4888,30,30,30,0,0,0,139,10,0,0,1000,0,6,6),(446,'【幻想项链ⅠⅠⅠ】','幻想西游vip玩家专属【幻想项链ⅠⅠⅠ】',0,4877,4877,0,30,30,30,30,30,30,139,10,0,0,1000,0,6,7),(447,'【幻想手镯ⅠⅠⅠ】','幻想西游vip玩家专属【幻想手镯ⅠⅠⅠ】',0,5448,5448,0,30,30,30,30,30,30,139,10,0,0,1000,0,6,8),(448,'【诛仙战甲】','此乃九天异铁落入凡间，枯心上人在北极冰原偶得，修炼而成',0,0,0,5325,0,0,0,35,35,35,159,10,0,0,1000,0,6,4),(449,'【诛仙战盔】','此乃九天异铁落入凡间，枯心上人在北极冰原偶得，修炼而成',0,7015,7015,7015,35,35,35,0,0,0,159,10,0,0,1000,0,6,5),(450,'【诛仙战靴】','此乃九天异铁落入凡间，枯心上人在北极冰原偶得，修炼而成',0,5515,5515,5674,35,35,35,0,0,0,159,10,0,0,1000,0,6,6),(451,'【诛仙项链】','此乃九天异铁落入凡间，枯心上人在北极冰原偶得，修炼而成',0,5684,5684,0,35,35,35,35,35,35,159,10,0,0,1000,0,6,7),(452,'【诛仙手镯】','此乃九天异铁落入凡间，枯心上人在北极冰原偶得，修炼而成',0,5984,5984,0,35,35,35,35,35,35,159,10,0,0,1000,0,6,8),(453,'【诛仙枪】','此乃九天异铁落入凡间，枯心上人在北极冰原偶得，修炼而成',0,8815,8815,0,35,35,35,0,0,0,159,10,0,0,1000,0,1,3),(454,'【诛仙叉】','此乃九天异铁落入凡间，枯心上人在北极冰原偶得，修炼而成',0,8815,8815,0,35,35,35,0,0,0,159,10,0,0,1000,0,2,3),(455,'【诛仙棍】','此乃九天异铁落入凡间，枯心上人在北极冰原偶得，修炼而成',0,8815,8815,0,35,35,35,0,0,0,159,10,0,0,1000,0,4,3),(456,'【诛仙仗】','此乃九天异铁落入凡间，枯心上人在北极冰原偶得，修炼而成',0,8815,8815,0,35,35,35,0,0,0,159,10,0,0,1000,0,5,3),(457,'【诛仙剑】','此乃九天异铁落入凡间，枯心上人在北极冰原偶得，修炼而成',0,8815,8815,0,35,35,35,0,0,0,159,10,0,0,1000,0,3,3),(458,'〖大兽爪〗','宠物可穿戴的中级武器',0,658,658,0,5,5,5,0,0,0,60,10,1,0,1000,0,7,3),(459,'〖大兽甲〗','宠物可穿戴的中级衣服',1600,0,0,600,0,0,0,5,5,5,60,10,1,0,1000,0,7,4),(460,'〖大兽盔〗','宠物可穿戴的中级头盔',0,580,580,0,0,0,0,5,5,5,60,10,1,0,1000,0,7,5),(461,'〖大兽靴〗','宠物可穿戴的中级鞋子',0,569,569,0,5,5,5,5,5,5,60,10,1,0,1000,0,7,6),(462,'〖大兽链〗','宠物可佩戴带的中级项链',1500,569,569,0,5,5,5,5,5,5,60,10,1,0,1000,0,7,7),(463,'〖大兽镯〗','宠物可佩戴的中级手镯',1525,577,577,0,5,5,5,5,5,5,60,10,1,0,1000,0,7,8),(464,'〖顽兽爪〗','宠物可穿戴的高级武器',0,1158,1158,0,10,10,10,0,0,0,100,10,1,0,1000,0,7,3),(465,'〖顽兽甲〗','宠物可穿戴的高级衣服',2600,0,0,1100,0,0,0,10,10,10,100,10,1,0,1000,0,7,4),(466,'〖顽兽盔〗','宠物可穿戴的高级头盔',0,1080,1080,0,0,0,0,10,10,10,100,10,1,0,1000,0,7,5),(467,'〖顽兽靴〗','宠物可穿戴的高级鞋子',0,1069,1069,0,10,10,10,10,10,10,100,10,1,0,1000,0,7,6),(468,'〖顽兽链〗','宠物可佩戴带的高级项链',2500,1069,1069,0,10,10,10,10,10,10,100,10,1,0,1000,0,7,7),(469,'〖顽兽镯〗','宠物可佩戴的高级手镯',2525,1077,1077,0,10,10,10,10,10,10,100,10,1,0,1000,0,7,8),(470,'〖猛兽爪〗','宠物可穿戴的猛兽级武器',0,1658,1658,0,15,15,15,0,0,0,120,10,1,0,1000,0,7,3),(471,'〖猛兽甲〗','宠物可穿戴的猛兽级衣服',3100,0,0,1100,0,0,0,15,15,15,120,10,1,0,1000,0,7,4),(472,'〖猛兽盔〗','宠物可穿戴的猛兽级头盔',0,1580,1580,0,0,0,0,15,15,15,120,10,1,0,1000,0,7,5),(473,'〖猛兽靴〗','宠物可穿戴的猛兽级鞋子',0,1569,1569,0,15,15,15,15,15,15,120,10,1,0,1000,0,7,6),(474,'〖猛兽链〗','宠物可佩戴带的猛兽级项链',3000,1569,1569,0,15,15,15,15,15,15,120,10,1,0,1000,0,7,7),(475,'〖猛兽镯〗','宠物可佩戴的猛兽级手镯',3025,1577,1577,0,15,15,15,15,15,15,120,10,1,0,1000,0,7,8),(476,'〖神兽兽爪〗','宠物可穿戴的神兽级武器',0,2158,2158,0,20,20,20,0,0,0,150,10,1,0,1000,0,7,3),(477,'〖神兽兽甲〗','宠物可穿戴的神兽级衣服',5000,0,0,1600,0,0,0,20,20,20,150,10,1,0,1000,0,7,4),(478,'〖神兽兽盔〗','宠物可穿戴的神兽级头盔',0,2080,2080,0,0,0,0,20,20,20,150,10,1,0,1000,0,7,5),(479,'〖神兽兽靴〗','宠物可穿戴的神兽级鞋子',0,2069,2069,0,20,20,20,20,20,20,150,10,1,0,1000,0,7,6),(480,'〖神兽兽链〗','宠物可佩戴带的神兽级项链',5500,2069,2069,0,20,20,20,20,20,20,150,10,1,0,1000,0,7,7),(481,'〖神兽兽镯〗','宠物可佩戴的神兽级手镯',5025,2077,2077,0,20,20,20,20,20,20,150,10,1,0,1000,0,7,8),(482,'〖圣兽兽爪〗','宠物可穿戴的圣兽级武器',0,3058,3058,0,25,25,25,0,0,0,180,10,1,0,1000,0,7,3),(483,'〖圣兽兽甲〗','宠物可穿戴的圣兽级衣服',6000,0,0,2100,0,0,0,25,25,25,180,10,1,0,1000,0,7,4),(484,'〖圣兽兽盔〗','宠物可穿戴的圣兽级头盔',0,2580,2580,0,0,0,0,25,25,25,180,10,1,0,1000,0,7,5),(485,'〖圣兽兽靴〗','宠物可穿戴的圣兽级鞋子',0,2569,2569,0,25,25,25,20,20,20,180,10,1,0,1000,0,7,6),(486,'〖圣兽兽链〗','宠物可佩戴带的圣兽级项链',6000,2569,2569,0,25,25,25,25,25,25,180,10,1,0,1000,0,7,7),(487,'〖圣兽兽镯〗','宠物可佩戴的圣兽级手镯',6025,2577,2577,0,25,25,25,25,25,25,180,10,1,0,1000,0,7,8),(488,'〖玛雅兽爪〗','玛雅宠物装，这是历代玛雅人的智慧与结晶',0,5000,5000,0,30,30,30,0,0,0,200,10,1,0,1000,0,7,3),(489,'〖玛雅兽甲〗','玛雅宠物装，这是历代玛雅人的智慧与结晶',8000,0,0,4100,0,0,0,30,30,30,200,10,1,0,1000,0,7,4),(490,'〖玛雅兽盔〗','玛雅宠物装，这是历代玛雅人的智慧与结晶',0,3580,3580,0,0,0,0,30,30,30,200,10,1,0,1000,0,7,5),(491,'〖玛雅兽靴〗','玛雅宠物装，这是历代玛雅人的智慧与结晶',0,3669,3669,0,30,30,30,30,30,30,200,10,1,0,1000,0,7,6),(492,'〖玛雅兽链〗','玛雅宠物装，这是历代玛雅人的智慧与结晶',8000,3569,3569,0,30,30,30,30,30,30,200,10,1,0,1000,0,7,7),(493,'〖玛雅兽镯〗','玛雅宠物装，这是历代玛雅人的智慧与结晶',8025,3487,3487,0,30,30,30,30,30,30,200,10,1,0,1000,0,7,8),(494,'@css01@【红莲怒火】（GM版）@css@','GM法宝-所向披靡百战百胜（拾取绑定）',39999,39999,39999,39999,99,99,99,99,99,99,1,10,0,0,1000,0,6,1),(495,'@css01@【冰火麒麟】（GM版）@css@','GM坐骑-所向披靡百战百胜（拾取绑定）',39999,39999,39999,39999,99,99,99,99,99,99,1,10,0,0,1000,0,6,2),(496,'@css01@【帝王兵器】（GM版）@css@','GM武器-所向披靡百战百胜（拾取绑定）',39999,39999,39999,39999,99,99,99,99,99,99,1,10,0,0,1000,0,6,3),(497,'@css01@【帝王战甲】（GM版）@css@','GM战甲-所向披靡百战百胜（拾取绑定）',39999,39999,39999,39999,99,99,99,99,99,99,1,10,0,0,1000,0,6,4),(498,'@css01@【帝王战盔】（GM版）@css@','GM头盔-所向披靡百战百胜（拾取绑定）',39999,39999,39999,39999,99,99,99,99,99,99,1,10,0,0,1000,0,6,5),(499,'@css01@【帝王战靴】（GM版）@css@','GM鞋子-所向披靡百战百胜（拾取绑定）',39999,39999,39999,39999,99,99,99,99,99,99,1,10,0,0,1000,0,6,6),(500,'@css01@【帝王项链】（GM版）@css@','GM项链-所向披靡百战百胜（拾取绑定）',39999,39999,39999,39999,99,99,99,99,99,99,1,10,0,0,1000,0,6,7),(501,'@css01@【帝王手镯】（GM版）@css@','GM手镯-所向披靡百战百胜（拾取绑定）',39999,39999,39999,39999,99,99,99,99,99,99,1,10,0,0,1000,0,6,8),(502,'@css01@【帝王婚戒】（GM版）@css@','GM婚戒-所向披靡百战百胜（拾取绑定）',39999,39999,39999,39999,99,99,99,99,99,99,1,10,0,0,1000,0,6,9),(503,'@css01@【帝王婚链】（GM版）@css@','GM婚链-所向披靡百战百胜（拾取绑定）',39999,39999,39999,39999,99,99,99,99,99,99,1,10,0,0,1000,0,6,10),(504,'【圣灵战甲】','传说诸神大战后留下的极品装备',0,0,0,5925,0,0,0,40,40,40,179,10,0,0,1000,0,6,4),(505,'【圣灵战盔】','传说诸神大战后留下的极品装备',0,7615,7615,7615,40,40,40,0,0,0,179,10,0,0,1000,0,6,5),(506,'【圣灵战靴】','传说诸神大战后留下的极品装备',0,6115,6115,6174,40,40,40,0,0,0,179,10,0,0,1000,0,6,6),(507,'【圣灵项链】','传说诸神大战后留下的极品装备',0,6284,6284,0,40,40,40,40,40,40,179,10,0,0,1000,0,6,7),(508,'【圣灵手镯】','传说诸神大战后留下的极品装备',0,6684,6684,0,40,40,40,40,40,40,179,10,0,0,1000,0,6,8),(509,'【圣灵枪】','传说诸神大战后留下的极品装备',0,9415,9415,0,40,40,40,0,0,0,179,10,0,0,1000,0,1,3),(510,'【圣灵叉】','传说诸神大战后留下的极品装备',0,9415,9415,0,40,40,40,0,0,0,179,10,0,0,1000,0,2,3),(511,'【圣灵棍】','传说诸神大战后留下的极品装备',0,9415,9415,0,40,40,40,0,0,0,179,10,0,0,1000,0,4,3),(512,'【圣灵仗】','传说诸神大战后留下的极品装备',0,9415,9415,0,40,40,40,0,0,0,179,10,0,0,1000,0,5,3),(513,'【圣灵剑】','传说诸神大战后留下的极品装备',0,9415,9415,0,40,40,40,0,0,0,179,10,0,0,1000,0,3,3),(514,'【圣灵战甲Ⅰ】','传说诸神大战后留下的极品装备',0,0,0,6525,0,0,0,42,42,42,179,10,0,0,1000,0,6,4),(515,'【圣灵战盔Ⅰ】','传说诸神大战后留下的极品装备',0,8215,8215,8215,42,42,42,0,0,0,179,10,0,0,1000,0,6,5),(516,'【圣灵战靴Ⅰ】','传说诸神大战后留下的极品装备',0,6715,6715,6774,42,42,42,0,0,0,179,10,0,0,1000,0,6,6),(517,'【圣灵项链Ⅰ】','传说诸神大战后留下的极品装备',0,6884,6884,0,42,42,42,42,42,42,179,10,0,0,1000,0,6,7),(518,'【圣灵手镯Ⅰ】','传说诸神大战后留下的极品装备',0,7284,7284,0,42,42,42,42,42,42,179,10,0,0,1000,0,6,8),(519,'【圣灵枪Ⅰ】','传说诸神大战后留下的极品装备',0,10015,10015,0,42,42,42,0,0,0,179,10,0,0,1000,0,1,3),(520,'【圣灵叉Ⅰ】','传说诸神大战后留下的极品装备',0,10015,10015,0,42,42,42,0,0,0,179,10,0,0,1000,0,2,3),(521,'【圣灵棍Ⅰ】','传说诸神大战后留下的极品装备',0,10015,10015,0,42,42,42,0,0,0,179,10,0,0,1000,0,4,3),(522,'【圣灵仗Ⅰ】','传说诸神大战后留下的极品装备',0,10015,10015,0,42,42,42,0,0,0,179,10,0,0,1000,0,5,3),(523,'【圣灵剑Ⅰ】','传说诸神大战后留下的极品装备',0,10015,10015,0,42,42,42,0,0,0,179,10,0,0,1000,0,3,3),(524,'【圣灵战甲ⅠⅠ】','传说诸神大战后留下的极品装备',0,0,0,7125,0,0,0,44,44,44,179,10,0,0,1000,0,6,4),(525,'【圣灵战盔ⅠⅠ】','传说诸神大战后留下的极品装备',0,8815,8815,8815,44,44,44,0,0,0,179,10,0,0,1000,0,6,5),(526,'【圣灵战靴ⅠⅠ】','传说诸神大战后留下的极品装备',0,7315,7315,7374,44,44,44,0,0,0,179,10,0,0,1000,0,6,6),(527,'【圣灵项链ⅠⅠ】','传说诸神大战后留下的极品装备',0,7484,7484,0,44,44,44,44,44,44,179,10,0,0,1000,0,6,7),(528,'【圣灵手镯ⅠⅠ】','传说诸神大战后留下的极品装备',0,7884,7884,0,44,44,44,44,44,44,179,10,0,0,1000,0,6,8),(529,'【圣灵枪ⅠⅠ】','传说诸神大战后留下的极品装备',0,10615,10615,0,44,44,44,0,0,0,179,10,0,0,1000,0,1,3),(530,'【圣灵叉ⅠⅠ】','传说诸神大战后留下的极品装备',0,10615,10615,0,44,44,44,0,0,0,179,10,0,0,1000,0,2,3),(531,'【圣灵棍ⅠⅠ】','传说诸神大战后留下的极品装备',0,10615,10615,0,44,44,44,0,0,0,179,10,0,0,1000,0,4,3),(532,'【圣灵仗ⅠⅠ】','传说诸神大战后留下的极品装备',0,10615,10615,0,44,44,44,0,0,0,179,10,0,0,1000,0,5,3),(533,'【圣灵剑ⅠⅠ】','传说诸神大战后留下的极品装备',0,10615,10615,0,44,44,44,0,0,0,179,10,0,0,1000,0,3,3),(534,'【圣灵战甲ⅠⅠⅠ】','传说诸神大战后留下的极品装备',0,0,0,8025,0,0,0,45,45,45,179,10,0,0,1000,0,6,4),(535,'【圣灵战盔ⅠⅠⅠ】','传说诸神大战后留下的极品装备',0,9415,9415,9415,45,45,45,0,0,0,179,10,0,0,1000,0,6,5),(536,'【圣灵战靴ⅠⅠⅠ】','传说诸神大战后留下的极品装备',0,7315,7315,7374,45,45,45,0,0,0,179,10,0,0,1000,0,6,6),(537,'【圣灵项链ⅠⅠⅠ】','传说诸神大战后留下的极品装备',0,8084,8084,0,45,45,45,45,45,45,179,10,0,0,1000,0,6,7),(538,'【圣灵手镯ⅠⅠⅠ】','传说诸神大战后留下的极品装备',0,8484,8484,0,45,45,45,45,45,45,179,10,0,0,1000,0,6,8),(539,'【圣灵枪ⅠⅠⅠ】','传说诸神大战后留下的极品装备',0,11515,11515,0,45,45,45,0,0,0,179,10,0,0,1000,0,1,3),(540,'【圣灵叉ⅠⅠⅠ】','传说诸神大战后留下的极品装备',0,11515,11515,0,45,45,45,0,0,0,179,10,0,0,1000,0,2,3),(541,'【圣灵棍ⅠⅠⅠ】','传说诸神大战后留下的极品装备',0,11515,11515,0,45,45,45,0,0,0,179,10,0,0,1000,0,4,3),(542,'【圣灵仗ⅠⅠⅠ】','传说诸神大战后留下的极品装备',0,11515,11515,0,45,45,45,0,0,0,179,10,0,0,1000,0,5,3),(543,'【圣灵剑ⅠⅠⅠ】','传说诸神大战后留下的极品装备',0,11515,11515,0,45,45,45,0,0,0,179,10,0,0,1000,0,3,3),(544,'【圣灵☯天元甲】','传说诸神大战后留下的极品装备',0,0,0,9525,0,0,0,50,50,50,179,10,0,0,1000,0,6,4),(545,'【圣灵☯天元盔】','传说诸神大战后留下的极品装备',0,10015,10015,10015,50,50,50,0,0,0,179,10,0,0,1000,0,6,5),(546,'【圣灵☯天元靴】','传说诸神大战后留下的极品装备',0,8815,8815,8874,50,50,50,0,0,0,179,10,0,0,1000,0,6,6),(547,'【圣灵☯天元链】','传说诸神大战后留下的极品装备',0,10084,10084,0,50,50,50,50,50,50,179,10,0,0,1000,0,6,7),(548,'【圣灵☯天元镯】','传说诸神大战后留下的极品装备',0,10084,10084,0,50,50,50,50,50,50,179,10,0,0,1000,0,6,8),(549,'【圣灵☯天元枪】','传说诸神大战后留下的极品装备',0,13015,13015,0,50,50,50,0,0,0,179,10,0,0,1000,0,1,3),(550,'【圣灵☯天元叉】','传说诸神大战后留下的极品装备',0,13015,13015,0,50,50,50,0,0,0,179,10,0,0,1000,0,2,3),(551,'【圣灵☯天元棍】','传说诸神大战后留下的极品装备',0,13015,13015,0,50,50,50,0,0,0,179,10,0,0,1000,0,4,3),(552,'【圣灵☯天元仗】','传说诸神大战后留下的极品装备',0,13015,13015,0,50,50,50,0,0,0,179,10,0,0,1000,0,5,3),(553,'【圣灵☯天元剑】','传说诸神大战后留下的极品装备',0,13015,13015,0,50,50,50,0,0,0,179,10,0,0,1000,0,3,3),(554,'【海枯石烂】（婚戒）','【海枯石烂】（婚戒）象征着彼此相爱恋人的信物',14258,4652,4652,4045,15,15,15,15,15,15,159,10,0,0,1000,0,6,9),(555,'【海枯石烂】（婚链）','【海枯石烂】（婚链）象征着彼此相爱恋人的信物',14258,4652,4652,4045,15,15,15,15,15,15,159,10,0,0,1000,0,6,10),(556,'【天作之合】（婚戒）','【天作之合】（婚戒）象征着彼此相爱恋人的信物',15058,5052,5052,4676,20,20,20,20,20,20,179,10,0,0,1000,0,6,9),(557,'【天作之合】（婚链）','【天作之合】（婚链）象征着彼此相爱恋人的信物',15058,5052,5052,4676,20,20,20,20,20,20,179,10,0,0,1000,0,6,10),(558,'【一生所爱の婚戒】（典藏版）','【一生所爱の婚戒】（典藏版）挚爱一生你值得拥有~~~',30000,10000,10000,10000,30,30,30,30,30,30,179,10,0,0,1000,0,6,9),(559,'【一生所爱の婚链】（典藏版）','【一生所爱の婚链】（典藏版）挚爱一生你值得拥有~~~',30000,10000,10000,10000,30,30,30,30,30,30,179,10,0,0,1000,0,6,10),(560,'【恋人未满の婚戒】（靛蓝版）','【恋人未满の婚戒】（靛蓝版）挚爱一生你值得拥有~~~',30000,5052,10000,10000,30,30,30,30,30,30,179,10,0,0,1000,0,6,9),(561,'【恋人未满の婚链】（靛蓝版）','【恋人未满の婚链】（靛蓝版）挚爱一生你值得拥有~~~',30000,5052,10000,10000,30,30,30,30,30,30,179,10,0,0,1000,0,6,10),(562,'【镇东神兽】青龙☯仙','【镇东神兽】青龙☯仙-十分威风的仙品坐骑',41555,5522,5522,4159,25,25,25,25,25,25,159,10,0,0,1000,0,6,2),(563,'【镇东神兽】白虎☯仙','【镇东神兽】白虎☯仙-十分威风的仙品坐骑',12888,7859,5522,4159,25,25,25,25,25,25,159,10,0,0,1000,0,6,2),(564,'【镇东神兽】朱雀☯仙','【镇东神兽】朱雀☯仙-十分威风的仙品坐骑',12888,5522,7859,4159,25,25,25,25,25,25,159,10,0,0,1000,0,6,2),(565,'【镇东神兽】玄武☯仙','【镇东神兽】玄武☯仙-十分威风的仙品坐骑',12888,5522,5522,7842,25,25,25,25,25,25,159,10,0,0,1000,0,6,2),(566,'【筋斗云】☯（血）','【筋斗云】☯（血）身披金甲圣衣、驾着七彩祥云',51555,6522,6522,5159,30,30,30,30,30,30,179,10,0,0,1000,0,6,2),(567,'【筋斗云】☯（攻）','【筋斗云】☯（攻）身披金甲圣衣、驾着七彩祥云',15999,8859,6522,5159,30,30,30,30,30,30,179,10,0,0,1000,0,6,2),(568,'【筋斗云】☯（魔）','【筋斗云】☯（魔）身披金甲圣衣、驾着七彩祥云',15999,6522,8859,5159,30,30,30,30,30,30,179,10,0,0,1000,0,6,2),(569,'【筋斗云】☯（防）','【筋斗云】☯（防）身披金甲圣衣、驾着七彩祥云',15999,6522,6522,8842,30,30,30,30,30,30,179,10,0,0,1000,0,6,2),(570,'【侠士披风】','侠士常用的披风解释耐用',0,2155,2155,2015,5,5,5,5,5,5,60,10,0,0,1000,0,6,11),(572,'【锦缎披风】','锦缎所制，纹理细密，价值不菲',0,3125,3125,2458,10,10,10,10,10,10,99,10,0,0,1000,0,6,11),(573,'【恶魔披风】','用恶魔的鲜血铸造而成',0,3758,3758,3058,15,15,15,15,15,15,109,10,0,0,1000,0,6,11),(574,'【王者披风】','一代绝世王者的披风',0,4258,4258,3788,20,20,20,20,20,20,139,10,0,0,1000,0,6,11),(575,'【金甲披风】','战无不胜，光彩依旧',0,5058,5058,4888,30,30,30,30,30,30,159,10,0,0,1000,0,6,11),(576,'【大圣披风】','仙气环绕，光彩夺目，非凡间之物，极为少有',0,6099,6099,5725,35,35,35,35,35,35,179,10,0,0,1000,0,6,11),(577,'【冠绝天下】（典藏版）','千金难觅,更是世间少有',8888,8888,8888,8888,40,40,40,40,40,40,179,10,0,0,1000,0,6,11),(578,'【噬魂仙甲】','传说诸神大战后留下的极品装备',0,0,0,12258,0,0,0,60,60,60,199,10,0,0,1000,0,6,4),(579,'【噬魂仙盔】','传说诸神大战后留下的极品装备',0,12584,12584,12584,60,60,60,0,0,0,199,10,0,0,1000,0,6,5),(580,'【噬魂仙靴】','传说诸神大战后留下的极品装备',0,11587,11587,11587,60,60,60,0,0,0,199,10,0,0,1000,0,6,6),(581,'【噬魂仙链】','传说诸神大战后留下的极品装备',0,12584,12584,0,60,60,60,60,60,60,199,10,0,0,1000,0,6,7),(582,'【噬魂仙镯】','传说诸神大战后留下的极品装备',0,12458,12458,0,60,60,60,60,60,60,199,10,0,0,1000,0,6,8),(583,'【噬魂仙枪】','传说诸神大战后留下的极品装备',0,15015,15015,0,60,60,60,0,0,0,199,10,0,0,1000,0,1,3),(584,'【噬魂仙叉】','传说诸神大战后留下的极品装备',0,15015,15015,0,60,60,60,0,0,0,199,10,0,0,1000,0,2,3),(585,'【噬魂仙棍】','传说诸神大战后留下的极品装备',0,15015,15015,0,60,60,60,0,0,0,199,10,0,0,1000,0,4,3),(586,'【噬魂仙杖】','传说诸神大战后留下的极品装备',0,15015,15015,0,60,60,60,0,0,0,199,10,0,0,1000,0,5,3),(587,'【噬魂仙剑】','传说诸神大战后留下的极品装备',0,15015,15015,0,60,60,60,0,0,0,199,10,0,0,1000,0,3,3),(588,'【缘定今生の婚戒】（典藏版）','【缘定今生の婚戒】（典藏版）挚爱一生你值得拥有~~~',50000,20000,20000,20000,50,50,50,50,50,50,199,10,0,0,1000,0,6,9),(589,'【缘定今生の婚链】（典藏版）','【缘定今生の婚链】（典藏版）挚爱一生你值得拥有~~~',50000,20000,20000,20000,50,50,50,50,50,50,199,10,0,0,1000,0,6,10),(590,'【天赐良缘の婚戒】','【天赐良缘の婚戒】挚爱一生你值得拥有~~~',50000,20000,20000,20000,50,50,50,50,50,50,199,10,0,0,1000,0,6,9),(591,'【天赐良缘の婚链】','【天赐良缘の婚链】挚爱一生你值得拥有~~~',50000,20000,20000,20000,50,50,50,50,50,50,199,10,0,0,1000,0,6,10),(592,'【玄☯仙披风】','仙气环绕，光彩夺目，非凡间之物，极为少有',0,10245,10245,9451,50,50,50,50,50,50,199,10,0,0,1000,0,6,11),(593,'【帝王仙甲】','西游小皇帝专属装备',0,0,0,15258,0,0,0,70,70,70,200,10,0,0,1000,0,6,4),(594,'【帝王仙盔】','西游小皇帝专属装备',0,15584,15584,15584,70,70,70,0,0,0,200,10,0,0,1000,0,6,5),(595,'【帝王仙靴】','西游小皇帝专属装备',0,15587,15587,15587,70,70,70,0,0,0,200,10,0,0,1000,0,6,6),(596,'【帝王仙链】','西游小皇帝专属装备',0,15584,15584,0,70,70,70,70,70,70,200,10,0,0,1000,0,6,7),(597,'【帝王仙镯】','西游小皇帝专属装备',0,15458,15458,0,70,70,70,70,70,70,200,10,0,0,1000,0,6,8),(598,'【帝王仙枪】','西游小皇帝专属装备',0,19015,19015,0,70,70,70,0,0,0,200,10,0,0,1000,0,1,3),(599,'【帝王仙叉】','西游小皇帝专属装备',0,19015,19015,0,70,70,70,0,0,0,200,10,0,0,1000,0,2,3),(600,'【帝王仙棍】','西游小皇帝专属装备',0,19015,19015,0,70,70,70,0,0,0,200,10,0,0,1000,0,4,3),(601,'【帝王仙杖】','西游小皇帝专属装备',0,19015,19015,0,70,70,70,0,0,0,200,10,0,0,1000,0,5,3),(602,'【帝王仙剑】','西游小皇帝专属装备',0,19015,19015,0,70,70,70,0,0,0,200,10,0,0,1000,0,3,3),(603,'【镇东神兽】青龙☯神','【镇东神兽】青龙☯神-十分威风的神品坐骑',46555,7522,7522,7159,30,30,30,30,30,30,179,10,0,0,1000,0,6,2),(604,'【镇东神兽】白虎☯神','【镇东神兽】白虎☯神-十分威风的神品坐骑',18888,11859,7522,6159,30,30,30,30,30,30,179,10,0,0,1000,0,6,2),(605,'【镇东神兽】朱雀☯神','【镇东神兽】朱雀☯神-十分威风的神品坐骑',18888,7522,11859,6159,30,30,30,30,30,30,179,10,0,0,1000,0,6,2),(606,'【镇东神兽】玄武☯神','【镇东神兽】玄武☯神-十分威风的神品坐骑',18888,7522,7522,11859,30,30,30,30,30,30,179,10,0,0,1000,0,6,2),(607,'【镇东至尊兽】青龙☯至尊','【镇东至尊兽】青龙☯至尊-十分威风的至尊-坐骑',66555,9522,9522,9159,40,40,40,40,40,40,199,10,0,0,1000,0,6,2),(608,'【镇东至尊兽】白虎☯至尊','【镇东至尊兽】白虎☯至尊-十分威风的至尊-坐骑',28888,16859,9522,8159,40,40,40,40,40,40,199,10,0,0,1000,0,6,2),(609,'【镇东至尊兽】朱雀☯至尊','【镇东至尊兽】朱雀☯至尊-十分威风的至尊-坐骑',28888,9522,16859,8159,40,40,40,40,40,40,199,10,0,0,1000,0,6,2),(610,'【镇东至尊兽】玄武☯至尊','【镇东至尊兽】玄武☯至尊-十分威风的至尊-坐骑',28888,9522,9522,16859,40,40,40,40,40,40,199,10,0,0,1000,0,6,2),(611,'【天尊神兽】（青龙）','【天尊神兽】（青龙）-十分威风的天尊-坐骑',108970,11522,11522,11159,50,50,50,50,50,50,200,10,0,0,1000,0,6,2),(612,'【天尊神兽】（白虎）','【天尊神兽】（白虎）-十分威风的天尊-坐骑',38888,20859,11522,11522,50,50,50,50,50,50,200,10,0,0,1000,0,6,2),(613,'【天尊神兽】（朱雀）','【天尊神兽】（朱雀）-十分威风的天尊-坐骑',38888,11522,20859,11522,50,50,50,50,50,50,200,10,0,0,1000,0,6,2),(614,'【天尊神兽】（玄武）','【天尊神兽】（玄武）-十分威风的天尊-坐骑',38888,11522,11522,20859,50,50,50,50,50,50,200,10,0,0,1000,0,6,2),(615,'【天仙之恋の婚戒】','【天仙之恋の婚戒】挚爱一生你值得拥有~~~',60000,30000,30000,30000,60,60,60,60,60,60,200,10,0,0,1000,0,6,9),(616,'【天仙之恋の婚链】','【天仙之恋の婚链】挚爱一生你值得拥有~~~',60000,30000,30000,30000,60,60,60,60,60,60,200,10,0,0,1000,0,6,10),(617,'【天尊之恋の婚戒】（典藏版）','【天尊之恋の婚戒】（典藏版）挚爱一生你值得拥有~~~',70000,30000,30000,30000,60,60,60,60,60,60,200,10,0,0,1000,0,6,9),(618,'【天尊之恋の婚链】（典藏版）','【天尊之恋の婚链】（典藏版）挚爱一生你值得拥有~~~',70000,30000,30000,30000,60,60,60,60,60,60,200,10,0,0,1000,0,6,10),(619,'【天尊の披风】','仙气环绕，光彩夺目，非凡间之物，极为少有',0,15245,15245,14451,60,60,60,60,60,60,200,10,0,0,1000,0,6,11),(620,'【如意金箍棒】（20级）','【如意金箍棒】号令天下，谁敢不从，能够自动收缩抽打敌人',400000,30000,30000,30000,99,99,99,99,99,99,200,10,0,0,1000,0,6,1),(621,'@css01@【小恶魔の魔翼】（时装）@css@','时装位置：翅膀【小恶魔の魔翼】（1级时装）',60000,30000,30000,30000,100,100,100,100,100,100,1,10,0,0,1000,0,6,12),(622,'@css01@【小恶魔の魔杖】（时装）@css@','时装位置：武器【小恶魔の魔杖】（1级时装）',60000,30000,30000,30000,100,100,100,100,100,100,1,10,0,0,1000,0,6,13),(623,'@css01@【小恶魔の魔盾】（时装）@css@','时装位置：副手【小恶魔の魔盾】（1级时装）',60000,30000,30000,30000,100,100,100,100,100,100,1,10,0,0,1000,0,6,14),(624,'@css01@【小恶魔の魔镜】（时装）@css@','时装位置：面具【小恶魔の魔镜】（1级时装）',60000,30000,30000,30000,100,100,100,100,100,100,1,10,0,0,1000,0,6,15),(625,'@css01@【小恶魔の魔服】（时装）@css@','时装位置：衣服【小恶魔の魔服】（1级时装）',60000,30000,30000,30000,100,100,100,100,100,100,1,10,0,0,1000,0,6,16),(626,'@css01@【小恶魔の魔靴】（时装）@css@','时装位置：鞋子【小恶魔の魔靴】（1级时装）',60000,30000,30000,30000,100,100,100,100,100,100,1,10,0,0,1000,0,6,17),(627,'@css01@【小恶魔の魔戒】（时装）@css@','时装位置：戒指【小恶魔の魔戒】（1级时装）',60000,30000,30000,30000,100,100,100,100,100,100,1,10,0,0,1000,0,6,18),(628,'@css01@【小恶魔の魔链】（时装）@css@','时装位置：项链【小恶魔の魔链】（1级时装）',60000,30000,30000,30000,100,100,100,100,100,100,1,10,0,0,1000,0,6,19),(629,'@css01@【小恶魔の魔袍】（时装）@css@','时装位置：披风【小恶魔の魔袍】（1级时装）',60000,30000,30000,30000,100,100,100,100,100,100,1,10,0,0,1000,0,6,20),(630,'@css01@【小恶魔の十字勋章】（时装）@css@','时装位置：勋章【小恶魔の十字勋章】（1级时装）',60000,30000,30000,30000,100,100,100,100,100,100,1,10,0,0,1000,0,6,21),(631,'@css01@【小天使の神翼】（时装）@css@','时装位置：翅膀【小天使の神翼】（2级时装）',80000,50000,50000,50000,150,150,150,150,150,150,1,10,0,0,1000,0,6,12),(632,'@css01@【小天使の神杖】（时装）@css@','时装位置：武器【小天使の神杖】（2级时装）',80000,50000,50000,50000,150,150,150,150,150,150,1,10,0,0,1000,0,6,13),(633,'@css01@【小天使の神盾】（时装）@css@','时装位置：副手【小天使の神盾】（2级时装）',80000,50000,50000,50000,150,150,150,150,150,150,1,10,0,0,1000,0,6,14),(634,'@css01@【小天使の神镜】（时装）@css@','时装位置：面具【小天使の神镜】（2级时装）',80000,50000,50000,50000,150,150,150,150,150,150,1,10,0,0,1000,0,6,15),(635,'@css01@【小天使の神服】（时装）@css@','时装位置：衣服【小天使の神服】（2级时装）',80000,50000,50000,50000,150,150,150,150,150,150,1,10,0,0,1000,0,6,16),(636,'@css01@【小天使の神靴】（时装）@css@','时装位置：鞋子【小天使の神靴】（2级时装）',80000,50000,50000,50000,150,150,150,150,150,150,1,10,0,0,1000,0,6,17),(637,'@css01@【小天使の神戒】（时装）@css@','时装位置：戒指【小天使の神戒】（2级时装）',80000,50000,50000,50000,150,150,150,150,150,150,1,10,0,0,1000,0,6,18),(638,'@css01@【小天使の神链】（时装）@css@','时装位置：项链【小天使の神链】（2级时装）',80000,50000,50000,50000,150,150,150,150,150,150,1,10,0,0,1000,0,6,19),(639,'@css01@【小天使の神袍】（时装）@css@','时装位置：披风【小天使の神袍】（2级时装）',80000,50000,50000,50000,150,150,150,150,150,150,1,10,0,0,1000,0,6,20),(640,'@css01@【小天使の烈火灼魂】（时装）@css@','时装位置：勋章【小天使の烈火灼魂】（2级时装）',80000,50000,50000,50000,150,150,150,150,150,150,1,10,0,0,1000,0,6,21),(641,'@css01@【黑骑士の火翼】（时装）@css@','时装位置：翅膀【黑骑士の火翼】（3级时装）',100000,70000,70000,70000,200,200,200,200,200,200,1,10,0,0,1000,0,6,12),(642,'@css01@【黑骑士の火杖】（时装）@css@','时装位置：武器【黑骑士の火杖】（3级时装）',100000,70000,70000,70000,200,200,200,200,200,200,1,10,0,0,1000,0,6,13),(643,'@css01@【黑骑士の火盾】（时装）@css@','时装位置：副手【黑骑士の火盾】（3级时装）',100000,70000,70000,70000,200,200,200,200,200,200,1,10,0,0,1000,0,6,14),(644,'@css01@【黑骑士の火镜】（时装）@css@','时装位置：面具【黑骑士の火镜】（3级时装）',100000,70000,70000,70000,200,200,200,200,200,200,1,10,0,0,1000,0,6,15),(645,'@css01@【黑骑士の火服】（时装）@css@','时装位置：衣服【黑骑士の火服】（3级时装）',100000,70000,70000,70000,200,200,200,200,200,200,1,10,0,0,1000,0,6,16),(646,'@css01@【黑骑士の火靴】（时装）@css@','时装位置：鞋子【黑骑士の火靴】（3级时装）',100000,70000,70000,70000,200,200,200,200,200,200,1,10,0,0,1000,0,6,17),(647,'@css01@【黑骑士の火戒】（时装）@css@','时装位置：戒指【黑骑士の火戒】（3级时装）',100000,70000,70000,70000,200,200,200,200,200,200,1,10,0,0,1000,0,6,18),(648,'@css01@【黑骑士の火链】（时装）@css@','时装位置：项链【黑骑士の火链】（3级时装）',100000,70000,70000,70000,200,200,200,200,200,200,1,10,0,0,1000,0,6,19),(649,'@css01@【黑骑士の火袍】（时装）@css@','时装位置：披风【黑骑士の火袍】（3级时装）',100000,70000,70000,70000,200,200,200,200,200,200,1,10,0,0,1000,0,6,20),(650,'@css01@【黑骑士の三角勋章】（时装）@css@','时装位置：勋章【黑骑士の三角勋章】（3级时装）',100000,70000,70000,70000,200,200,200,200,200,200,1,10,0,0,1000,0,6,21),(651,'@css01@【猎天使の天灵羽】（时装）@css@','时装位置：翅膀【猎天使の天灵羽】（4级时装）',120000,90000,90000,90000,250,250,250,250,250,250,1,10,0,0,1000,0,6,12),(652,'@css01@【猎天使の天灵镰】（时装）@css@','时装位置：武器【猎天使の天灵镰】（4级时装）',120000,90000,90000,90000,250,250,250,250,250,250,1,10,0,0,1000,0,6,13),(653,'@css01@【猎天使の天灵盾】（时装）@css@','时装位置：副手【猎天使の天灵盾】（4级时装）',120000,90000,90000,90000,250,250,250,250,250,250,1,10,0,0,1000,0,6,14),(654,'@css01@【猎天使の天灵镜】（时装）@css@','时装位置：面具【猎天使の天灵镜】（4级时装）',120000,90000,90000,90000,250,250,250,250,250,250,1,10,0,0,1000,0,6,15),(655,'@css01@【猎天使の天灵服】（时装）@css@','时装位置：衣服【猎天使の天灵服】（4级时装）',120000,90000,90000,90000,250,250,250,250,250,250,1,10,0,0,1000,0,6,16),(656,'@css01@【猎天使の天灵靴】（时装）@css@','时装位置：鞋子【猎天使の天灵靴】（4级时装）',120000,90000,90000,90000,250,250,250,250,250,250,1,10,0,0,1000,0,6,17),(657,'@css01@【猎天使の天灵戒】（时装）@css@','时装位置：戒指【猎天使の天灵戒】（4级时装）',120000,90000,90000,90000,250,250,250,250,250,250,1,10,0,0,1000,0,6,18),(658,'@css01@【猎天使の天灵链】（时装）@css@','时装位置：项链【猎天使の天灵链】（4级时装）',120000,90000,90000,90000,250,250,250,250,250,250,1,10,0,0,1000,0,6,19),(659,'@css01@【猎天使の天灵袍】（时装）@css@','时装位置：披风【猎天使の天灵袍】（4级时装）',120000,90000,90000,90000,250,250,250,250,250,250,1,10,0,0,1000,0,6,20),(660,'@css01@【猎天使の星辰勋章】（时装）@css@','时装位置：勋章【猎天使の星辰勋章】（4级时装）',120000,90000,90000,90000,250,250,250,250,250,250,1,10,0,0,1000,0,6,21),(661,'@css01@【死神の星海翼】（时装）@css@','时装位置：翅膀【死神の星海翼】（5级时装）',140000,110000,110000,110000,300,300,300,300,300,300,1,10,0,0,1000,0,6,12),(662,'@css01@【死神の星海镰】（时装）@css@','时装位置：武器【死神の星海镰】（5级时装）',140000,110000,110000,110000,300,300,300,300,300,300,1,10,0,0,1000,0,6,13),(663,'@css01@【死神の星海盾】（时装）@css@','时装位置：副手【死神の星海盾】（5级时装）',140000,110000,110000,110000,300,300,300,300,300,300,1,10,0,0,1000,0,6,14),(664,'@css01@【死神の星海镜】（时装）@css@','时装位置：面具【死神の星海镜】（5级时装）',140000,110000,110000,110000,300,300,300,300,300,300,1,10,0,0,1000,0,6,15),(665,'@css01@【死神の星海服】（时装）@css@','时装位置：衣服【死神の星海服】',140000,110000,110000,110000,300,300,300,300,300,300,1,10,0,0,1000,0,6,16),(666,'@css01@【死神の星海靴】（时装）@css@','时装位置：鞋子【死神の星海靴】（5级时装）',140000,110000,110000,110000,300,300,300,300,300,300,1,10,0,0,1000,0,6,17),(667,'@css01@【死神の星海戒】（时装）@css@','时装位置：戒指【死神の星海戒】（5级时装）',140000,110000,110000,110000,300,300,300,300,300,300,1,10,0,0,1000,0,6,18),(668,'@css01@【死神の星海链】（时装）@css@','时装位置：项链【死神の星海链】（5级时装）',140000,110000,110000,110000,300,300,300,300,300,300,1,10,0,0,1000,0,6,19),(669,'@css01@【死神の星海袍】（时装）@css@','时装位置：披风【死神の星海袍】（5级时装）',140000,110000,110000,110000,300,300,300,300,300,300,1,10,0,0,1000,0,6,20),(670,'@css01@【死神の无尽勋章】（时装）@css@','时装位置：勋章【死神の无尽勋章】（5级时装）',140000,110000,110000,110000,300,300,300,300,300,300,1,10,0,0,1000,0,6,21),(671,'【仙尊甲】','西游仙级装备',0,0,0,20258,0,0,0,80,80,80,220,10,0,0,1000,0,6,4),(672,'【仙尊盔】','西游仙级装备',0,20584,20584,20584,80,80,80,0,0,0,220,10,0,0,1000,0,6,5),(673,'【仙尊靴】','西游仙级装备',0,20587,20587,20587,80,80,80,0,0,0,220,10,0,0,1000,0,6,6),(674,'【仙尊链】','西游仙级装备',0,20584,20584,0,80,80,80,80,80,80,220,10,0,0,1000,0,6,7),(675,'【仙尊镯】','西游仙级装备',0,20458,20458,0,80,80,80,80,80,80,220,10,0,0,1000,0,6,8),(676,'【仙尊枪】','西游仙级装备',0,24015,24015,0,80,80,80,0,0,0,220,10,0,0,1000,0,1,3),(677,'【仙尊叉】','西游仙级装备',0,24015,24015,0,80,80,80,0,0,0,220,10,0,0,1000,0,2,3),(678,'【仙尊棍】','西游仙级装备',0,24015,24015,0,80,80,80,0,0,0,220,10,0,0,1000,0,4,3),(679,'【仙尊杖】','西游仙级装备',0,24015,24015,0,80,80,80,0,0,0,220,10,0,0,1000,0,5,3),(680,'【仙尊剑】','西游仙级装备',0,24015,24015,0,80,80,80,0,0,0,220,10,0,0,1000,0,3,3),(681,'【神尊甲】','西游神级装备',0,0,0,26258,0,0,0,99,99,99,230,10,0,0,1000,0,6,4),(682,'【神尊盔】','西游神级装备',0,26584,26584,26584,99,99,99,0,0,0,230,10,0,0,1000,0,6,5),(683,'【神尊靴】','西游神级装备',0,26587,26587,26587,99,99,99,0,0,0,230,10,0,0,1000,0,6,6),(684,'【神尊链】','西游神级装备',0,26584,26584,0,99,99,99,99,99,99,230,10,0,0,1000,0,6,7),(685,'【神尊镯】','西游神级装备',0,26458,26458,0,99,99,99,99,99,99,230,10,0,0,1000,0,6,8),(686,'【神尊枪】','西游神级装备',0,30015,30015,0,99,99,99,0,0,0,230,10,0,0,1000,0,1,3),(687,'【神尊叉】','西游神级装备',0,30015,30015,0,99,99,99,0,0,0,230,10,0,0,1000,0,2,3),(688,'【神尊棍】','西游神级装备',0,30015,30015,0,99,99,99,0,0,0,230,10,0,0,1000,0,4,3),(689,'【神尊杖】','西游神级装备',0,30015,30015,0,99,99,99,0,0,0,230,10,0,0,1000,0,5,3),(690,'【神尊剑】','西游神级装备',0,30015,30015,0,99,99,99,0,0,0,230,10,0,0,1000,0,3,3),(691,'【圣尊甲】','西游圣级装备',33584,37015,37015,33584,109,109,109,109,109,109,1,10,0,0,1000,0,6,4),(692,'【圣尊盔】','西游圣级装备',33584,37015,37015,33584,109,109,109,109,109,109,1,10,0,0,1000,0,6,5),(693,'【圣尊靴】','西游圣级装备',33584,37015,37015,33584,109,109,109,109,109,109,1,10,0,0,1000,0,6,6),(694,'【圣尊链】','西游圣级装备',33584,37015,37015,33584,109,109,109,109,109,109,1,10,0,0,1000,0,6,7),(695,'【圣尊镯】','西游圣级装备',33584,37015,37015,33584,109,109,109,109,109,109,1,10,0,0,1000,0,6,8),(696,'【圣尊枪】','西游圣级装备',33584,37015,37015,33584,109,109,109,109,109,109,1,10,0,0,1000,0,1,3),(697,'【圣尊叉】','西游圣级装备',33584,37015,37015,33584,109,109,109,109,109,109,1,10,0,0,1000,0,2,3),(698,'【圣尊棍】','西游圣级装备',33584,37015,37015,33584,109,109,109,109,109,109,1,10,0,0,1000,0,4,3),(699,'【圣尊杖】','西游圣级装备',33584,37015,37015,33584,109,109,109,109,109,109,1,10,0,0,1000,0,5,3),(700,'【圣尊剑】','西游圣级装备',33584,37015,37015,33584,109,109,109,109,109,109,1,10,0,0,1000,0,3,3),(701,'@css01@【混沌天尊の甲】@css@','西游混沌天级装备',71584,71584,71584,71584,159,159,159,159,159,159,1,10,0,0,1000,0,6,4),(702,'@css01@【混沌天尊の盔】@css@','西游混沌天级装备',71584,71584,71584,71584,159,159,159,159,159,159,1,10,0,0,1000,0,6,5),(703,'@css01@【混沌天尊の靴】@css@','西游混沌天级装备',71584,71584,71584,71584,159,159,159,159,159,159,1,10,0,0,1000,0,6,6),(704,'@css01@【混沌天尊の链】@css@','西游混沌天级装备',71584,71584,71584,71584,159,159,159,159,159,159,1,10,0,0,1000,0,6,7),(705,'@css01@【混沌天尊の镯】@css@','西游混沌天级装备',71584,71584,71584,71584,159,159,159,159,159,159,1,10,0,0,1000,0,6,8),(706,'@css01@【混沌天尊の枪】@css@','西游混沌天级装备',81584,81584,81584,81584,159,159,159,159,159,159,1,10,0,0,1000,0,1,3),(707,'@css01@【混沌天尊の叉】@css@','西游混沌天级装备',81584,81584,81584,81584,159,159,159,159,159,159,1,10,0,0,1000,0,2,3),(708,'@css01@【混沌天尊の棍】@css@','西游混沌天级装备',81584,81584,81584,81584,159,159,159,159,159,159,1,10,0,0,1000,0,4,3),(709,'@css01@【混沌天尊の杖】@css@','西游混沌天级装备',81584,81584,81584,81584,159,159,159,159,159,159,1,10,0,0,1000,0,5,3),(710,'@css01@【混沌天尊の剑】@css@','西游混沌天级装备',81584,81584,81584,81584,159,159,159,159,159,159,1,10,0,0,1000,0,3,3),(711,'@css02@【混沌神尊の甲】@css@','西游混沌神级装备',110584,110584,110584,110584,209,209,209,209,209,209,1,10,0,0,1000,0,6,4),(712,'@css02@【混沌神尊の盔】@css@','西游混沌神级装备',110584,110584,110584,110584,209,209,209,209,209,209,1,10,0,0,1000,0,6,5),(713,'@css02@【混沌神尊の靴】@css@','西游混沌神级装备',110584,110584,110584,110584,209,209,209,209,209,209,1,10,0,0,1000,0,6,6),(714,'@css02@【混沌神尊の链】@css@','西游混沌神级装备',110584,110584,110584,110584,209,209,209,209,209,209,1,10,0,0,1000,0,6,7),(715,'@css02@【混沌神尊の镯】@css@','西游混沌神级装备',110584,110584,110584,110584,209,209,209,209,209,209,1,10,0,0,1000,0,6,8),(716,'@css02@【混沌神尊の枪】@css@','西游混沌神级装备',130584,130584,130584,130584,209,209,209,209,209,209,1,10,0,0,1000,0,1,3),(717,'@css02@【混沌神尊の叉】@css@','西游混沌神级装备',130584,130584,130584,130584,209,209,209,209,209,209,1,10,0,0,1000,0,2,3),(718,'@css02@【混沌神尊の棍】@css@','西游混沌神级装备',130584,130584,130584,130584,209,209,209,209,209,209,1,10,0,0,1000,0,4,3),(719,'@css02@【混沌神尊の杖】@css@','西游混沌神级装备',130584,130584,130584,130584,209,209,209,209,209,209,1,10,0,0,1000,0,5,3),(720,'@css02@【混沌神尊の剑】@css@','西游混沌神级装备',130584,130584,130584,130584,209,209,209,209,209,209,1,10,0,0,1000,0,3,3),(721,'@css03@【混沌圣尊の甲】@css@','西游混沌圣级装备',160258,160258,160258,160258,259,259,259,259,259,259,1,10,0,0,1000,0,6,4),(722,'@css03@【混沌圣尊の盔】@css@','西游混沌圣级装备',160258,160258,160258,160258,259,259,259,259,259,259,1,10,0,0,1000,0,6,5),(723,'@css03@【混沌圣尊の靴】@css@','西游混沌圣级装备',160258,160258,160258,160258,259,259,259,259,259,259,1,10,0,0,1000,0,6,6),(724,'@css03@【混沌圣尊の链】@css@','西游混沌圣级装备',160258,160258,160258,160258,259,259,259,259,259,259,1,10,0,0,1000,0,6,7),(725,'@css03@【混沌圣尊の镯】@css@','西游混沌圣级装备',160258,160258,160258,160258,259,259,259,259,259,259,1,10,0,0,1000,0,6,8),(726,'@css03@【混沌圣尊の枪】@css@','西游混沌圣级装备',180258,180258,180258,180258,259,259,259,259,259,259,1,10,0,0,1000,0,1,3),(727,'@css03@【混沌圣尊の叉】@css@','西游混沌圣级装备',180258,180258,180258,180258,259,259,259,259,259,259,1,10,0,0,1000,0,2,3),(728,'@css03@【混沌圣尊の棍】@css@','西游混沌圣级装备',180258,180258,180258,180258,259,259,259,259,259,259,1,10,0,0,1000,0,4,3),(729,'@css03@【混沌圣尊の杖】@css@','西游混沌圣级装备',180258,180258,180258,180258,259,259,259,259,259,259,1,10,0,0,1000,0,5,3),(730,'@css03@【混沌圣尊の剑】@css@','西游混沌圣级装备',180258,180258,180258,180258,259,259,259,259,259,259,1,10,0,0,1000,0,3,3),(731,'@css04@【鸿蒙天尊の甲】@css@','西游鸿蒙天级装备',211584,211584,211584,211584,309,309,309,309,309,309,1,10,0,0,1000,0,6,4),(732,'@css04@【鸿蒙天尊の盔】@css@','西游鸿蒙天级装备',211584,211584,211584,211584,309,309,309,309,309,309,1,10,0,0,1000,0,6,5),(733,'@css04@【鸿蒙天尊の靴】@css@','西游鸿蒙天级装备',211584,211584,211584,211584,309,309,309,309,309,309,1,10,0,0,1000,0,6,6),(734,'@css04@【鸿蒙天尊の链】@css@','西游鸿蒙天级装备',211584,211584,211584,211584,309,309,309,309,309,309,1,10,0,0,1000,0,6,7),(735,'@css04@【鸿蒙天尊の镯】@css@','西游鸿蒙天级装备',211584,211584,211584,211584,309,309,309,309,309,309,1,10,0,0,1000,0,6,8),(736,'@css04@【鸿蒙天尊の枪】@css@','西游鸿蒙天级装备',231584,231584,231584,231584,309,309,309,309,309,309,1,10,0,0,1000,0,1,3),(737,'@css04@【鸿蒙天尊の叉】@css@','西游鸿蒙天级装备',231584,231584,231584,231584,309,309,309,309,309,309,1,10,0,0,1000,0,2,3),(738,'@css04@【鸿蒙天尊の棍】@css@','西游鸿蒙天级装备',231584,231584,231584,231584,309,309,309,309,309,309,1,10,0,0,1000,0,4,3),(739,'@css04@【鸿蒙天尊の杖】@css@','西游鸿蒙天级装备',231584,231584,231584,231584,309,309,309,309,309,309,1,10,0,0,1000,0,5,3),(740,'@css04@【鸿蒙天尊の剑】@css@','西游鸿蒙天级装备',231584,231584,231584,231584,309,309,309,309,309,309,1,10,0,0,1000,0,3,3),(741,'@css05@【鸿蒙神尊の甲】@css@','西游鸿蒙神级装备',263584,263584,263584,263584,359,359,359,359,359,359,1,10,0,0,1000,0,6,4),(742,'@css05@【鸿蒙神尊の盔】@css@','西游鸿蒙神级装备',263584,263584,263584,263584,359,359,359,359,359,359,1,10,0,0,1000,0,6,5),(743,'@css05@【鸿蒙神尊の靴】@css@','西游鸿蒙神级装备',263584,263584,263584,263584,359,359,359,359,359,359,1,10,0,0,1000,0,6,6),(744,'@css05@【鸿蒙神尊の链】@css@','西游鸿蒙神级装备',263584,263584,263584,263584,359,359,359,359,359,359,1,10,0,0,1000,0,6,7),(745,'@css05@【鸿蒙神尊の镯】@css@','西游鸿蒙神级装备',263584,263584,263584,263584,359,359,359,359,359,359,1,10,0,0,1000,0,6,8),(746,'@css05@【鸿蒙神尊の枪】@css@','西游鸿蒙神级装备',283584,283584,283584,283584,359,359,359,359,359,359,1,10,0,0,1000,0,1,3),(747,'@css05@【鸿蒙神尊の叉】@css@','西游鸿蒙神级装备',283584,283584,283584,283584,359,359,359,359,359,359,1,10,0,0,1000,0,2,3),(748,'@css05@【鸿蒙神尊の棍】@css@','西游鸿蒙神级装备',283584,283584,283584,283584,359,359,359,359,359,359,1,10,0,0,1000,0,4,3),(749,'@css05@【鸿蒙神尊の杖】@css@','西游鸿蒙神级装备',283584,283584,283584,283584,359,359,359,359,359,359,1,10,0,0,1000,0,5,3),(750,'@css05@【鸿蒙神尊の剑】@css@','西游鸿蒙神级装备',283584,283584,283584,283584,359,359,359,359,359,359,1,10,0,0,1000,0,3,3),(751,'@css05@【鸿蒙圣尊の甲】@css@','西游鸿蒙圣级装备',315584,315584,315584,315584,409,409,409,409,409,409,1,10,0,0,1000,0,6,4),(752,'@css06@【鸿蒙圣尊の盔】@css@','西游鸿蒙圣级装备',315584,315584,315584,315584,409,409,409,409,409,409,1,10,0,0,1000,0,6,5),(753,'@css06@【鸿蒙圣尊の靴】@css@','西游鸿蒙圣级装备',315584,315584,315584,315584,409,409,409,409,409,409,1,10,0,0,1000,0,6,6),(754,'@css06@【鸿蒙圣尊の链】@css@','西游鸿蒙圣级装备',315584,315584,315584,315584,409,409,409,409,409,409,1,10,0,0,1000,0,6,7),(755,'@css06@【鸿蒙圣尊の镯】@css@','西游鸿蒙圣级装备',315584,315584,315584,315584,409,409,409,409,409,409,1,10,0,0,1000,0,6,8),(756,'@css06@【鸿蒙圣尊の枪】@css@','西游鸿蒙圣级装备',335584,335584,335584,335584,409,409,409,409,409,409,1,10,0,0,1000,0,1,3),(757,'@css06@【鸿蒙圣尊の叉】@css@','西游鸿蒙圣级装备',335584,335584,335584,335584,409,409,409,409,409,409,1,10,0,0,1000,0,2,3),(758,'@css06@【鸿蒙圣尊の棍】@css@','西游鸿蒙圣级装备',335584,335584,335584,335584,409,409,409,409,409,409,1,10,0,0,1000,0,4,3),(759,'@css06@【鸿蒙圣尊の杖】@css@','西游鸿蒙圣级装备',335584,335584,335584,335584,409,409,409,409,409,409,1,10,0,0,1000,0,5,3),(760,'@css06@【鸿蒙圣尊の剑】@css@','西游鸿蒙圣级装备',335584,335584,335584,335584,409,409,409,409,409,409,1,10,0,0,1000,0,3,3),(761,'@css07@【洪荒苍穹の枪】@css@','“洪荒苍穹”是一套传说中的套装，据说是由天界的龙族锻造大师亲手打造，蕴含着龙族的古老力量。',380008,380008,380008,380008,459,459,459,459,459,459,1,10,1,0,1000,0,1,3),(762,'@css07@【洪荒苍穹の叉】@css@','“洪荒苍穹”是一套传说中的套装，据说是由天界的龙族锻造大师亲手打造，蕴含着龙族的古老力量。',380008,380008,380008,380008,459,459,459,459,459,459,1,10,1,0,1000,0,2,3),(763,'@css07@【洪荒苍穹の剑】@css@','“洪荒苍穹”是一套传说中的套装，据说是由天界的龙族锻造大师亲手打造，蕴含着龙族的古老力量。',380008,380008,380008,380008,459,459,459,459,459,459,1,10,1,0,1000,0,3,3),(764,'@css07@【洪荒苍穹の棍】@css@','“洪荒苍穹”是一套传说中的套装，据说是由天界的龙族锻造大师亲手打造，蕴含着龙族的古老力量。',380008,380008,380008,380008,459,459,459,459,459,459,1,10,1,0,1000,0,4,3),(765,'@css07@【洪荒苍穹の杖】@css@','“洪荒苍穹”是一套传说中的套装，据说是由天界的龙族锻造大师亲手打造，蕴含着龙族的古老力量。',380008,380008,380008,380008,459,459,459,459,459,459,1,10,1,0,1000,0,5,3),(766,'@css07@【洪荒苍穹の甲】@css@','“洪荒苍穹”是一套传说中的套装，据说是由天界的龙族锻造大师亲手打造，蕴含着龙族的古老力量。',360008,360008,360008,360008,459,459,459,459,459,459,1,10,1,0,1000,0,6,4),(767,'@css07@【洪荒苍穹の盔】@css@','“洪荒苍穹”是一套传说中的套装，据说是由天界的龙族锻造大师亲手打造，蕴含着龙族的古老力量。',360008,360008,360008,360008,459,459,459,459,459,459,1,10,1,0,1000,0,6,5),(768,'@css07@【洪荒苍穹の靴】@css@','“洪荒苍穹”是一套传说中的套装，据说是由天界的龙族锻造大师亲手打造，蕴含着龙族的古老力量。',360008,360008,360008,360008,459,459,459,459,459,459,1,10,1,0,1000,0,6,6),(769,'@css07@【洪荒苍穹の链】@css@','“洪荒苍穹”是一套传说中的套装，据说是由天界的龙族锻造大师亲手打造，蕴含着龙族的古老力量。',360008,360008,360008,360008,459,459,459,459,459,459,1,10,1,0,1000,0,6,7),(770,'@css07@【洪荒苍穹の镯】@css@','“洪荒苍穹”是一套传说中的套装，据说是由天界的龙族锻造大师亲手打造，蕴含着龙族的古老力量。',360008,360008,360008,360008,459,459,459,459,459,459,1,10,1,0,1000,0,6,8),(771,'@css08@【精致 • 洪荒苍穹の枪】@css@','“洪荒苍穹”是一套传说中的套装，据说是由天界的龙族锻造大师亲手打造，蕴含着龙族的古老力量。',430008,430008,430008,430008,589,589,589,589,589,589,1,10,1,0,1000,0,1,3),(772,'@css08@【精致 • 洪荒苍穹の叉】@css@','“洪荒苍穹”是一套传说中的套装，据说是由天界的龙族锻造大师亲手打造，蕴含着龙族的古老力量。',430008,430008,430008,430008,589,589,589,589,589,589,1,10,1,0,1000,0,2,3),(773,'@css08@【精致 • 洪荒苍穹の剑】@css@','“洪荒苍穹”是一套传说中的套装，据说是由天界的龙族锻造大师亲手打造，蕴含着龙族的古老力量。',430008,430008,430008,430008,589,589,589,589,589,589,1,10,1,0,1000,0,3,3),(774,'@css08@【精致 • 洪荒苍穹の棍】@css@','“洪荒苍穹”是一套传说中的套装，据说是由天界的龙族锻造大师亲手打造，蕴含着龙族的古老力量。',430008,430008,430008,430008,589,589,589,589,589,589,1,10,1,0,1000,0,4,3),(775,'@css08@【精致 • 洪荒苍穹の杖】@css@','“洪荒苍穹”是一套传说中的套装，据说是由天界的龙族锻造大师亲手打造，蕴含着龙族的古老力量。',430008,430008,430008,430008,589,589,589,589,589,589,1,10,1,0,1000,0,5,3),(776,'@css08@【精致 ▪ 洪荒苍穹の甲】@css@','“洪荒苍穹”是一套传说中的套装，据说是由天界的龙族锻造大师亲手打造，蕴含着龙族的古老力量。',410008,410008,410008,410008,589,589,589,589,589,589,1,10,1,0,1000,0,6,4),(777,'@css08@【精致 ▪ 洪荒苍穹の盔】@css@','“洪荒苍穹”是一套传说中的套装，据说是由天界的龙族锻造大师亲手打造，蕴含着龙族的古老力量。',410008,410008,410008,410008,589,589,589,589,589,589,1,10,1,0,1000,0,6,5),(778,'@css08@【精致 ▪ 洪荒苍穹の靴】@css@','“洪荒苍穹”是一套传说中的套装，据说是由天界的龙族锻造大师亲手打造，蕴含着龙族的古老力量。',410008,410008,410008,410008,589,589,589,589,589,589,1,10,1,0,1000,0,6,6),(779,'@css08@【精致 ▪ 洪荒苍穹の链】@css@','“洪荒苍穹”是一套传说中的套装，据说是由天界的龙族锻造大师亲手打造，蕴含着龙族的古老力量。',410008,410008,410008,410008,589,589,589,589,589,589,1,10,1,0,1000,0,6,7),(780,'@css08@【精致 ▪ 洪荒苍穹の镯】@css@','“洪荒苍穹”是一套传说中的套装，据说是由天界的龙族锻造大师亲手打造，蕴含着龙族的古老力量。',410008,410008,410008,410008,589,589,589,589,589,589,1,10,1,0,1000,0,6,8),(781,'@css09@【卓越 • 洪荒苍穹の枪】@css@','“洪荒苍穹”是一套传说中的套装，据说是由天界的龙族锻造大师亲手打造，蕴含着龙族的古老力量。',480008,480008,480008,480008,671,671,671,671,671,671,1,10,1,0,1000,0,1,3),(782,'@css09@【卓越 • 洪荒苍穹の叉】@css@','“洪荒苍穹”是一套传说中的套装，据说是由天界的龙族锻造大师亲手打造，蕴含着龙族的古老力量。',480008,480008,480008,480008,671,671,671,671,671,671,1,10,1,0,1000,0,2,3),(783,'@css09@【卓越 • 洪荒苍穹の剑】@css@','“洪荒苍穹”是一套传说中的套装，据说是由天界的龙族锻造大师亲手打造，蕴含着龙族的古老力量。',480008,480008,480008,480008,671,671,671,671,671,671,1,10,1,0,1000,0,3,3),(784,'@css09@【卓越 • 洪荒苍穹の棍】@css@','“洪荒苍穹”是一套传说中的套装，据说是由天界的龙族锻造大师亲手打造，蕴含着龙族的古老力量。',480008,480008,480008,480008,671,671,671,671,671,671,1,10,1,0,1000,0,4,3),(785,'@css09@【卓越 • 洪荒苍穹の杖】@css@','“洪荒苍穹”是一套传说中的套装，据说是由天界的龙族锻造大师亲手打造，蕴含着龙族的古老力量。',480008,480008,480008,480008,671,671,671,671,671,671,1,10,1,0,1000,0,5,3),(786,'@css09@【卓越 ▪ 洪荒苍穹の甲】@css@','“洪荒苍穹”是一套传说中的套装，据说是由天界的龙族锻造大师亲手打造，蕴含着龙族的古老力量。',460008,460008,460008,460008,671,671,671,671,671,671,1,10,1,0,1000,0,6,4),(787,'@css09@【卓越 ▪ 洪荒苍穹の盔】@css@','“洪荒苍穹”是一套传说中的套装，据说是由天界的龙族锻造大师亲手打造，蕴含着龙族的古老力量。',460008,460008,460008,460008,671,671,671,671,671,671,1,10,1,0,1000,0,6,5),(788,'@css09@【卓越 ▪ 洪荒苍穹の靴】@css@','“洪荒苍穹”是一套传说中的套装，据说是由天界的龙族锻造大师亲手打造，蕴含着龙族的古老力量。',460008,460008,460008,460008,671,671,671,671,671,671,1,10,1,0,1000,0,6,6),(789,'@css09@【卓越 ▪ 洪荒苍穹の链】@css@','“洪荒苍穹”是一套传说中的套装，据说是由天界的龙族锻造大师亲手打造，蕴含着龙族的古老力量。',460008,460008,460008,460008,671,671,671,671,671,671,1,10,1,0,1000,0,6,7),(790,'@css09@【卓越 ▪ 洪荒苍穹の镯】@css@','“洪荒苍穹”是一套传说中的套装，据说是由天界的龙族锻造大师亲手打造，蕴含着龙族的古老力量。',460008,460008,460008,460008,671,671,671,671,671,671,1,10,1,0,1000,0,6,8),(791,'@css09@【完美 ▪ 洪荒苍穹の枪】@css@','“洪荒苍穹”是一套传说中的套装，据说是由天界的龙族锻造大师亲手打造，蕴含着龙族的古老力量。',560008,560008,560008,560008,1171,1171,1171,1171,1171,1171,1,10,1,0,1000,0,1,3),(792,'@css09@【完美 ▪ 洪荒苍穹の叉】@css@','“洪荒苍穹”是一套传说中的套装，据说是由天界的龙族锻造大师亲手打造，蕴含着龙族的古老力量。',560008,560008,560008,560008,1171,1171,1171,1171,1171,1171,1,10,1,0,1000,0,2,3),(793,'@css09@【完美 ▪ 洪荒苍穹の剑】@css@','“洪荒苍穹”是一套传说中的套装，据说是由天界的龙族锻造大师亲手打造，蕴含着龙族的古老力量。',560008,560008,560008,560008,1171,1171,1171,1171,1171,1171,1,10,1,0,1000,0,3,3),(794,'@css09@【完美 ▪ 洪荒苍穹の棍】@css@','“洪荒苍穹”是一套传说中的套装，据说是由天界的龙族锻造大师亲手打造，蕴含着龙族的古老力量。',560008,560008,560008,560008,1171,1171,1171,1171,1171,1171,1,10,1,0,1000,0,4,3),(795,'@css09@【完美 ▪ 洪荒苍穹の杖】@css@','“洪荒苍穹”是一套传说中的套装，据说是由天界的龙族锻造大师亲手打造，蕴含着龙族的古老力量。',560008,560008,560008,560008,1171,1171,1171,1171,1171,1171,1,10,1,0,1000,0,5,3),(796,'@css09@【完美 ▪ 洪荒苍穹の甲】@css@','“洪荒苍穹”是一套传说中的套装，据说是由天界的龙族锻造大师亲手打造，蕴含着龙族的古老力量。',540008,540008,540008,540008,1171,1171,1171,1171,1171,1171,1,10,1,0,1000,0,6,4),(797,'@css09@【完美 ▪ 洪荒苍穹の盔】@css@','“洪荒苍穹”是一套传说中的套装，据说是由天界的龙族锻造大师亲手打造，蕴含着龙族的古老力量。',540008,540008,540008,540008,1171,1171,1171,1171,1171,1171,1,10,1,0,1000,0,6,5),(798,'@css09@【完美 ▪ 洪荒苍穹の靴】@css@','“洪荒苍穹”是一套传说中的套装，据说是由天界的龙族锻造大师亲手打造，蕴含着龙族的古老力量。',540008,540008,540008,540008,1171,1171,1171,1171,1171,1171,1,10,1,0,1000,0,6,6),(799,'@css09@【完美 ▪ 洪荒苍穹の链】@css@','“洪荒苍穹”是一套传说中的套装，据说是由天界的龙族锻造大师亲手打造，蕴含着龙族的古老力量。',540008,540008,540008,540008,1171,1171,1171,1171,1171,1171,1,10,1,0,1000,0,6,7),(800,'@css09@【完美 ▪ 洪荒苍穹の镯】@css@','“洪荒苍穹”是一套传说中的套装，据说是由天界的龙族锻造大师亲手打造，蕴含着龙族的古老力量。',540008,540008,540008,540008,1171,1171,1171,1171,1171,1171,1,10,1,0,1000,0,6,8),(801,'@css09@惊才苍穹将星长枪@css@','传奇中的苍穹将星的王者所使用的装备与武器',864128,864128,864128,864128,1871,1871,1871,1871,1871,1871,1,10,1,0,1000,0,1,3),(802,'@css09@惊才苍穹将星长叉@css@','传奇中的惊才苍穹将星的王者所使用的装备与武器',864128,864128,864128,864128,1871,1871,1871,1871,1871,1871,1,10,1,0,1000,0,2,3),(803,'@css09@惊才苍穹将星长剑@css@','传奇中的惊才苍穹将星的王者所使用的装备与武器',864128,864128,864128,864128,1871,1871,1871,1871,1871,1871,1,10,1,0,1000,0,3,3),(804,'@css09@惊才苍穹将星长棍@css@','传奇中的鸿蒙至尊霸王的王者所使用的装备与武器',864128,864128,864128,864128,1871,1871,1871,1871,1871,1871,1,10,1,0,1000,0,4,3),(805,'@css09@惊才苍穹将星长杖@css@','传奇中的惊才苍穹将星的王者所使用的装备与武器',864128,864128,864128,864128,1871,1871,1871,1871,1871,1871,1,10,1,0,1000,0,5,3),(806,'@css09@惊才苍穹将星长甲@css@','传奇中的惊才苍穹将星的王者所使用的装备与武器',664128,664128,664128,664128,1871,1871,1871,1871,1871,1871,1,10,1,0,1000,0,6,4),(807,'@css09@惊才苍穹将星长盔@css@','传奇中的惊才苍穹将星的王者所使用的装备与武器',664128,664128,664128,664128,1871,1871,1871,1871,1871,1871,1,10,1,0,1000,0,6,5),(808,'@css09@惊才苍穹将星长靴@css@','传奇中的惊才苍穹将星的王者所使用的装备与武器',664128,664128,664128,664128,1871,1871,1871,1871,1871,1871,1,10,1,0,1000,0,6,6),(809,'@css09@惊才苍穹将星长链@css@','传奇中的惊才苍穹将星的王者所使用的装备与武器',664128,664128,664128,664128,1871,1871,1871,1871,1871,1871,1,10,1,0,1000,0,6,7),(810,'@css09@惊才苍穹将星长镯@css@','传奇中的惊才苍穹将星的王者所使用的装备与武器',664128,664128,664128,664128,1871,1871,1871,1871,1871,1871,1,10,1,0,1000,0,6,8),(811,'@css03@【尊 ▪ 霸天神威の枪】@css@','神威如天，霸气无双，无人能敌，传闻是已陨落的最强铸造师所铸造。',3880000,3880000,3880000,0,3688,3688,3688,3688,3688,3688,1,10,1,0,1000,0,1,3),(812,'@css03@【尊 ▪ 霸天神威の叉】@css@','神威如天，霸气无双，无人能敌，传闻是已陨落的最强铸造师所铸造。',3880000,3880000,3880000,0,3688,3688,3688,3688,3688,3688,1,10,1,0,1000,0,2,3),(813,'@css03@【尊 ▪ 霸天神威の剑】@css@','神威如天，霸气无双，无人能敌，传闻是已陨落的最强铸造师所铸造。',3880000,3880000,3880000,0,3688,3688,3688,3688,3688,3688,1,10,1,0,1000,0,3,3),(814,'@css03@【尊 ▪ 霸天神威の棍】@css@','神威如天，霸气无双，无人能敌，传闻是已陨落的最强铸造师所铸造。',3880000,3880000,3880000,0,3688,3688,3688,3688,3688,3688,1,10,1,0,1000,0,4,3),(815,'@css03@【尊 ▪ 霸天神威の杖】@css@','神威如天，霸气无双，无人能敌，传闻是已陨落的最强铸造师所铸造。',3880000,3880000,3880000,0,3688,3688,3688,3688,3688,3688,1,10,1,0,1000,0,5,3),(816,'@css03@【尊 ▪ 霸天神威の甲】@css@','神威如天，霸气无双，无人能敌，传闻是已陨落的最强铸造师所铸造',3550008,3550008,3550008,3450008,3680,3680,3680,3680,3680,3680,1,10,1,0,1000,0,6,4),(817,'@css03@【尊 ▪ 霸天神威の盔】@css@','神威如天，霸气无双，无人能敌，传闻是已陨落的最强铸造师所铸造',3550008,3550008,3550008,3450008,3680,3680,3680,3680,3680,3680,1,10,1,0,1000,0,6,5),(818,'@css03@【尊 ▪ 霸天神威の靴】@css@','神威如天，霸气无双，无人能敌，传闻是已陨落的最强铸造师所铸造',3550008,3550008,3550008,3450008,3680,3680,3680,3680,3680,3680,1,10,1,0,1000,0,6,6),(819,'@css03@【尊 ▪ 霸天神威の链】@css@','神威如天，霸气无双，无人能敌，传闻是已陨落的最强铸造师所铸造',3550008,3550008,3550008,3450008,3680,3680,3680,3680,3680,3680,1,10,1,0,1000,0,6,7),(820,'@css03@【尊 ▪ 霸天神威の镯】@css@','神威如天，霸气无双，无人能敌，传闻是已陨落的最强铸造师所铸造',3550008,3550008,3550008,3450008,3680,3680,3680,3680,3680,3680,1,10,1,0,1000,0,6,8),(821,'@css05@【火焰之心の戒指】@css@','霸气的火焰与浪漫并存',755008,555008,555008,345008,5680,5680,5680,5680,5680,5680,1,10,1,0,1000,0,6,9),(822,'@css05@【风之语言の手链】@css@','风的语言，谁能听懂呢？',755008,555008,555008,345008,5680,5680,5680,5680,5680,5680,1,10,1,0,1000,0,6,10),(823,'@css05@【精锐 ▪ 火焰之心の戒指】@css@','霸气的火焰与浪漫并存',1055008,855008,855008,545008,8680,8680,8680,8680,8680,8680,1,10,1,0,1000,0,6,9),(824,'@css05@【精锐 ▪ 风之语言の手链】@css@','风的语言，谁能听懂呢？',1055008,855008,855008,545008,8680,8680,8680,8680,8680,8680,1,10,1,0,1000,0,6,10),(825,'@css01@【苍穹霸主の披风】@css@','苍穹之下，霸主之风，霸气与威严的体现。',755008,555008,555008,345008,5680,5680,5680,5680,5680,5680,1,10,1,0,1000,0,6,11),(826,'@css02@【精锐▪ 苍穹霸主の披风】@css@','苍穹之下，霸主之风，霸气与威严的体现。',1055558,855008,855008,545008,8680,8680,8680,8680,8680,8680,1,10,1,0,1000,0,6,11),(827,'@css04@【龙腾九天神兽の坐骑】@css@','龙腾于九天之上，霸气与速度的完美结合。',755008,555008,555008,345008,5680,5680,5680,5680,5680,5680,1,10,1,0,1000,0,6,2),(828,'@css04@【乾坤无极珠の法宝】@css@',' 乾坤在手，无极之力，霸气与神秘的力量源泉。',755008,555008,555008,345008,5680,5680,5680,5680,5680,5680,1,10,1,0,1000,0,6,1),(829,'@css05@【龙鸣苍穹の戒指】@css@','苍穹之下，神龙在申鸣，或在悲鸣。',650008,450008,450008,250008,4980,4980,4980,4980,4980,4980,1,10,1,0,1000,0,6,9),(830,'@css05@【龙鸣苍穹の手链】@css@','苍穹之下，神龙在申鸣，或在悲鸣。',650008,450008,450008,250008,4980,4980,4980,4980,4980,4980,1,10,1,0,1000,0,6,10),(831,'@css05@【精锐 ▪ 龙鸣苍穹の戒指】@css@','苍穹之下，神龙在申鸣，或在悲鸣。',850008,650008,650008,450008,7980,7980,7980,7980,7980,7980,1,10,1,0,1000,0,6,9),(832,'@css05@【精锐 ▪ 龙鸣苍穹の手链】@css@','苍穹之下，神龙在申鸣，或在悲鸣。',850008,650008,650008,450008,7980,7980,7980,7980,7980,7980,1,10,1,0,1000,0,6,10),(833,'@css02@【冥夜 ▪ 幽冥暗影の翅膀】（时装）@css@','时装位置：翅膀  冥夜中，幽冥的暗影在静静的靠近，给予敌人最强一击。（8级时装）',683342,585644,495464,345723,550,550,550,550,550,550,1,10,0,0,1000,0,6,12),(834,'@css02@【冥夜 ▪ 幽冥暗影の镰刀】（时装）@css@','时装位置：武器  冥夜中，幽冥的暗影在静静的靠近，给予敌人最强一击。（8级时装）',683342,585644,495464,345723,550,550,550,550,550,550,1,10,0,0,1000,0,6,13),(835,'@css02@【冥夜 ▪ 幽冥暗影の盾牌】（时装）@css@','时装位置：副手  冥夜中，幽冥的暗影在静静的靠近，给予敌人最强一击。（8级时装））',683342,585644,495464,345723,550,550,550,550,550,550,1,10,0,0,1000,0,6,14),(836,'@css02@【冥夜 ▪ 幽冥暗影の眼镜】（时装）@css@','时装位置：面具  冥夜中，幽冥的暗影在静静的靠近，给予敌人最强一击。（8级时装）',683342,585644,495464,345723,550,550,550,550,550,550,1,10,0,0,1000,0,6,15),(837,'@css02@【冥夜 ▪ 幽冥暗影の衣服】（时装）@css@','时装位置：衣服  冥夜中，幽冥的暗影在静静的靠近，给予敌人最强一击。（8级时装）',683342,585644,495464,345723,550,550,550,550,550,550,1,10,0,0,1000,0,6,16),(838,'@css02@【冥夜 ▪ 幽冥暗影の皮靴】（时装）@css@','时装位置：鞋子  冥夜中，幽冥的暗影在静静的靠近，给予敌人最强一击。（8级时装）',683342,585644,495464,345723,550,550,550,550,550,550,1,10,0,0,1000,0,6,17),(839,'@css02@【冥夜 ▪ 幽冥暗影の戒指】（时装）@css@','时装位置：戒指  冥夜中，幽冥的暗影在静静的靠近，给予敌人最强一击。（8级时装）',683342,585644,495464,345723,550,550,550,550,550,550,1,10,0,0,1000,0,6,18),(840,'@css02@【冥夜 ▪ 幽冥暗影の项链】（时装）@css@','时装位置：项链  冥夜中，幽冥的暗影在静静的靠近，给予敌人最强一击。（8级时装）',683342,585644,495464,345723,550,550,550,550,550,550,1,10,0,0,1000,0,6,19),(841,'@css02@【冥夜 ▪ 幽冥暗影の披风】（时装）@css@','时装位置：披风  冥夜中，幽冥的暗影在静静的靠近，给予敌人最强一击。（8级时装）',683342,585644,495464,345723,550,550,550,550,550,550,1,10,0,0,1000,0,6,20),(842,'@css02@【冥夜 ▪ 幽冥暗影の勋章】（时装）@css@','时装位置：勋章  冥夜中，幽冥的暗影在静静的靠近，给予敌人最强一击。（8级时装）',683342,585644,495464,345723,550,550,550,550,550,550,1,10,0,0,1000,0,6,21),(843,'@css04@【永恒 • 光辉圣使の翅膀】（时装）@css@','时装位置：翅膀  光辉的照耀下，黑暗将不复存在。（8级时装）',1791182,1392244,986649,745723,2550,2550,2550,2550,2550,2550,1,10,0,0,1000,0,6,12),(844,'@css04@【永恒 • 光辉圣使の镰刀】（时装）@css@','时装位置：武器  光辉的照耀下，黑暗将不复存在。（8级时装）',1791182,1392244,986649,745723,2550,2550,2550,2550,2550,2550,1,10,0,0,1000,0,6,13),(845,'@css04@【永恒 • 光辉圣使の盾牌】（时装）@css@','时装位置：副手  光辉的照耀下，黑暗将不复存在。（8级时装）',1791182,1392244,986649,745723,2550,2550,2550,2550,2550,2550,1,10,0,0,1000,0,6,14),(846,'@css04@【永恒 • 光辉圣使の眼镜】（时装）@css@','时装位置：面具  光辉的照耀下，黑暗将不复存在。（8级时装）',1791182,1392244,986649,745723,2550,2550,2550,2550,2550,2550,1,10,0,0,1000,0,6,15),(847,'@css04@【永恒 • 光辉圣使の衣服】（时装）@css@','时装位置：衣服  光辉的照耀下，黑暗将不复存在。（8级时装）',1791182,1392244,986649,745723,2550,2550,2550,2550,2550,2550,1,10,0,0,1000,0,6,16),(848,'@css04@【永恒 • 光辉圣使の皮靴】（时装）@css@','时装位置：鞋子  光辉的照耀下，黑暗将不复存在。（8级时装）',1791182,1392244,986649,745723,2550,2550,2550,2550,2550,2550,1,10,0,0,1000,0,6,17),(849,'@css04@【永恒 • 光辉圣使の戒指】（时装）@css@','时装位置：戒指  光辉的照耀下，黑暗将不复存在。（8级时装）',1791182,1392244,986649,745723,2550,2550,2550,2550,2550,2550,1,10,0,0,1000,0,6,18),(850,'@css04@【永恒 • 光辉圣使の项链】（时装）@css@','时装位置：项链  光辉的照耀下，黑暗将不复存在。（8级时装）',1791182,1392244,986649,745723,2550,2550,2550,2550,2550,2550,1,10,0,0,1000,0,6,19),(851,'@css04@【永恒 • 光辉圣使の披风】（时装）@css@','时装位置：披风  光辉的照耀下，黑暗将不复存在。（8级时装）',1791182,1392244,986649,745723,2550,2550,2550,2550,2550,2550,1,10,0,0,1000,0,6,20),(852,'@css04@【永恒 • 光辉圣使の勋章】（时装）@css@','时装位置：勋章  光辉的照耀下，黑暗将不复存在。（8级时装）',1791182,1392244,986649,745723,2550,2550,2550,2550,2550,2550,1,10,0,0,1000,0,6,21),(853,'@css07@【神圣 • 光明神帝の翅膀】（时装）@css@','时装位置：翅膀  光明的神帝，乃是光明帝国的帝王。（20级时装）',3091182,1902244,1506649,900003,10050,10050,10050,10050,10050,10050,1,10,0,0,1000,0,6,12),(854,'@css07@【神圣 • 光明神帝の镰刀】（时装）@css@','时装位置：武器  光明的神帝，乃是光明帝国的帝王。（20级时装）',3091182,1902244,1506649,900003,10050,10050,10050,10050,10050,10050,1,10,0,0,1000,0,6,13),(855,'@css07@【神圣 • 光明神帝の盾牌】（时装）@css@','时装位置：副手  光明的神帝，乃是光明帝国的帝王。（20级时装）',3091182,1902244,1506649,900003,10050,10050,10050,10050,10050,10050,1,10,0,0,1000,0,6,14),(856,'@css07@【神圣 • 光明神帝の眼镜】（时装）@css@','时装位置：面具  光明的神帝，乃是光明帝国的帝王。（20级时装）',3091182,1902244,1506649,900003,10050,10050,10050,10050,10050,10050,1,10,0,0,1000,0,6,15),(857,'@css07@【神圣 • 光明神帝の衣服】（时装）@css@','时装位置：衣服  光明的神帝，乃是光明帝国的帝王。（20级时装）',3091182,1902244,1506649,900003,10050,10050,10050,10050,10050,10050,1,10,0,0,1000,0,6,16),(858,'@css07@【神圣 • 光明神帝の皮靴】（时装）@css@','时装位置：鞋子  光明的神帝，乃是光明帝国的帝王。（20级时装）',3091182,1902244,1506649,900003,10050,10050,10050,10050,10050,10050,1,10,0,0,1000,0,6,17),(859,'@css07@【神圣 • 光明神帝の戒指】（时装）@css@','时装位置：戒指  光明的神帝，乃是光明帝国的帝王。（20级时装）',3091182,1902244,1506649,900003,10050,10050,10050,10050,10050,10050,1,10,0,0,1000,0,6,18),(860,'@css07@【神圣 • 光明神帝の项链】（时装）@css@','时装位置：项链  光明的神帝，乃是光明帝国的帝王。（20级时装）',3091182,1902244,1506649,900003,10050,10050,10050,10050,10050,10050,1,10,0,0,1000,0,6,19),(861,'@css07@【神圣 • 光明神帝の披风】（时装）@css@','时装位置：披风  光明的神帝，乃是光明帝国的帝王。（10级时装）',3091182,1902244,1506649,900003,10050,10050,10050,10050,10050,10050,1,10,0,0,1000,0,6,20),(862,'@css07@【神圣 • 光明神帝の勋章】（时装）@css@','时装位置：勋章  光明的神帝，乃是光明帝国的帝王。（10级时装）',3091182,1902244,1506649,900003,10050,10050,10050,10050,10050,10050,1,10,0,0,1000,0,6,21),(863,'@css02@【神器 - 铁扇公主[芭蕉扇]】@css@','传说中的铁扇公主公主所持神器，能扇出十级仙风吹灭火焔山',1000000,1000000,1000000,1000000,70000,0,0,70000,0,0,1,10,1,0,1000,0,6,22),(864,'@css02@【神器 - 孙悟空[如意金箍棒]】@css@','传说中的齐天大圣孙悟空的神器，定海神针如意金箍棒，重达十万八千斤',1000000,1000000,1000000,1000000,0,70000,0,0,70000,0,1,10,1,0,1000,0,6,22),(865,'@css02@【神器 - 二郎神[三尖两刃刀]】@css@','传说中的二郎神杨戬的神兵利器，击败无数妖魔鬼怪',1000000,1000000,1000000,1000000,0,0,70000,0,0,70000,1,10,1,0,1000,0,6,22);
/*!40000 ALTER TABLE `zbxx` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `zem`
--

DROP TABLE IF EXISTS `zem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `zem` (
  `id` int(11) NOT NULL,
  `zem` text NOT NULL,
  `sy` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `zem`
--

LOCK TABLES `zem` WRITE;
/*!40000 ALTER TABLE `zem` DISABLE KEYS */;
/*!40000 ALTER TABLE `zem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `zf`
--

DROP TABLE IF EXISTS `zf`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `zf` (
  `wjid` int(10) unsigned NOT NULL DEFAULT '0',
  `jy_10` int(11) NOT NULL DEFAULT '0' COMMENT '年',
  `wp_8` int(11) NOT NULL DEFAULT '0' COMMENT '月',
  `wp_4` int(11) NOT NULL DEFAULT '0' COMMENT '日',
  `zf_time` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `zf`
--

LOCK TABLES `zf` WRITE;
/*!40000 ALTER TABLE `zf` DISABLE KEYS */;
INSERT INTO `zf` VALUES (10000001,0,0,0,0);
/*!40000 ALTER TABLE `zf` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `zgvip`
--

DROP TABLE IF EXISTS `zgvip`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `zgvip` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '编号ID',
  `wjid` int(10) unsigned NOT NULL DEFAULT '0',
  `zgvipid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '尊贵VIP编号',
  `zgviptime` datetime NOT NULL COMMENT '尊贵vip时间',
  `xs` int(11) NOT NULL DEFAULT '0' COMMENT '显示',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `zgvip`
--

LOCK TABLES `zgvip` WRITE;
/*!40000 ALTER TABLE `zgvip` DISABLE KEYS */;
/*!40000 ALTER TABLE `zgvip` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `zq_qs`
--

DROP TABLE IF EXISTS `zq_qs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `zq_qs` (
  `wjid` int(11) NOT NULL,
  `zq_id` int(11) NOT NULL,
  `zq_qs` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `zq_qs`
--

LOCK TABLES `zq_qs` WRITE;
/*!40000 ALTER TABLE `zq_qs` DISABLE KEYS */;
/*!40000 ALTER TABLE `zq_qs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `zz`
--

DROP TABLE IF EXISTS `zz`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `zz` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `wjid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '玩家ID',
  `zzdj` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '种植等级',
  `zzwpmz` varchar(32) NOT NULL DEFAULT '' COMMENT '种植物品名字',
  `zzwpid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '种植物品ID',
  `zzwpsl` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '种植物品数量',
  `zztime` timestamp NULL DEFAULT NULL COMMENT '种植时间',
  `sftime` timestamp NULL DEFAULT NULL COMMENT '施肥时间',
  `shtime` timestamp NULL DEFAULT NULL COMMENT '收获时间',
  PRIMARY KEY (`id`),
  KEY `zz_wjid_IDX` (`wjid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `zz`
--

LOCK TABLES `zz` WRITE;
/*!40000 ALTER TABLE `zz` DISABLE KEYS */;
/*!40000 ALTER TABLE `zz` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `zzck`
--

DROP TABLE IF EXISTS `zzck`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `zzck` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '编号ID',
  `wjid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '玩家ID',
  `wpid` int(11) NOT NULL DEFAULT '0' COMMENT '物品ID',
  `wpsl` int(11) NOT NULL DEFAULT '0' COMMENT '物品数量',
  `wpfl` int(11) NOT NULL DEFAULT '0' COMMENT '物品分类',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='增值仓库';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `zzck`
--

LOCK TABLES `zzck` WRITE;
/*!40000 ALTER TABLE `zzck` DISABLE KEYS */;
/*!40000 ALTER TABLE `zzck` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-03-13 23:52:18
