<?php

$install_lock = __DIR__ . '/../../install.lock';
if (!file_exists($install_lock)) {
    header('Location: /install.php');
    exit;
}

//分区所属家园地址
$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';
$host = $_SERVER['HTTP_HOST'];
$config['jy_url'] = "$protocol://$host";

//分区地址
$config['xy_url'] = "$protocol://$host";

//分区数据库配置
$config['mysql'] = [
    'host' => 'localhost',
    'user' => 'xyexye',
    'password' => 'xyexye',
    'database' => 'xyexye',
];

//是否开启调试信息
$config['debug'] = false;

//是否开启地图编辑，请勿打开此选项，后果自负！！
$config['edit_map'] = false;

return $config;
