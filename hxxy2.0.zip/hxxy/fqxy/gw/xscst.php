<?php

$img = '/fqxy/pic/npc/npc65.png';
echo '<img src="' . $img . ' "alt="图片"/>';

//cmd及超链接值
$cmid=$cmid+1;
$cdid[]=$cmid;
$clj[]=10;
$npc[]=335;//需要改动
echo "<a href='xy.php?uid=$wjid&&cmd=$cmid&&sid=$a1'><font color=blue>螃蟹</font></a>";
echo " , ";

echo '<img src="' . $img . ' "alt="图片"/>';
//cmd及超链接值
$cmid=$cmid+1;
$cdid[]=$cmid;
$clj[]=10;
$npc[]=335;//需要改动
echo "<a href='xy.php?uid=$wjid&&cmd=$cmid&&sid=$a1'><font color=blue>螃蟹</font></a>";
echo " , ";

echo '<img src="' . $img . ' "alt="图片"/>';
//cmd及超链接值
$cmid=$cmid+1;
$cdid[]=$cmid;
$clj[]=10;
$npc[]=335;//需要改动
echo "<a href='xy.php?uid=$wjid&&cmd=$cmid&&sid=$a1'><font color=blue>螃蟹</font></a>";

echo "<br>";








?>







