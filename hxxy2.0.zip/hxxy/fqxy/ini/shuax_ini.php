<?php

$inina="shuax.ini";
$path='ache/'.$wjid;
$file = $path."/".$inina;
if(file_exists($file)) {

} else {
    $inina="shuax.ini";
    $path='ache/'.$wjid;
    $file = $path."/".$inina;
    file_put_contents($file,"[玩家]");
    $iniFile = new iniFile($file);
    $iniFile->addItem('玩家信息',['初始' => 123]);
    $iniFile->addCategory('玩家信息', ['刷新过快' => 1]);
}
$iniFile = new iniFile($file);
