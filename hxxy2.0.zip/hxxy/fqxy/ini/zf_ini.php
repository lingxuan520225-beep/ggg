<?php

include("./sql/mysql.php");//调用数据库连
$sql1 = mysql_query("select * from zf where wjid=$wjid", $conn);
$info1 = @mysql_fetch_array($sql1);
$zf_id = $info1['wjid'];
$jyzf_10 = $info1['jy_10'];
$wpzf_4 = $info1['wp_4'];
$wpzf_8 = $info1['wp_8'];
$zfsj = $info1['zf_time'];

if($zf_id==0){
	
	//添加新数据
	include("./sql/mysql.php");//调用数据库连接 
	$sql = "insert into zf (wjid)  values('$wjid')";
 	if (!mysql_query($sql,$conn)){
   	die('Error: ' . mysql_error());
 	}

}

$inina="zf.ini";
$path='ache/'.$wjid;
$file = $path."/".$inina;	
//创建文件
file_put_contents($file,"[玩家]");
# 实例化ini文件操作类，并载入 .ini文件
$iniFile = new iniFile($file);
