<?php

include("./sql/mysql.php");//调用数据库连
$sql1 = mysql_query("select * from xydfw where wjid=$wjid", $conn);
$info1 = @mysql_fetch_array($sql1);
$pl_id = $info1['wjid'];
$pl_cs = $info1['plcs'];
$pl_mfcz = $info1['pl_mfcz'];
$pl_time = $info1['pl_time'];
$pl_10 = $info1['pl_10'];
$pl_20 = $info1['pl_20'];
$pl_50 = $info1['pl_50'];
$pl_60 = $info1['pl_60'];
$pl_80 = $info1['pl_80'];
$pl_100 = $info1['pl_100'];
$pl_150 = $info1['pl_150'];
$pl_100 = $info1['pl_100'];
$pl_200 = $info1['pl_200'];
$pl_300 = $info1['pl_300'];
$pl_400 = $info1['pl_400'];
$pl_500 = $info1['pl_500'];
$pl_600 = $info1['pl_600'];
$pl_700 = $info1['pl_700'];
$pl_800 = $info1['pl_800'];
$pl_900 = $info1['pl_900'];
$pl_1000 = $info1['pl_1000'];

if($pl_id==0){
	
	//添加新数据
	include("./sql/mysql.php");//调用数据库连接 
	$sql = "insert into xydfw (wjid, plcs)  values('$wjid','1')";
 	if (!mysql_query($sql,$conn)){
   	die('Error: ' . mysql_error());
 	}

}




?>