<?php

include("./sql/mysql.php");//调用数据库连接
$q2 = "all_zt";
$sql1 = mysql_query("select * from $q2 where wjid=$wjid", $conn);
$info1 = @mysql_fetch_array($sql1);
$u_fmtcs = $info1['u_fmtcs'];


include("./npc/fmtagw.php");//调用怪物信息
$fmtgwmz = $nname;

//调用数据库连接


echo "<font color=00000>[伏魔塔]</font>"."<br>";
	
$img = '/fqxy/pic/fmt/fmta.png';
echo '<img src="' . $img . ' "alt="图片"/>';
echo "<br>";	
	
echo "<font color=black>当前关卡: 第 [".$u_fmtcs."] 关</font>";
echo "<br>";
echo "<font color=black>最高关卡: 第 [".$u_fmtcs."] 关</font>";
echo "<br>";
echo "<font color=black>当前守卫: </font>";
?>

<span class="demo_tooltip">

<?php
echo "<font color=green>".$fmtgwmz."</font>";
?>
<span class="tooltiptext">
<?php
include("./fmt/fmtsx.php");//调用怪物信息
?>
</span></span>

<?php
echo "<br>";
echo "<br>";

if($u_fmtcs<1000){
	
//cmd及超链接值
$cmid=$cmid+1;
$cdid[]=$cmid;
$clj[]=10;
$npc[]=1328;
echo "<a href='xy.php?uid=$wjid&&cmd=$cmid&&sid=$a1'><font color=blue>〓开始挑战〓</font></a>"."<br>";

}else{
	
//cmd及超链接值
$cmid=$cmid+1;
$cdid[]=$cmid;
$clj[]=131;
$npc[]=0;
echo "<a href='xy.php?uid=$wjid&&cmd=$cmid&&sid=$a1'><font color=blue>〓开始挑战〓</font></a>"."<br>";	


}

echo "<br>";


//cmd及超链接值
$cmid=$cmid+1;
$cdid[]=$cmid;
$clj[]=698;
$npc[]=999;
echo "<a href='xy.php?uid=$wjid&&cmd=$cmid&&sid=$a1'><font color=blue>〓重置关卡〓</font></a>"."<br>";
echo "<br>";

//cmd及超链接值
$cmid=$cmid+1;
$cdid[]=$cmid;
$clj[]=698;
$npc[]=888;
echo "<a href='xy.php?uid=$wjid&&cmd=$cmid&&sid=$a1'><font color=blue>〓伏魔商店〓</font></a>"."<br>";


?>






