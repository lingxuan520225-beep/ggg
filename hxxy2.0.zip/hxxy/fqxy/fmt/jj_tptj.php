<?php

include("./sql/mysql.php");//调用数据库连接
$q2 = "wj_jj";
$sql1 = mysql_query("select * from $q2 where wjid=$wjid", $conn);
$info1 = @mysql_fetch_array($sql1);
$jj_d = $info1['wj_jj'];
$jj_cs = $info1['jj_cs'];




if($jj_d==1 and $jj_cs==10){
	$jj_tja = '筑基金丹';
}elseif($jj_d==2 and $jj_cs==10){
	$jj_tja = '金丹金丹';
}elseif($jj_d==3 and $jj_cs==10){
	$jj_tja = '元婴金丹';
}elseif($jj_d==4 and $jj_cs==10){
	$jj_tja = '化神金丹';
}elseif($jj_d==5 and $jj_cs==10){
	$jj_tja = '炼虚金丹';
}elseif($jj_d==6 and $jj_cs==10){
	$jj_tja = '合体金丹';
}elseif($jj_d==7 and $jj_cs==10){
	$jj_tja = '大乘金丹';
}elseif($jj_d==8 and $jj_cs==10){
	$jj_tja = '真仙仙丹';
}elseif($jj_d==9 and $jj_cs==10){
	$jj_tja = '金仙仙丹';
}elseif($jj_d==10 and $jj_cs==10){
	$jj_tja= '太乙仙丹';
}elseif($jj_d==11 and $jj_cs==10){
	$jj_tja = '大罗仙丹';
}elseif($jj_d==12 and $jj_cs==10){
	$jj_tja = '道祖仙丹';
}elseif($jj_d==13 and $jj_cs==10){
	$jj_tja = '虚神仙丹';
}elseif($jj_d==14 and $jj_cs==10){
	$jj_tja = '真神仙丹';
}elseif($jj_d==15 and $jj_cs==10){
	$jj_tja = '神王仙丹';
}elseif($jj_d==16 and $jj_cs==10){
	$jj_tja = '祖神仙丹';
}elseif($jj_d==17 and $jj_cs==10){
	$jj_tja = '祖王仙丹';
}elseif($jj_d==18 and $jj_cs==10){
	$jj_tja = '祖皇仙丹';
}elseif($jj_d==19 and $jj_cs==10){
	$jj_tja = '祖帝仙丹';
}elseif($jj_d==20 and $jj_cs==10){
	$jj_tja = '圣尊仙丹';
}elseif($jj_d==21 and $jj_cs==10){
	$jj_tja = '仙尊仙丹';
}elseif($jj_d==22 and $jj_cs==10){
	$jj_tja = '天帝仙丹';
}elseif($jj_d==23 and $jj_cs==10){
	$jj_tja = '如来佛仙丹';		
}



if($jj_d==1 and $jj_cs==10){
	$jj_tjb = 1119;
}elseif($jj_d==2 and $jj_cs==10){
	$jj_tjb = 1120;
}elseif($jj_d==3 and $jj_cs==10){
	$jj_tjb = 1121;
}elseif($jj_d==4 and $jj_cs==10){
	$jj_tjb = 1122;
}elseif($jj_d==5 and $jj_cs==10){
	$jj_tjb = 1123;
}elseif($jj_d==6 and $jj_cs==10){
	$jj_tjb = 1124;
}elseif($jj_d==7 and $jj_cs==10){
	$jj_tjb = 1125;
}elseif($jj_d==8 and $jj_cs==10){
	$jj_tjb = 1126;
}elseif($jj_d==9 and $jj_cs==10){
	$jj_tjb = 1127;
}elseif($jj_d==10 and $jj_cs==10){
	$jj_tjb = 1128;
}elseif($jj_d==11 and $jj_cs==10){
	$jj_tjb = 1129;
}elseif($jj_d==12 and $jj_cs==10){
	$jj_tjb = 1130;
}elseif($jj_d==13 and $jj_cs==10){
	$jj_tjb = 1131;
}elseif($jj_d==14 and $jj_cs==10){
	$jj_tjb = 1132;
}elseif($jj_d==15 and $jj_cs==10){
	$jj_tjb = 1133;
}elseif($jj_d==16 and $jj_cs==10){
	$jj_tjb = 1134;
}elseif($jj_d==17 and $jj_cs==10){
	$jj_tjb = 1199;
}elseif($jj_d==18 and $jj_cs==10){
	$jj_tjb = 1200;
}elseif($jj_d==19 and $jj_cs==10){
	$jj_tjb = 1201;
}elseif($jj_d==20 and $jj_cs==10){
	$jj_tjb = 1202;
}elseif($jj_d==21 and $jj_cs==10){
	$jj_tjb = 1203;
}elseif($jj_d==22 and $jj_cs==10){
	$jj_tjb = 1204;
}elseif($jj_d==23 and $jj_cs==10){
	$jj_tjb = 1205;		
}



$jj_tpjy = $jj_d*50000;