<?php

include("./sql/mysql.php");//调用数据库连接
$q2 = "fstcz";
$sql1 = mysql_query("select * from $q2 where wjid=$wjid and hdid=1", $conn);
$info1 = @mysql_fetch_array($sql1);
$s_time = $info1['hdtime'];
$d_time = date('d');
$s_time_hdid = $info1['hdid'];
$s_time_hdcs = $info1['hdcs'];

if($s_time!=$d_time and $s_time_hdid!=1 ){
	
    //添加新数据
	$hdid=1;
	include("./sql/mysql.php");//调用数据库连接 

	$sql = "insert into fstcz (wjid, hdid,hdtime,hdcs)  values('$wjid','$hdid','$d_time','1')";
 	if (!mysql_query($sql,$conn)){
   	die('Error: ' . mysql_error());
 	}
	

    $strsql = "update wj_jj set fst_cs=1 where wjid=$wjid";//物品id号必改值
    $result = mysql_query($strsql);
	

    echo "<font color=00000>重置飞仙塔成功，当前关卡已重置到第一关卡！</font>"."<br>";
	

} elseif($s_time!=$d_time and $s_time_hdid==1){
	
    include("./sql/mysql.php");//调用数据库连接

    $strsql = "update fstcz set hdtime=$d_time , hdcs=hdcs+1 where wjid=$wjid and hdid=1";//物品id号必改值
    $result = mysql_query($strsql);

    $strsql = "update wj_jj set fst_cs=1 where wjid=$wjid";//物品id号必改值
    $result = mysql_query($strsql);
	

    echo "<font color=00000>重置飞仙塔成功，当前关卡已重置到第一关卡！</font>"."<br>";
	
	
	
}else{
	echo "<font color=00000>每天只能免费重置一次，请明天再来！</font>"."<br>";
	
}
	
	

//cmd及超链接值
$cmid=$cmid+1;
$cdid[]=$cmid;
$clj[]=7;
$npc[]=1329;
echo "<a href='xy.php?uid=$wjid&&cmd=$cmid&&sid=$a1'><font color=blue>返回上一级</font></a>"."<br>";
?>
