<?php

include("./npc/fstagw.php");//调用怪物信息
$fmtgwmz = $nname;
$fmtgwms = $nms;
$fmtgwdj = $ndj;
$fmtgwhp = $nhp;
$fmtgwmaxhp = $nmaxhp;
$fmtgwmp = $nmp;
$fmtgwmaxmp = $nmaxmp;
$fmtgwgj = $ngj;
$fmtgwmg = $nmg;
$fmtgwfy = $nfy;
$fmtgwmf = $nmf;
$fmtgwbg = $nbg;
$fmtgwhg = $nhg;
$fmtgwlg = $nlg;
$fmtgwbf = $nbf;
$fmtgwhf = $nhf;
$fmtgwlf = $nlf;

//


echo "[".$fmtgwmz."]"."<br>";

echo "".$fmtgwms.""."<br>";

echo "等级：".$fmtgwdj.""."<br>";
echo "生命：".$fmtgwhp."/".$fmtgwmaxhp.""."<br>";
echo "法力：".$fmtgwmp."/".$fmtgwmaxmp.""."<br>";
echo "攻击：".$fmtgwgj."-".$fmtgwgj.""."<br>";
echo "魔攻：".$fmtgwmg."-".$fmtgwmg.""."<br>";
echo "防御：".$fmtgwfy."-".$fmtgwfy.""."<br>";

echo "<br>";



?>