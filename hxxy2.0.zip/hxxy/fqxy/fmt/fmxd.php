<?php

include("./sql/mysql.php");//调用数据库连接
$q2 = "wp";
$sql1 = mysql_query("select * from $q2 where wjid=$wjid and wpid=1116", $conn);
$info1 = @mysql_fetch_array($sql1);



echo "<font color=00000>[物品兑换]</font>"."<br>";
$fmbi = $info1['wpsl'];
if($fmbi==0){
	$fmbi=0;
}else{
	$fmbi=$fmbi;
}

echo "<br>";

echo "<font color=00000>伏魔币: [".$fmbi."] 个</font>"."<br>";

echo "<br>";
?>
  

<?php
$cmid = $cmid + 1;
$cdid[] = $cmid;
$clj[] = 698;
$npc[] = 1;
$mdxurl = sprintf('xy.php?uid=%d&cmd=%d&sid=%s', $wjid, $cmid, $a1);
?>
<form  action="<?php echo $mdxurl?>" method="POST"><span class="demo_tooltip">
<font color=00000>金刚砂 </font> 
<input type="text" name="sl" placeholder="请输入"id='search'onkeyup="this.value=this.value.replace(/\D/g,'')" onafterpaste="this.value=this.value.replace(/\D/g,'')">
<input  type="submit" name="submit"  value="购买" id="search1"><br>
</form>
	
<span class="tooltiptext">
<金刚砂
<br>
升级炼妖壶神器所需材料物品之一!
<br>
价格：10 伏魔币
</span></span>

  
<?php
$cmid = $cmid + 1;
$cdid[] = $cmid;
$clj[] = 698;
$npc[] = 2;
$mdxurl = sprintf('xy.php?uid=%d&cmd=%d&sid=%s', $wjid, $cmid, $a1);
?>
<form  action="<?php echo $mdxurl?>" method="POST"><span class="demo_tooltip">
<font color=00000>黄铁矿石 </font> 
<input type="text" name="sl" placeholder="请输入"id='search'onkeyup="this.value=this.value.replace(/\D/g,'')" onafterpaste="this.value=this.value.replace(/\D/g,'')">
<input  type="submit" name="submit"  value="购买" id="search1"><br>
</form>
	
<span class="tooltiptext">
黄铁矿石
<br>
升级炼妖壶神器所需材料物品之一!
<br>
价格：30 伏魔币
</span></span>

 
<?php
$cmid = $cmid + 1;
$cdid[] = $cmid;
$clj[] = 698;
$npc[] = 3;
$mdxurl = sprintf('xy.php?uid=%d&cmd=%d&sid=%s', $wjid, $cmid, $a1);
?>
<form  action="<?php echo $mdxurl?>" method="POST"><span class="demo_tooltip">
<font color=00000>剑柄碎片 </font> 
<input type="text" name="sl" placeholder="请输入"id='search'onkeyup="this.value=this.value.replace(/\D/g,'')" onafterpaste="this.value=this.value.replace(/\D/g,'')">
<input  type="submit" name="submit"  value="购买" id="search1"><br>
</form>
	
<span class="tooltiptext">
剑柄碎片
<br>
升级轩辕剑神器所需材料物品之一!
<br>
价格：10 伏魔币
</span></span>


<?php
$cmid = $cmid + 1;
$cdid[] = $cmid;
$clj[] = 698;
$npc[] = 4;
$mdxurl = sprintf('xy.php?uid=%d&cmd=%d&sid=%s', $wjid, $cmid, $a1);
?>
<form  action="<?php echo $mdxurl?>" method="POST"><span class="demo_tooltip">
<font color=00000>玄铁矿石 </font> 
<input type="text" name="sl" placeholder="请输入"id='search'onkeyup="this.value=this.value.replace(/\D/g,'')" onafterpaste="this.value=this.value.replace(/\D/g,'')">
<input  type="submit" name="submit"  value="购买" id="search1"><br>
</form>
	
<span class="tooltiptext">
玄铁矿石
<br>
升级轩辕剑神器所需材料物品之一!
<br>
价格：30 伏魔币
</span></span>


 
<?php
$cmid = $cmid + 1;
$cdid[] = $cmid;
$clj[] = 698;
$npc[] = 5;
$mdxurl = sprintf('xy.php?uid=%d&cmd=%d&sid=%s', $wjid, $cmid, $a1);
?>
<form  action="<?php echo $mdxurl?>" method="POST"><span class="demo_tooltip">
<font color=00000>昆仑神木 </font> 
<input type="text" name="sl" placeholder="请输入"id='search'onkeyup="this.value=this.value.replace(/\D/g,'')" onafterpaste="this.value=this.value.replace(/\D/g,'')">
<input  type="submit" name="submit"  value="购买" id="search1"><br>
</form>
	
<span class="tooltiptext">
昆仑神木
<br>
升级昆仑镜神器所需材料物品之一!
<br>
价格：10 伏魔币
</span></span>



<?php
$cmid = $cmid + 1;
$cdid[] = $cmid;
$clj[] = 698;
$npc[] = 6;
$mdxurl = sprintf('xy.php?uid=%d&cmd=%d&sid=%s', $wjid, $cmid, $a1);
?>
<form  action="<?php echo $mdxurl?>" method="POST"><span class="demo_tooltip">
<font color=00000>神秘矿石 </font> 
<input type="text" name="sl" placeholder="请输入"id='search'onkeyup="this.value=this.value.replace(/\D/g,'')" onafterpaste="this.value=this.value.replace(/\D/g,'')">
<input  type="submit" name="submit"  value="购买" id="search1"><br>
</form>
	
<span class="tooltiptext">
神秘矿石
<br>
升级昆仑镜神器所需材料物品之一!
<br>
价格：30 伏魔币
</span></span>



<?php
$cmid = $cmid + 1;
$cdid[] = $cmid;
$clj[] = 698;
$npc[] = 7;
$mdxurl = sprintf('xy.php?uid=%d&cmd=%d&sid=%s', $wjid, $cmid, $a1);
?>
<form  action="<?php echo $mdxurl?>" method="POST"><span class="demo_tooltip">
<font color=00000>【精炼的玄铁】 </font> 
<input type="text" name="sl" placeholder="请输入"id='search'onkeyup="this.value=this.value.replace(/\D/g,'')" onafterpaste="this.value=this.value.replace(/\D/g,'')">
<input  type="submit" name="submit"  value="购买" id="search1"><br>
</form>
	
<span class="tooltiptext">
【精炼的玄铁】
<br>
神器升星阶时所需的通用物品!
<br>
价格：1000 伏魔币
</span></span>



<?php
$cmid = $cmid + 1;
$cdid[] = $cmid;
$clj[] = 698;
$npc[] = 8;
$mdxurl = sprintf('xy.php?uid=%d&cmd=%d&sid=%s', $wjid, $cmid, $a1);
?>
<form  action="<?php echo $mdxurl?>" method="POST"><span class="demo_tooltip">
<font color=blue><div class='css01'>【龙吟苍穹の首饰套装】</div> </font> 
<input type="text" name="sl" placeholder="请输入"id='search'onkeyup="this.value=this.value.replace(/\D/g,'')" onafterpaste="this.value=this.value.replace(/\D/g,'')">
<input  type="submit" name="submit"  value="购买" id="search1"><br>
</form>
	
<span class="tooltiptext">
<div class='css01'>【龙吟苍穹の首饰套装】</div>
<br>
“龙吟苍穹”据说是由天界的龙族锻造大师亲手打造，蕴含着龙族的古老力量。
<br>
价格：188888 伏魔币 + 堕落的魔心x100
</span></span>




<?php
$cmid = $cmid + 1;
$cdid[] = $cmid;
$clj[] = 698;
$npc[] = 10;
$mdxurl = sprintf('xy.php?uid=%d&cmd=%d&sid=%s', $wjid, $cmid, $a1);
?>
<form  action="<?php echo $mdxurl?>" method="POST"><span class="demo_tooltip">
<font color=blue>〖龙鸣之圣晶〗</font> 
<input type="text" name="sl" placeholder="请输入"id='search'onkeyup="this.value=this.value.replace(/\D/g,'')" onafterpaste="this.value=this.value.replace(/\D/g,'')">
<input  type="submit" name="submit"  value="购买" id="search1"><br>
</form>
	
<span class="tooltiptext">
〖龙鸣之圣晶〗
<br>
升级龙鸣苍穹首饰装备时需要的材料
<br>
价格：888 伏魔币
</span></span>






<?php
$cmid = $cmid + 1;
$cdid[] = $cmid;
$clj[] = 698;
$npc[] = 9;
$mdxurl = sprintf('xy.php?uid=%d&cmd=%d&sid=%s', $wjid, $cmid, $a1);
?>
<form  action="<?php echo $mdxurl?>" method="POST"><span class="demo_tooltip">
<font color=blue>〖洪荒苍穹材料包〗</font> 
<input type="text" name="sl" placeholder="请输入"id='search'onkeyup="this.value=this.value.replace(/\D/g,'')" onafterpaste="this.value=this.value.replace(/\D/g,'')">
<input  type="submit" name="submit"  value="购买" id="search1"><br>
</form>
	
<span class="tooltiptext">
〖洪荒苍穹材料包〗
<br>
能开出升级洪荒苍穹装备时需要的材料
<br>
价格：1888 伏魔币 + 堕落的魔心x1
</span></span>


<?php
$cmid = $cmid + 1;
$cdid[] = $cmid;
$clj[] = 698;
$npc[] = 11;
$mdxurl = sprintf('xy.php?uid=%d&cmd=%d&sid=%s', $wjid, $cmid, $a1);
?>
<form  action="<?php echo $mdxurl?>" method="POST"><span class="demo_tooltip">
<font color=blue>〖洪荒苍穹材料包（100）〗</font> 
<input type="text" name="sl" placeholder="请输入"id='search'onkeyup="this.value=this.value.replace(/\D/g,'')" onafterpaste="this.value=this.value.replace(/\D/g,'')">
<input  type="submit" name="submit"  value="购买" id="search1"><br>
</form>
	
<span class="tooltiptext">
〖洪荒苍穹材料包（100）〗
<br>
能开出升级洪荒苍穹装备时需要的材料
<br>
价格：18888 伏魔币 + 堕落的魔心x10
</span></span>






<?php
echo "<br>";
//cmd及超链接值
$cmid=$cmid+1;
$cdid[]=$cmid;
$clj[]=7;
$npc[]=1324;
echo "<a href='xy.php?uid=$wjid&&cmd=$cmid&&sid=$a1'><font color=blue>返回上一级</font></a>"."<br>";

?>


































