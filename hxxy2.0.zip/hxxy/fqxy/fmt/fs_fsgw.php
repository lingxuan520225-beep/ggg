<?php

include("./sql/mysql.php");//调用数据库连
$sql1 = mysql_query("select * from wj_tf where wjid=$wjid", $conn);
$info1 = @mysql_fetch_array($sql1);
$tf_id = $info1['wjid'];
$tf_exp = $info1['tf_exp'];
$fs_lvl = $info1['fs_lvl'];
$fs_dj = $info1['fs_dj'];


$fs_jy = (($fs_lvl+1)*100000);
include("./ini/cl_ini.php");
$xyc1=($iniFile->getItem('材料数量','1212'));

if($npcc==1330){
	
	if($tf_exp>=$fs_jy){

        include("./ini/cl_ini.php");
        $xyc1=($iniFile->getItem('材料数量','1212'));

        if($xyc1>=1 and $fs_dj<10 ){
	
            $fs_exp = $tf_exp-$fs_jy;
            echo "<font color=00000>失去: 顿悟经验".$fs_jy."点</font>"."<br>";
			include("./sql/mysql.php");//调用数据库连
            $strsql = "update wj_tf set tf_exp=tf_exp-$fs_jy  where wjid=$wjid ";//物品id号必改值
            $result = mysql_query($strsql);
            
			$wpdz1[]="【佛陀护心珠】";//名字
            $wpdz2[]=2;//物品分类
            $wpdz3[]=1212;//物品id
            $wpdz4[]=1;//	需要扣除的量
            $wpdz5[]=1;//	重量
	
            //提供需要扣除的物品作为判读依据
            include("./pz/ini_pzz026.php");
	
    	    echo "<font color=blac>你在渡劫过程中，天空突然黑云遮日，天雷滚滚恐怖闪耀着，你明白这是天劫即将到来！</font>"."<br>";
		    echo "<br>";
	
	        //cmd及超链接值
            $cmid=$cmid+1;
            $cdid[]=$cmid;
            $clj[]=10;
            $npc[]=1346;
     	    echo "<a href='xy.php?uid=$wjid&&cmd=$cmid&&sid=$a1'><font color=red>继续渡劫>>></font></a>";
		    echo "<br>";
		    echo "（你身上有【佛陀护心珠】，继续渡劫将避免遇到强大的雷劫兽）";
		
	    }else{

            $jj_exp = $tf_exp-$fs_jy;
            echo "<font color=00000>失去: 顿悟经验".$fs_jy."点</font>"."<br>";
			include("./sql/mysql.php");//调用数据库连
            $strsql = "update wj_tf set tf_exp=tf_exp-$fs_jy  where wjid=$wjid ";//物品id号必改值
            $result = mysql_query($strsql);
        
	
    	    echo "<font color=blac>你在渡劫过程中，天空突然黑云遮日，天雷滚滚恐怖闪耀着，你明白这是天劫即将到来！</font>"."<br>";
		    echo "<br>";
	
	        //cmd及超链接值
            $cmid=$cmid+1;
            $cdid[]=$cmid;
            $clj[]=10;
            $npc[]=1346;
     	    echo "<a href='xy.php?uid=$wjid&&cmd=$cmid&&sid=$a1'><font color=red>继续渡劫>>></font></a>";
		    echo "<br>";
		    echo "（你身上没有【佛陀护心珠】，继续渡劫将极可能遇到强大的雷劫兽）";
	    
	
	    }
	
		
    }else{
		
		echo "<font color=blac>你对人世间的顿悟经验太少了，渡劫需要积累".$fs_jy."点顿悟经验！</font>"."<br>";
		echo "<br>";
	
	    //cmd及超链接值
        $cmid=$cmid+1;
        $cdid[]=$cmid;
        $clj[]=138;
        $npc[]=0;
     	echo "<a href='xy.php?uid=$wjid&&cmd=$cmid&&sid=$a1'><font color=red>返回上级</font></a>";
		
	}



}


































	
	
?>