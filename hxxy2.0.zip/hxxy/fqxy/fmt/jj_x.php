<?php

include("./sql/mysql.php");//调用数据库连接
$q2 = "wj_jj";
$sql1 = mysql_query("select * from $q2 where wjid=$wjid", $conn);
$info1 = @mysql_fetch_array($sql1);
$jj_d = $info1['wj_jj'];
$jj_cs = $info1['jj_cs'];




if($jj_d==1 and $jj_cs==10){
	echo "<font color=blac>筑基期</font>";
}elseif($jj_d==2 and $jj_cs==10){
	echo "<font color=blac>金丹期</font>";
}elseif($jj_d==3 and $jj_cs==10){
	echo "<font color=blac>元婴期</font>";
}elseif($jj_d==4 and $jj_cs==10){
	echo "<font color=blac>化神期</font>";
}elseif($jj_d==5 and $jj_cs==10){
	echo "<font color=blac>炼虚期</font>";
}elseif($jj_d==6 and $jj_cs==10){
	echo "<font color=blac>合体期</font>";
}elseif($jj_d==7 and $jj_cs==10){
	echo "<font color=blac>大乘期</font>";
}elseif($jj_d==8 and $jj_cs==10){
	echo "<font color=blac>真仙期</font>";
}elseif($jj_d==9 and $jj_cs==10){
	echo "<font color=blac>金仙期</font>";
}elseif($jj_d==10 and $jj_cs==10){
	echo "<font color=blac>太乙期</font>";
}elseif($jj_d==11 and $jj_cs==10){
	echo "<font color=blac>大罗期</font>";
}elseif($jj_d==12 and $jj_cs==10){
	echo "<font color=blac>道祖期</font>";
}elseif($jj_d==13 and $jj_cs==10){
	echo "<font color=blac>虚神境</font>";
}elseif($jj_d==14 and $jj_cs==10){
	echo "<font color=blac>真神境</font>";
}elseif($jj_d==15 and $jj_cs==10){
	echo "<font color=blac>神王境</font>";
}elseif($jj_d==16 and $jj_cs==10){
	echo "<font color=blac>祖神境</font>";
}elseif($jj_d==17 and $jj_cs==10){
	echo "<font color=blac>祖王境</font>";	
}elseif($jj_d==18 and $jj_cs==10){
	echo "<font color=blac>祖皇境</font>";	
}elseif($jj_d==19 and $jj_cs==10){
	echo "<font color=blac>祖帝境</font>";	
}elseif($jj_d==20 and $jj_cs==10){
	echo "<font color=blac>圣尊境</font>";	
}elseif($jj_d==21 and $jj_cs==10){
	echo "<font color=blac>仙尊境</font>";	
}elseif($jj_d==22 and $jj_cs==10){
	echo "<font color=blac>天帝境</font>";	
}elseif($jj_d==23 and $jj_cs==10){
	echo "<font color=blac>如来佛境</font>";	
}elseif($jj_d==24 and $jj_cs==10){
	echo "<font color=blac>神秘的境界</font>";
}


if($jj_d==1 and $jj_cs<10){
	echo "<font color=blac>练气期</font>";
}elseif($jj_d==2 and $jj_cs<10){
	echo "<font color=blac>筑基期</font>";
}elseif($jj_d==3 and $jj_cs<10){
	echo "<font color=blac>金丹期</font>";
}elseif($jj_d==4 and $jj_cs<10){
	echo "<font color=blac>元婴期</font>";
}elseif($jj_d==5 and $jj_cs<10){
	echo "<font color=blac>化神期</font>";
}elseif($jj_d==6 and $jj_cs<10){
	echo "<font color=blac>炼虚期</font>";
}elseif($jj_d==7 and $jj_cs<10){
	echo "<font color=blac>合体期</font>";
}elseif($jj_d==8 and $jj_cs<10){
	echo "<font color=blac>大乘期</font>";
}elseif($jj_d==9 and $jj_cs<10){
	echo "<font color=blac>真仙期</font>";
}elseif($jj_d==10 and $jj_cs<10){
	echo "<font color=blac>金仙期</font>";
}elseif($jj_d==11 and $jj_cs<10){
	echo "<font color=blac>太乙期</font>";
}elseif($jj_d==12 and $jj_cs<10){
	echo "<font color=blac>大罗期</font>";
}elseif($jj_d==13 and $jj_cs<10){
	echo "<font color=blac>道祖期</font>";
}elseif($jj_d==14 and $jj_cs<10){
	echo "<font color=blac>虚神境</font>";
}elseif($jj_d==15 and $jj_cs<10){
	echo "<font color=blac>真神境</font>";
}elseif($jj_d==16 and $jj_cs<10){
	echo "<font color=blac>神王境</font>";
}elseif($jj_d==17 and $jj_cs<10){
	echo "<font color=blac>祖神境</font>";
}elseif($jj_d==18 and $jj_cs<10){
	echo "<font color=blac>祖王境</font>";	
}elseif($jj_d==19 and $jj_cs<10){
	echo "<font color=blac>祖皇境</font>";	
}elseif($jj_d==20 and $jj_cs<10){
	echo "<font color=blac>祖帝境</font>";	
}elseif($jj_d==21 and $jj_cs<10){
	echo "<font color=blac>圣尊境</font>";	
}elseif($jj_d==22 and $jj_cs<10){
	echo "<font color=blac>仙尊境</font>";	
}elseif($jj_d==23 and $jj_cs<10){
	echo "<font color=blac>天帝境</font>";	
}elseif($jj_d==24 and $jj_cs<10){
	echo "<font color=blac>如来佛境</font>";			
}





if($jj_cs==1){
	echo "<font color=blac>[二层]</font>";
}elseif($jj_cs==2){
	echo "<font color=blac>[三层]</font>";
}elseif($jj_cs==3){
	echo "<font color=blac>[四层]</font>";
}elseif($jj_cs==4){
	echo "<font color=blac>[五层]</font>";
}elseif($jj_cs==5){
	echo "<font color=blac>[六层]</font>";
}elseif($jj_cs==6){
	echo "<font color=blac>[七层]</font>";
}elseif($jj_cs==7){
	echo "<font color=blac>[八层]</font>";
}elseif($jj_cs==8){
	echo "<font color=blac>[九层]</font>";
}elseif($jj_cs==9){
	echo "<font color=blac>[十层]</font>";
}else{
	echo "<font color=blac>[一层]</font>";
}