<?php


if($sz_tz==1){
	
	$q = "tzcs_1";
	
}elseif($sz_tz==2){

	$q = "tzcs_2";

}elseif($sz_tz==3){

	$q = "tzcs_3";

}elseif($sz_tz==4){

	$q = "tzcs_4";

}elseif($sz_tz==5){

	$q = "tzcs_5";

}elseif($sz_tz==6){

	$q = "tzcs_6";

}elseif($sz_tz==7){

	$q = "tzcs_7";

}elseif($sz_tz==8){

	$q = "tzcs_8";
	
}	
	
	
include("./sql/mysql.php");//调用数据库连接
$sql1 = mysql_query("select * from all_sz where wjid=$wjid", $conn);
$info1 = @mysql_fetch_array($sql1);
$jj_d = $info1['sz_lvl'];
$jj_cs = $info1['sz_cs'];
	
	
	
if($jj_d==0){

    //添加新数据
	$hdid=1;
	include("./sql/mysql.php");//调用数据库连接 
	$sql = "insert into all_sz (wjid,sz_lvl,sz_cs)  values('$wjid','1','1')";
 	if (!mysql_query($sql,$conn)){
   	die('Error: ' . mysql_error());
    }
}	
	
	

include("./sql/mysql.php");//调用数据库连接
$strsql = "update all_sz set $q=$q+1 where wjid=$wjid ";//物品id号必改值
$result = mysql_query($strsql);	




