<?php

include("./sql/mysql.php");//调用数据库连接
$q2 = "all_sz";
$sql1 = mysql_query("select * from $q2 where wjid=$wjid", $conn);
$info1 = @mysql_fetch_array($sql1);
$jj_d = $info1['sz_lvl'];
$jj_cs = $info1['sz_cs'];




if($jj_d==1 and $jj_cs==5){
	echo "<font color=blac>最强天将</font>";
}elseif($jj_d==2 and $jj_cs==5){
	echo "<font color=blac>最强天神</font>";
}elseif($jj_d==3 and $jj_cs==5){
	echo "<font color=blac>日月星君</font>";
}elseif($jj_d==4 and $jj_cs==5){
	echo "<font color=blac>地魁星君</font>";
}elseif($jj_d==5 and $jj_cs==5){
	echo "<font color=blac>天魁星君</font>";
}elseif($jj_d==6 and $jj_cs==5){
	echo "<font color=blac>地煞星君</font>";
}elseif($jj_d==7 and $jj_cs==5){
	echo "<font color=blac>天煞星君</font>";
}elseif($jj_d==8 and $jj_cs==5){
	echo "<font color=blac>天罡星君</font>";
}elseif($jj_d==9 and $jj_cs==5){
	echo "<font color=blac>天机星君</font>";
}elseif($jj_d==10 and $jj_cs==5){
	echo "<font color=blac>日游神君</font>";
}elseif($jj_d==11 and $jj_cs==5){
	echo "<font color=blac>夜游神君</font>";
}elseif($jj_d==12 and $jj_cs==5){
	echo "<font color=blac>白马帝君</font>";
}elseif($jj_d==13 and $jj_cs==5){
	echo "<font color=blac>司命帝君</font>";
}elseif($jj_d==14 and $jj_cs==5){
	echo "<font color=blac>太乙上仙</font>";
}elseif($jj_d==15 and $jj_cs==5){
	echo "<font color=blac>太乙金仙</font>";
}elseif($jj_d==16 and $jj_cs==5){
	echo "<font color=blac>太白金仙</font>";
}elseif($jj_d==17 and $jj_cs==5){
	echo "<font color=blac>天宫东殿主</font>";	
}elseif($jj_d==18 and $jj_cs==5){
	echo "<font color=blac>天宫西殿主</font>";	
}elseif($jj_d==19 and $jj_cs==5){
	echo "<font color=blac>天宫南殿主</font>";	
}elseif($jj_d==20 and $jj_cs==5){
	echo "<font color=blac>天宫北殿主</font>";	
}elseif($jj_d==21 and $jj_cs==5){
	echo "<font color=blac>天宫神殿将军</font>";		
}elseif($jj_d==22 and $jj_cs==5){
	echo "<font color=blac>神秘的殿主</font>";
}



















if($jj_d==1 and $jj_cs<5){
	echo "<font color=blac>最强天兵</font>";
}elseif($jj_d==2 and $jj_cs<5){
	echo "<font color=blac>最强天将</font>";
}elseif($jj_d==3 and $jj_cs<5){
	echo "<font color=blac>最强天神</font>";
}elseif($jj_d==4 and $jj_cs<5){
	echo "<font color=blac>日月星君</font>";
}elseif($jj_d==5 and $jj_cs<5){
	echo "<font color=blac>地魁星君</font>";
}elseif($jj_d==6 and $jj_cs<5){
	echo "<font color=blac>天魁星君</font>";
}elseif($jj_d==7 and $jj_cs<5){
	echo "<font color=blac>地煞星君</font>";
}elseif($jj_d==8 and $jj_cs<5){
	echo "<font color=blac>天煞星君</font>";
}elseif($jj_d==9 and $jj_cs<5){
	echo "<font color=blac>天罡星君</font>";
}elseif($jj_d==10 and $jj_cs<5){
	echo "<font color=blac>天机星君</font>";
}elseif($jj_d==11 and $jj_cs<5){
	echo "<font color=blac>日游神君</font>";
}elseif($jj_d==12 and $jj_cs<5){
	echo "<font color=blac>夜游神君</font>";
}elseif($jj_d==13 and $jj_cs<5){
	echo "<font color=blac>白马帝君</font>";
}elseif($jj_d==14 and $jj_cs<5){
	echo "<font color=blac>司命帝君</font>";
}elseif($jj_d==15 and $jj_cs<5){
	echo "<font color=blac>太乙上仙</font>";
}elseif($jj_d==16 and $jj_cs<5){
	echo "<font color=blac>太乙金仙</font>";
}elseif($jj_d==17 and $jj_cs<5){
	echo "<font color=blac>天宫东殿主</font>";	
}elseif($jj_d==18 and $jj_cs<5){
	echo "<font color=blac>天宫西殿主</font>";	
}elseif($jj_d==19 and $jj_cs<5){
	echo "<font color=blac>天宫南殿主</font>";	
}elseif($jj_d==20 and $jj_cs<5){
	echo "<font color=blac>天宫北殿主</font>";	
}elseif($jj_d==21 and $jj_cs<5){
	echo "<font color=blac>天宫神殿将军</font>";	
	
}





if($jj_cs==1){
	echo "<font color=blac> | 中期</font>";
}elseif($jj_cs==2){
	echo "<font color=blac> | 后期</font>";
}elseif($jj_cs==3){
	echo "<font color=blac> | 巅峰</font>";
}elseif($jj_cs==4){
	echo "<font color=blac> | 圆满</font>";
}elseif($jj_cs==5){
	echo "<font color=blac> | 前期</font>";
}