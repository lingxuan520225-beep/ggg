<?php

include("./sql/mysql.php");//调用数据库连接
$q2 = "wj_jj";
$sql1 = mysql_query("select * from $q2 where wjid=$wjid", $conn);
$info1 = @mysql_fetch_array($sql1);
$fstcs = $info1['fst_cs'];


include("./npc/fstagw.php");//调用怪物信息
$fmtgwmz = $nname;

//调用数据库连接


echo "<font color=00000>[渡劫飞仙塔]</font>"."<br>";
	
$img = '/fqxy/pic/gl/fs_ta.png';
echo '<img src="' . $img . ' "alt="图片"/>';
echo "<br>";	
echo "<font color=black>当前关卡: 第 [".$fstcs."] 关</font>";
echo "<br>";
echo "<font color=black>最高关卡: 第 [".$fstcs."] 关</font>";
echo "<br>";
echo "<font color=black>驻守佛陀: </font>";
?>

<span class="demo_tooltip">

<?php
echo "<font color=green>".$fmtgwmz."</font>";
?>
<span class="tooltiptext">
<?php
include("./fmt/fstsx.php");//调用怪物信息
?>
</span></span>

<?php
echo "<br>";
echo "<br>";

if($u_fmtcs<16){
	
//cmd及超链接值
$cmid=$cmid+1;
$cdid[]=$cmid;
$clj[]=10;
$npc[]=1345;
echo "<a href='xy.php?uid=$wjid&&cmd=$cmid&&sid=$a1'><font color=blue>〓开始挑战〓</font></a>"."<br>";

}else{
	
	
echo "你已通关目前最高关卡，更高关卡待后续开放！";

}

echo "<br>";


//cmd及超链接值
$cmid=$cmid+1;
$cdid[]=$cmid;
$clj[]=698;
$npc[]=998;
echo "<a href='xy.php?uid=$wjid&&cmd=$cmid&&sid=$a1'><font color=blue>〓重置关卡〓</font></a>"."<br>";



?>






