<?php

include("./sql/mysql.php");//调用数据库连接
$q2 = "wj_jj";
$sql1 = mysql_query("select * from $q2 where wjid=$wjid", $conn);
$info1 = @mysql_fetch_array($sql1);
$jj_d = $info1['wj_jj'];
$jj_cs = $info1['jj_cs'];
$jj_sx = $info1['jj_sx'];
$jj_jsgw = $info1['jj_jsgw'];

include("./ini/zt_ini.php");
$xljy = ($iniFile->getItem('玩家信息','修炼经验'));
$jj_jy = ($jj_cs*1100)*$jj_d*$jj_d*$jj_d;




if($xljy>=$jj_jy and $jj_cs<10 ){
	include("./ini/zt_ini.php");
    $jj_exp = $xljy-$jj_jy;
    $iniFile->updItem('玩家信息', ['修炼经验' => $jj_exp]);
    echo "<font color=00000>失去: 修炼经验".$jj_jy."点</font>"."<br>";
    $strsql = "update $q2 set jj_cs=jj_cs+1 ,jj_sx=jj_sx+2222  where wjid=$wjid ";//物品id号必改值
    $result = mysql_query($strsql);
    echo "<font color=black>恭喜你，提升境界层次成功，属性有所提升了!</font>"."<br>";
	
	$inina="ztt.ini";
    $path='ache/'.$wjid;
    $ininame = $path."/".$inina;
    _unlink($ininame); //删除文件
	
	echo "<br>";
    //cmd及超链接值
	$cmid=$cmid+1;
	$cdid[]=$cmid;
	$clj[]=699;
	$npc[]=0;
	echo "<a href='xy.php?uid=$wjid&&cmd=$cmid&&sid=$a1'><font color=blue>返回上级</font></a>";
	
	
}elseif($xljy<$jj_jy and $jj_cs<10){

    echo "<font color=black>提升境界层次需要：修炼经验".$jj_jy."点;</font>"."<br>";
 
	echo "<br>";
	//cmd及超链接值
	$cmid=$cmid+1;
    $cdid[]=$cmid;
	$clj[]=699;
	$npc[]=0;
	echo "<a href='xy.php?uid=$wjid&&cmd=$cmid&&sid=$a1'><font color=blue>返回上级</font></a>";
	
	
	 
	
	
}elseif($jj_cs==10 and $jj_jsgw==0 and $jj_d<24){
    
	if($xljy>=$jj_d*50000){
		
		include("./fmt/jj_tptj.php");
	
	    $wpdz1[]="【".$jj_tja."】";//名字
        $wpdz2[]=2;//物品分类
        $wpdz3[]=$jj_tjb;//物品id
        $wpdz4[]=1;//	需要扣除的量
        $wpdz5[]=1;//	重量
	
        //提供需要扣除的物品作为判读依据
        include("./pz/ini_pzz026.php");
	
        if($pd==2){
		
		    include("./ini/zt_ini.php");
            $jj_exp = $xljy-$jj_tpjy;
            $iniFile->updItem('玩家信息', ['修炼经验' => $jj_exp]);
			echo "<font color=00000>失去: 修炼经验".$jj_tpjy."点</font>"."<br>";
			
			//
			
		    echo "<font color=blac>[心魔的扰乱]<br>你在突破过程中遇到了心魔的扰乱，你需要战胜自己的心魔才能成功突破;</font>"."<br>";
			echo "<br>";
	
	        //cmd及超链接值
            $cmid=$cmid+1;
            $cdid[]=$cmid;
            $clj[]=10;
            $npc[]=1329;
            echo "<a href='xy.php?uid=$wjid&&cmd=$cmid&&sid=$a1'><font color=red>〓攻击心魔〓</font></a>";
			echo "<br>";
            echo "<font class=jjsm>注意：返回游戏和战斗心魔是否成功，都均不返还材料哦！！！</font>"."<br>";
			
		
	    }else{
		    
			include("./fmt/jj_tptj.php");
		    echo "<font color=red>突破失败，突破需要【".$jj_tja."】一个,修炼经验".$jj_tpjy."点;</font>"."<br>";
		
		    echo "<br>";
		    //cmd及超链接值
		    $cmid=$cmid+1;
		    $cdid[]=$cmid;
		    $clj[]=699;
		    $npc[]=0;
		    echo "<a href='xy.php?uid=$wjid&&cmd=$cmid&&sid=$a1'><font color=blue>返回上级</font></a>";
		
	    }
		
	}else{
		include("./fmt/jj_tptj.php");
		echo "<font color=red>突破失败，突破需要【".$jj_tja."】一个,修炼经验".$jj_tpjy."点;</font>"."<br>";
		
		echo "<br>";
		//cmd及超链接值
		$cmid=$cmid+1;
		$cdid[]=$cmid;
		$clj[]=699;
		$npc[]=0;
		echo "<a href='xy.php?uid=$wjid&&cmd=$cmid&&sid=$a1'><font color=blue>返回上级</font></a>";
		
	}
	
}elseif($jj_cs==10 and $jj_jsgw==1 and $jj_d<24){
	
	include("./sql/mysql.php");//调用数据库连接
    $q2 = "wj_jj";
    $strsql = "update $q2 set jj_jsgw=0 , wj_jj=wj_jj+1 , jj_cs=1 where wjid=$wjid ";//物品id号必改值
    $result = mysql_query($strsql);
	
	include("./template/xy699.php");//调用数据库连接
		
}elseif($jj_cs==10 and $jj_d==24){
	
	echo "<font color=red>突破失败，你已达到当前最高境界;更高境界待后续开放~;</font>"."<br>";
		
	echo "<br>";
	//cmd及超链接值
	$cmid=$cmid+1;
	$cdid[]=$cmid;
	$clj[]=699;
	$npc[]=0;
	echo "<a href='xy.php?uid=$wjid&&cmd=$cmid&&sid=$a1'><font color=blue>返回上级</font></a>";
		
}





































	
	
?>