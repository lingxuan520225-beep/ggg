<?php

include("./sql/mysql.php");//调用数据库连接
$q2 = "mtcz";
$sql1 = mysql_query("select * from $q2 where wjid=$wjid and hdid=1", $conn);
$info1 = @mysql_fetch_array($sql1);
$s_time = $info1['hdtime'];
$d_time = date('d');
$s_time_hdid = $info1['hdid'];
$s_time_hdcs = $info1['hdcs'];

if($s_time!=$d_time and $s_time_hdid!=1 ){
	
    //添加新数据
	$hdid=1;
	include("./sql/mysql.php");//调用数据库连接 
	$q2="mtcz";
	$sql = "insert into $q2 (wjid, hdid,hdtime,hdcs)  values('$wjid','$hdid','$d_time','1')";
 	if (!mysql_query($sql,$conn)){
   	die('Error: ' . mysql_error());
 	}
	
	$q2="all_zt";
    $strsql = "update $q2 set u_fmtcs=1 where wjid=$wjid";//物品id号必改值
    $result = mysql_query($strsql);
	

    echo "<font color=00000>重置伏魔塔成功，当前关卡已重置到第一关卡！</font>"."<br>";
	

} elseif($s_time!=$d_time and $s_time_hdid==1){
	
    include("./sql/mysql.php");//调用数据库连接
	$q2="mtcz";
    $strsql = "update $q2 set hdtime=$d_time , hdcs=hdcs+1 where wjid=$wjid and hdid=1";//物品id号必改值
    $result = mysql_query($strsql);
	
	$q2="all_zt";
    $strsql = "update $q2 set u_fmtcs=1 where wjid=$wjid";//物品id号必改值
    $result = mysql_query($strsql);
	

    echo "<font color=00000>重置伏魔塔成功，当前关卡已重置到第一关卡！</font>"."<br>";
	
} elseif($s_time==$d_time and $s_time_hdid==1){
	
	$wpdz1[]="〖伏魔重置卡〗";//名字
    $wpdz2[]=2;//物品分类
    $wpdz3[]=1064;//物品id
    $wpdz4[]=1;//	需要扣除的量
    $wpdz5[]=1;//	重量	
    //提供需要扣除的物品作为判读依据
    include("./pz/ini_pzz026.php");
	
	if($pd==2){
	
        include("./sql/mysql.php");//调用数据库连接
	
	    $q2="all_zt";
        $strsql = "update $q2 set u_fmtcs=1 where wjid=$wjid";//物品id号必改值
        $result = mysql_query($strsql);
	

        echo "<font color=00000>重置伏魔塔成功，当前关卡已重置到第一关卡！</font>"."<br>";	
		
	
	
	}else{
		
		echo "<font color=00000>每天只能免费重置一次，请使用〖伏魔重置卡〗这个物品重置或者明天再来！</font>"."<br>";
		
	}
	
	
}else{
	echo "<font color=00000>每天只能免费重置一次，请使用〖伏魔重置卡〗这个物品重置或者明天再来！</font>"."<br>";
	
}
	
	

//cmd及超链接值
$cmid=$cmid+1;
$cdid[]=$cmid;
$clj[]=7;
$npc[]=1324;
echo "<a href='xy.php?uid=$wjid&&cmd=$cmid&&sid=$a1'><font color=blue>返回上一级</font></a>"."<br>";
?>
