<?php


class Room
{

}