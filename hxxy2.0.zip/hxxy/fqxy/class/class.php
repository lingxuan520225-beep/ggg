<style>

 //////////////////////////////css//////////////////////////
@keyframes masked-animation {

            0% {

                background-position: 0 0;   /*background-position 属性设置背景图像的起始位置。*/

            }

            100% {

                background-position: -100% 0;

            }

        }

.css01{

            display: inline;

            width: 200px;

            height: 25px;

            /*渐变背景*/

            background-image: -webkit-linear-gradient(left, #0000ff, #0000ff 10%, #0000ff 20%, #0000ff 30%,

            #0000ff 40%, #0000ff 50%, #0000ff 60%, #ffff00 70%, #00ffff 80%, #0000ff 90%, #0000ff);

            color: transparent; /*文字填充色为透明*/

            -webkit-text-fill-color: transparent;

            -webkit-background-clip: text;          /*背景剪裁为文字，只将文字显示为背景*/

            background-size: 300% 100%;            /*背景图片向水平方向扩大一倍，这样background-position才有移动与变化的空间*/

            /* 动画 */
			
			text-shadow: 
    1px 1px 2px rgba(0, 0, 0, 0.3), /* 第一层阴影 */
    2px 2px 4px rgba(0, 0, 0, 0.2), /* 第二层阴影 */
    3px 3px 6px rgba(0, 0, 0, 0.1); /* 第三层阴影 */

            animation: masked-animation 5s infinite linear;

        }







   		
		
.css02{

            display: inline;

            width: 200px;

            height: 22px;

            /*渐变背景*/

            background-image: -webkit-linear-gradient(left, #000000, #000000 10%, #000000 20%, #000000 30%,

            #000000 40%, #000000 50%, #00ff00 60%, #ffff00 70%, #00ffff 80%, #000000 90%, #000000);

            color: transparent; /*文字填充色为透明*/

            -webkit-text-fill-color: transparent;

            -webkit-background-clip: text;          /*背景剪裁为文字，只将文字显示为背景*/

            background-size: 500% 100%;            /*背景图片向水平方向扩大一倍，这样background-position才有移动与变化的空间*/

            /* 动画 */
			
			text-shadow: 
    1px 1px 2px rgba(0, 0, 0, 0.3), /* 第一层阴影 */
    2px 2px 4px rgba(0, 0, 0, 0.2), /* 第二层阴影 */
    3px 3px 6px rgba(0, 0, 0, 0.1); /* 第三层阴影 */
	4px 4px 8px rgba(0, 0, 0, 0.1); /* 第三层阴影 */

            animation: masked-animation 5s infinite linear;

        }      





.css03{

            display: inline;

            width: 200px;

            height: 22px;

            /*渐变背景*/
	
            background-image: -webkit-linear-gradient(left, #00ffff, #00ffff 10%, #00ffff 20%, #00ffff 30%,

            #00ffff 40%, #00ffff 50%, #ff0000 60%, #ffff00 70%, #00ffff 80%, #00ffff 90%, #00ffff);

            color: transparent; /*文字填充色为透明*/

            -webkit-text-fill-color: transparent;

            -webkit-background-clip: text;          /*背景剪裁为文字，只将文字显示为背景*/

            background-size: 500% 100%;            /*背景图片向水平方向扩大一倍，这样background-position才有移动与变化的空间*/

            /* 动画 */
			
			text-shadow: 
    1px 1px 2px rgba(0, 0, 0, 0.3), /* 第一层阴影 */
    2px 2px 4px rgba(0, 0, 0, 0.2), /* 第二层阴影 */
    3px 3px 6px rgba(0, 0, 0, 0.1); /* 第三层阴影 */

            animation: masked-animation 5s infinite linear;

        }    
      
	


		   				   
		   
.css04{

            display: inline;

            width: 200px;

            height: 22px;

            /*渐变背景*/

            background-image: -webkit-linear-gradient(left, #ffa500, #ffa500 10%, #ffa500 20%, #ffa500 30%,

            #ffa500 40%, #ffa500 50%, #000000 60%, #ffff00 70%, #00ffff 80%, #ffa500 90%, #ffa500);

            color: transparent; /*文字填充色为透明*/

            -webkit-text-fill-color: transparent;

            -webkit-background-clip: text;          /*背景剪裁为文字，只将文字显示为背景*/

            background-size: 500% 100%;            /*背景图片向水平方向扩大一倍，这样background-position才有移动与变化的空间*/

            /* 动画 */
			
			text-shadow: 
    1px 1px 2px rgba(0, 0, 0, 0.3), /* 第一层阴影 */
    2px 2px 4px rgba(0, 0, 0, 0.2), /* 第二层阴影 */
    3px 3px 6px rgba(0, 0, 0, 0.1); /* 第三层阴影 */

            animation: masked-animation 5s infinite linear;

        }  


.css05{

            display: inline;

            width: 200px;

            height: 22px;

            /*渐变背景*/

            background-image: -webkit-linear-gradient(left, #ff8000, #ff8000 10%, #ff0000 20%, #ff0000 30%,

            #ff0000 40%, #ff0000 50%, #000000 60%, #ffff00 70%, #00ffff 80%, #ff0000 90%, #ff0000);

            color: transparent; /*文字填充色为透明*/

            -webkit-text-fill-color: transparent;

            -webkit-background-clip: text;          /*背景剪裁为文字，只将文字显示为背景*/

            background-size: 500% 100%;            /*背景图片向水平方向扩大一倍，这样background-position才有移动与变化的空间*/

            /* 动画 */
			
			text-shadow: 
    1px 1px 2px rgba(0, 0, 0, 0.3), /* 第一层阴影 */
    2px 2px 4px rgba(0, 0, 0, 0.2), /* 第二层阴影 */
    3px 3px 6px rgba(0, 0, 0, 0.1); /* 第三层阴影 */

            animation: masked-animation 5s infinite linear;

        } 


.css06{

            display: inline;

            width: 200px;

            height: 22px;

            /*渐变背景*/

            background-image: -webkit-linear-gradient(left, #CD5C5C, #CD5C5C 10%, #CD5C5C 20%, #CD5C5C 30%,

            #CD5C5C 40%, #CD5C5C 50%, #000000 60%, #ffff00 70%, #00ffff 80%, #CD5C5C 90%, #CD5C5C);

            color: transparent; /*文字填充色为透明*/

            -webkit-text-fill-color: transparent;

            -webkit-background-clip: text;          /*背景剪裁为文字，只将文字显示为背景*/

            background-size: 500% 100%;            /*背景图片向水平方向扩大一倍，这样background-position才有移动与变化的空间*/

            /* 动画 */
			
			text-shadow: 
    1px 1px 2px rgba(0, 0, 0, 0.3), /* 第一层阴影 */
    2px 2px 4px rgba(0, 0, 0, 0.2), /* 第二层阴影 */
    3px 3px 6px rgba(0, 0, 0, 0.1); /* 第三层阴影 */

            animation: masked-animation 5s infinite linear;

        } 


.css07{

            display: inline;

            width: 200px;

            height: 22px;

            /*渐变背景*/

            background-image: -webkit-linear-gradient(left, #FF0000, #FF0000 10%, #FF0000 20%, #FF0000 30%,

            #FF0000 40%, #FF0000 50%, #000000 60%, #ffff00 70%, #00ffff 80%, #FF0000 90%, #FF0000);

            color: transparent; /*文字填充色为透明*/

            -webkit-text-fill-color: transparent;

            -webkit-background-clip: text;          /*背景剪裁为文字，只将文字显示为背景*/

            background-size: 500% 100%;            /*背景图片向水平方向扩大一倍，这样background-position才有移动与变化的空间*/

            /* 动画 */
			
			text-shadow: 
    1px 1px 2px rgba(0, 0, 0, 0.3), /* 第一层阴影 */
    2px 2px 4px rgba(0, 0, 0, 0.2), /* 第二层阴影 */
    3px 3px 6px rgba(0, 0, 0, 0.1); /* 第三层阴影 */

            animation: masked-animation 5s infinite linear;

        } 





.css08{

            display: inline;

            width: 200px;

            height: 22px;

            /*渐变背景*/

            background-image: -webkit-linear-gradient(left, #FF0000, #FF0000 10%, #FF0000 20%, #FF0000 30%,

            #FF0000 40%, #FF0000 50%, #000000 60%, #ffff00 70%, #00ffff 80%, #FF0000 90%, #FF0000);

            color: transparent; /*文字填充色为透明*/

            -webkit-text-fill-color: transparent;

            -webkit-background-clip: text;          /*背景剪裁为文字，只将文字显示为背景*/

            background-size: 500% 100%;            /*背景图片向水平方向扩大一倍，这样background-position才有移动与变化的空间*/

            /* 动画 */
			
			text-shadow: 
    1px 1px 2px rgba(0, 0, 0, 0.3), /* 第一层阴影 */
    2px 2px 4px rgba(0, 0, 0, 0.2), /* 第二层阴影 */
    3px 3px 6px rgba(0, 0, 0, 0.1); /* 第三层阴影 */

            animation: masked-animation 5s infinite linear;

        } 


.css09{

            display: inline;

            width: 200px;

            height: 22px;

            /*渐变背景*/

            background-image: -webkit-linear-gradient(left, #FF0000, #FF0000 10%, #FF0000 20%, #FF0000 30%,

            #FF0000 40%, #FF0000 50%, #000000 60%, #ffff00 70%, #00ffff 80%, #FF0000 90%, #FF0000);

            color: transparent; /*文字填充色为透明*/

            -webkit-text-fill-color: transparent;

            -webkit-background-clip: text;          /*背景剪裁为文字，只将文字显示为背景*/

            background-size: 500% 100%;            /*背景图片向水平方向扩大一倍，这样background-position才有移动与变化的空间*/

            /* 动画 */
			
			text-shadow: 
    1px 1px 2px rgba(0, 0, 0, 0.3), /* 第一层阴影 */
    2px 2px 4px rgba(0, 0, 0, 0.2), /* 第二层阴影 */
    3px 3px 6px rgba(0, 0, 0, 0.1); /* 第三层阴影 */

            animation: masked-animation 5s infinite linear;

        } 


@keyframes masked-animation {

            0% {

                background-position: 0% 0;   

            }

            100% {

                background-position: -100% 0;

            }

        }






















	
			
</style>







<style>



.demo_tooltip {
    text-decoration: underline;
    position: relative;
    display: inline-block;
}

.demo_tooltip:hover .tooltiptext {
    visibility: visible;
}

.demo_tooltip .tooltiptext {
    font-size: 14px;
    line-height: 19px;
    visibility: hidden;
    width: 200px;
    background-color: #F0F0F0; /* 修改背景颜色为灰白色 */
    color: #000000; /* 字体颜色保持黑色 */
    border-radius: 9px;
    padding: 15px; /* 保持15px的内边距 */
    text-align: left;
    position: absolute;
    z-index: 99999;
    top: 30px;
    left: 12px;
}

.demo_tooltip .tooltiptext::after {
    content: "";
    position: absolute;
    bottom: 100%;
    left: 10%;
    margin-left: -5px;
    border-width: 5px;
    border-style: solid;
    border-color: transparent transparent #000000 transparent; /* 箭头颜色保持黑色 */
}
			

input[type="text"] {
            width: 15%;
            
        }			
			





.demo {
    text-decoration: underline;
    position: relative;
    display: inline-block;
}

.demo:hover .text {
    visibility: visible;
}

.demo .text {
    font-size: 14px;
    line-height: 19px;
    visibility: hidden;
    width: 300px;
    background-color: #000000; /* 修改背景颜色为灰白色 */
    color: #ffffff; /* 字体颜色保持黑色 */
    border-radius: 9px;
    padding: 15px; /* 保持15px的内边距 */
    text-align: left;
    position: absolute;
    z-index: 99999;
    top: 30px;
    left: 12px;
}

.demo.text::after {
    content: "";
    position: absolute;
    bottom: 100%;
    left: 10%;
    margin-left: -5px;
    border-width: 5px;
    border-style: solid;
    border-color: transparent transparent #000000 transparent; /* 箭头颜色保持黑色 */
}


.demo_w {
    text-decoration: underline;
    position: relative;
    display: inline-block;
}

.demo_w:hover .text {
    visibility: visible;
}

.demo_w .text {
    font-size: 14px;
    line-height: 19px;
    visibility: hidden;
    width: 180px;
    background-color: #000000; /* 修改背景颜色为灰白色 */
    color: #ffffff; /* 字体颜色保持黑色 */
    border-radius: 9px;
    padding: 15px; /* 保持15px的内边距 */
    text-align: left;
    position: absolute;
    z-index: 99999;
    top: 30px;
    left: 12px;
}

.demo.text::after {
    content: "";
    position: absolute;
    bottom: 100%;
    left: 10%;
    margin-left: -5px;
    border-width: 5px;
    border-style: solid;
    border-color: transparent transparent #000000 transparent; /* 箭头颜色保持黑色 */
}


.css{

            
			
			text-shadow: 
    1px 1px 2px rgba(0, 0, 0, 0.3), /* 第一层阴影 */
    2px 2px 4px rgba(0, 0, 0, 0.2), /* 第二层阴影 */
    3px 3px 6px rgba(0, 0, 0, 0.1); /* 第三层阴影 */

            

        }



.caise7 {
  --interval: 1s;
    text-shadow: 
    0 0 5px var(--color1),
    0 0 5px var(--color2),
    0 0 5px var(--color3),
    0 0 5px var(--color4);
  will-change: filter, color;
  filter: saturate(60%);
  animation: flicker steps(100) var(--interval) 1s infinite;
}
.caise7:nth-of-type(1) {
  color: black;
  --color1: azure;
  --color2: orangered;
  --color3: mediumblue;
  --color4: dodgerblue;
  font-family: Gruppo;
}

.caise7:nth-of-type(2) {
  color: lightpink;
  --color1: pink;
  --color2: mediumblue;
  --color3: dodgerblue;
  --color4: azure;
  font-family: Bad Script;
}

.caise7:nth-of-type(3) {
  color: lightyellow;
  --color1: black;
  --color2: dodgerblue;
  --color3: green;
  --color4: mediumblue;
  font-family: Kumar One Outline;
}

.caise7:nth-of-type(4) {
  color: lightyellow;
  --color1: gold;
  --color2: dodgerblue;
  --color3: pink;
  --color4: azure;
  font-family: Londrina Outline;
}


.caise7:nth-of-type(5) {
  color: azure;
  --color1: azure;
  --color2: aqua;
  --color3: dodgerblue;
  --color4: blue;
  font-family: Sriracha;
}

.caise7:nth-of-type(6) {
  color:  azure;
  --color1: green;
  --color2: pink;
  --color3: dodgerblue;
  --color4: green;
  font-family: Yellowtail;
}

.caise7:nth-of-type(7) {
  color: lightyellow;
  --color1: yellow;
  --color2: orange;
  --color3: pink;
  --color4: purple;
  font-family: Bad Script;
}

.caise7:nth-of-type(8) {
  color: yellow;
  --color1: yellow;
  --color2: pink;
  --color3: azure;
  --color4: pink;
  font-family: Monoton;
}

.caise7:nth-of-type(9) {
  color: lightyellow;
  --color1: yellow;
  --color2: gold;
  --color3: azure;
  --color4: pink;
  font-family: Sriracha;
}
@keyframes flicker {
  50% {
    color:  white;
    filter: saturate(200%) hue-rotate(90deg);
  }
}




</style>