<?php

function color_string($input) {
    
    $input = str_replace('@css01@', '<wap class=css01>', $input);
	$input = str_replace('@css02@', '<wap class=css02>', $input);
	$input = str_replace('@css03@', '<wap class=css03>', $input);
	$input = str_replace('@css04@', '<wap class=css04>', $input);
	$input = str_replace('@css05@', '<wap class=css05>', $input);
	$input = str_replace('@css06@', '<wap class=css06>', $input);
	$input = str_replace('@css07@', '<wap class=css07>', $input);
	$input = str_replace('@css08@', '<wap class=css08>', $input);
	$input = str_replace('@css09@', '<wap class=css09>', $input);
	$input = str_replace('@css010@', '<wap class=css010>', $input);
    $input = str_replace('@css@', '</wap>', $input);

    return $input;
}



?>