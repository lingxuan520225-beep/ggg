<!DOCTYPE html>
<html lang="zh">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,height=device-height,inital-scale=1.0,maximum-scale=1.0,user-scalable=no;">
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta name="format-detection" content="telephone=no">
    <title>幻想西游管理平台-注册</title>
    <link rel="icon" href="../img/favicon.png" type="image/x-icon" />
    <style>
    </style>
</head>
<body>

<?php
error_reporting(E_ALL & ~E_NOTICE);
include_once __DIR__ . '/../includes/constants.php';
include ROOT . '/sql/mysql.php';
$configs = include JY_CONFIG_DIR . '/config.php';

session_start();
$db = DB::instance();
$user=0;
$zcxx = '';
try {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $exists = $db->count('gmuser');
        if ($exists) {
            throw new InvalidArgumentException('管理员帐号已存在，请直接<a style="color: #51acff" href="/admin/login.php">登录帐号</a>');
        }

        if (empty($_POST['username']) || !preg_match('/^[a-zA-Z0-9]+$/', $_POST['username'])){
            throw new InvalidArgumentException('无效帐号');
        }
        $username = $_POST['username'];

        if (empty($_POST['password'])) {
            throw new InvalidArgumentException('无效密码');
        }
        $password = $_POST['password'];

        if (empty($_POST['confirm_password'])) {
            throw new InvalidArgumentException('请输入确认密码');
        }
        $confirmPassword = $_POST['confirm_password'];

        if ($password !== $confirmPassword) {
            throw new InvalidArgumentException('两次输入密码不一致');
        }

        $adminPassword = password_hash($password, PASSWORD_BCRYPT);
        $db->insert('gmuser', [
            'name' => $username,
            'username' => $username,
            'password' => $adminPassword,
        ]);

        $xxjyurl = $configs['jy_url'];
        $xyurl = $xxjyurl . "/admin/login.php";
        header( "refresh:5;url={$xyurl}" );
        printf('管理员注册成功，请前往<a href="%s">登录页面</a>登录帐号', $xyurl);
        exit;
    }
} catch (InvalidArgumentException $e) {
    $zcxx = sprintf('<span style="color: red">%s</span>', $e->getMessage());
}
?>

<div>
    <?php echo $zcxx;?><br>
    请输入管理员账号和密码
</div>
<div>
    <form  action="register.php" method="POST">
        账号：<input  type="text" name="username" placeholder="请输入管理员账号"><br>
        密码：<input  type="password" name="password" placeholder="请输入管理员密码"><br>
        确认密码：<input  type="password" name="confirm_password" placeholder="请确认管理员密码"><br>
        <input  type="submit" name="submit" value="注册" ><br>
    </form>
</div>

<div style="min-height: 80px;">
</div>
</body>
</html>
