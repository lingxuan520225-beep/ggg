<!DOCTYPE html>
<html lang="zh">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>幻想西游GM管理平台</title>
</head>
<body>

<div style='width: device-width;display:block;word-break: break-all;word-wrap: break-word;'>
    <?php
    error_reporting(E_ALL & ~E_NOTICE);
    include_once __DIR__ . '/../includes/constants.php';
    $configs = include JY_CONFIG_DIR . '/config.php';

    session_start();
    if (empty($_SESSION['admin']) || empty($_SESSION['token'])) {
        header('location: /admin/login.php', true, 302);
        exit;
    }

    // Handle partition addition
    if (isset($_POST['add_partition'])) {
        $qy = intval($_POST['qy']);
        $url = trim($_POST['url']);
        $name = trim($_POST['name']);
        $status = intval($_POST['status']);
        
        if ($qy && $url && $name) {
            $config_file = JY_CONFIG_DIR . '/config.php';
            $config_content = file_get_contents($config_file);
            
            // Extract the urls array
            preg_match('/\$config\[\'urls\'\]\s*=\s*\[(.*?)\];/s', $config_content, $matches);
            if (isset($matches[1])) {
                $urls_array = $matches[1];
                $new_partition = "\n    [\n        'qy' => $qy,\n        'url' => '$url',\n        'name' => '$name',\n        'status' => $status, // 运行状态，1正常，0关闭\n    ]";
                
                // Add the new partition before the closing bracket
                $new_urls_array = rtrim($urls_array, "\n\t\r ") . $new_partition;
                $new_config_content = str_replace($matches[1], $new_urls_array, $config_content);
                
                // Write the updated config file
                if (file_put_contents($config_file, $new_config_content)) {
                    echo "<font color=green>分区添加成功！</font><br>";
                    // Refresh the page to show the new partition
                    header('Refresh: 1');
                } else {
                    echo "<font color=red>分区添加失败，请检查文件权限！</font><br>";
                }
            }
        } else {
            echo "<font color=red>请填写完整的分区信息！</font><br>";
        }
    }

    $uid = $_SESSION['admin'];
    $token = $_SESSION['token'];
    $xxjyurl = $configs['jy_url'];
    echo '<font color=red>【请选择你需要要管理的项目】</font><br>';
    echo '<a href="' . $xxjyurl . '/admin/gm01.php"><font color=blue>社区管理（总站）</font></a><br>';
    echo '<br>';
    foreach ($configs['urls'] as $i => $v) {
        if ($v['status'] == 0) {
            continue;
        }
        echo '<a href="' . $v['url'] . '/fqxy/gm.php?uid=' . $uid . '&token=' . $token . '&gid=1"><font color=blue>' . ($i + 1) . '.' . $v['name'] . '</font></a><br>';
        echo '<br>';
    }
    
    echo '<br><font color=red>【添加新分区】</font><br>';
    echo '<form method="post" action="">';
    echo '分区ID: <input type="text" name="qy" placeholder="输入分区ID"><br>';
    echo '分区URL: <input type="text" name="url" placeholder="输入分区完整URL"><br>';
    echo '分区名称: <input type="text" name="name" placeholder="输入分区名称"><br>';
    echo '运行状态: <select name="status">';
    echo '<option value="1">正常</option>';
    echo '<option value="0">关闭</option>';
    echo '</select><br>';
    echo '<input type="submit" name="add_partition" value="添加分区">';
    echo '</form>';
    ?>
</div>

</body>
</html>